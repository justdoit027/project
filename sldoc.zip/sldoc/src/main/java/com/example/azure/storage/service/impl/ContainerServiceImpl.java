package com.example.azure.storage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.azure.storage.mapper.ContainersMapper;
import com.example.azure.storage.model.Containers;
import com.example.azure.storage.service.ContainerService;
import com.example.azure.storage.util.AzureApp;

@Service
public class ContainerServiceImpl implements ContainerService {

	@Value("${storageConnectionString}")
	private String storageConnectionString;
	
	@Value("${containerString}")
	private String containerString;
	
	@Autowired
	private ContainersMapper containersMapper;
	
	public boolean createContainer(String containerName) {
		AzureApp azure = new AzureApp(storageConnectionString);
		boolean createContainer = azure.createContainer(containerName);
		return createContainer;
	}
	
	
	public List<String> findContainerList() {
		AzureApp azure = new AzureApp(storageConnectionString);
		List<String> findContainerList = azure.findContainerList();
		return findContainerList;
	}
	
	//TODO modify container object
	public boolean deleteContainer(String containerName) {
		AzureApp azure = new AzureApp(storageConnectionString);

		System.out.println("Deleting the container");
			if(azure.exitContainer(containerName)) {
				azure.deleteContainerIfExists(containerName);
				System.out.println("exist container "+containerName+" delete it!");
				return true;
			}else {
				System.out.println("there no container "+containerName);
			}
		
		return false;

	}


	@Override
	public Containers findContainerByID(String ContainerID) {
		// TODO Auto-generated method stub
		return containersMapper.findContainerByID(ContainerID);
	}
	
	


}
