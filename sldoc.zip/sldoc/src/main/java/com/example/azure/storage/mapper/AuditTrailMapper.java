package com.example.azure.storage.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.example.azure.storage.model.AuditTrail;

@Mapper
public interface AuditTrailMapper {
	public List<AuditTrail> getFormAuditTrailList(String formID);
	public List<AuditTrail> getDocAuditTrailList(String docID );
	public void addFormAuditTrail(AuditTrail auditTrail);
	public void addDocAuditTrail(AuditTrail auditTrail);

}
