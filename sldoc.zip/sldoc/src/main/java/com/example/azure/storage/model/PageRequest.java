package com.example.azure.storage.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageRequest extends Document{
    private Integer pageNum;
    private Integer pageSize;
//    private String policyNO;
//    private String agentCode;
//    private String NIC;
    private String query;
}
