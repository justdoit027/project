package com.example.azure.storage.model;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class DmsDocumentTree {
	
	private String folderID;
	private String folderName;
	private String formID;
	private String URI;
	private String fileName; 
	private String parentFolderID;
	private String type; // 0:folder ,1:document  
	private String isLeaf ;
	private String isForm;
	private String suffix;
	
	private List<DmsDocumentTree> children ;

	@Override
	public String toString() {
		return "DmsDocumentTree [folderID=" + folderID + ", folderName=" + folderName + ", formID=" + formID + ", URI="
				+ URI + ", fileName=" + fileName + ", parentFolderID=" + parentFolderID + ", type=" + type + ", isLeaf="
				+ isLeaf + ", isForm=" + isForm + ", suffix=" + suffix + ", children=" + children + "]";
	}
	

	
	
}
