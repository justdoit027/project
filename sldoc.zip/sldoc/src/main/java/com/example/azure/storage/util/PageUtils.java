package com.example.azure.storage.util;

import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.model.PageRequest;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

public class PageUtils {

	public static Page<Object> startPage(PageRequest param) {
        int pageNum = 0;
        int pageSize = 0;
 
        if (param.getPageNum() != null && param.getPageSize() != null) {
            pageNum = param.getPageNum();
            pageSize = param.getPageSize();
        } else if (param.getPageNum() == null || param.getPageSize() == null) {
//            log.error("StartPage Failed!");
        }else {
//            log.error("Failed");
        }
 
        Page<Object> startPage = PageHelper.startPage(pageNum, pageSize,true);
        return startPage;
    }
	
	public static Page<Object> startPage(FormDefinition param) {
        int pageNum = 0;
        int pageSize = 0;
 
        if (param.getPageNum() != null && param.getPageSize() != null) {
            pageNum = param.getPageNum();
            pageSize = param.getPageSize();
        } else if (param.getPageNum() == null || param.getPageSize() == null) {
//            log.error("StartPage Failed!");
        }else {
//            log.error("Failed");
        }
 
        Page<Object> startPage = PageHelper.startPage(pageNum, pageSize,true);
        return startPage;
    }
}
