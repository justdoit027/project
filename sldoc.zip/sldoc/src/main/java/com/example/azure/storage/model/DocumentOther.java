package com.example.azure.storage.model;

public class DocumentOther extends Document {

}
