package com.example.azure.storage.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.example.azure.storage.aop.AuditTrailLog;
import com.example.azure.storage.common.FunctionTypeValue;
import com.example.azure.storage.mapper.DmsDocumentsMapper;
import com.example.azure.storage.mapper.DocumentsMapper;
import com.example.azure.storage.mapper.FormDefinitionMapper;
import com.example.azure.storage.model.Containers;
import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.DmsFolderHierarchy;
import com.example.azure.storage.model.DocControl;
import com.example.azure.storage.model.DocTemplete;
import com.example.azure.storage.model.Document;
import com.example.azure.storage.model.DocumentAgent;
import com.example.azure.storage.model.DocumentOther;
import com.example.azure.storage.model.DocumentPolicy;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.model.MasterFolder;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;
import com.example.azure.storage.service.ContainerService;
import com.example.azure.storage.service.DmsDocumentsService;
import com.example.azure.storage.util.AESUtils;
import com.example.azure.storage.util.AzureApp;
import com.example.azure.storage.util.JsonUtils;
import com.example.azure.storage.util.MD5Utils;
import com.example.azure.storage.util.PageUtils;
import com.github.pagehelper.Page;
import com.sun.org.apache.xpath.internal.operations.And;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DmsDocumentsServiceImpl implements DmsDocumentsService {


	@Value("${storageConnectionString}")
	private String storageConnectionString;
	
	@Value("${containerString}")
	private String containerString;
	
	@Value("${blobfilepath}")
	private String blobfilepath;
	
	@Value("${targetFilepath}")
	private String targetFilepath;
	
	@Autowired
	public DocumentsMapper dmsDocumentsMapper;
	
	@Autowired
	public FormDefinitionMapper formDefinitionMapper;
	
	@Autowired
	public ContainerService containerService;
	
	
	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_UPDATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO)
	@Override
	@Transactional
	public boolean  updateDocument(Document document) {
		DocControl docControl = new DocControl();
		String filePath = document.getFilePath();
		String containerID = document.getContainerID();
		String docID = document.getDocID();

				
		DocControl oldVersionDoc = findOldVersionByDocID(docID);
		String versionNum = oldVersionDoc.getVersionNum();
		int newVsersionNum = Integer.parseInt(versionNum)+1;
		
		//upload to Azure container
		AzureApp azureApp = new AzureApp(storageConnectionString); 
		File file = new File(filePath);
		String name = file.getName();
		int lastIndexOf = name.lastIndexOf(".");
		String substring = name.substring(0, lastIndexOf); 
		String suffix = name.substring(name.lastIndexOf(".") + 1);
//		String newName = substring+"_"+newVsersionNum+"."+suffix;     //fileName_VersionNo
		String newName = docID+"_"+newVsersionNum+"."+suffix;	  //fileID_VersionNo
		log.info("new file name:"+newName);
		
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Containers container = containerService.findContainerByID(containerID);
//		azureApp.uploadFile(file,container.getContainerName());
		List<Map<String, Object>> maplist = new ArrayList<>();
		Map<String, Object> map= new HashMap<>();
		map.put("InputStream", fileInputStream);
		map.put("fileName", newName);
		maplist.add(map);
		String URI = azureApp.uploadFromStreamList(maplist,container.getContainerName());
		
		//if old document, find the doc and update the doc table to new version
		document.setVersionNum(String.valueOf(newVsersionNum));
		document.setFileName(newName);
		document.setURI(URI);
		upatePolicyDocument(document);
		log.info("find the doc :"+docID+", update the doc table to new version.");
		
		docControl.setVersionNum(String.valueOf(newVsersionNum));
		docControl.setDocID(docID);
		
		if (document.getDocType() == null || "".equals(document.getDocType())) {
			docControl.setDocType("policy");
			docControl.setContainerID("1");
			document.setContainerID("1");
		}else {
			docControl.setDocType(document.getDocType());
			if(document.getDocType() == "policy" || "policy".equals(document.getDocType())) {
				docControl.setContainerID("1");
				document.setContainerID("1");
			}else if(document.getDocType() == "agent" || "agent".equals(document.getDocType())) {
				docControl.setContainerID("2");
				document.setContainerID("2");
			}else {
				docControl.setContainerID("3");
				document.setContainerID("3");
			}
		}
		docControl.setFilePath(file.getParent()+"\\"+newName);
		docControl.setFileSize(String.valueOf(file.length()));
		docControl.setDocName(newName);
		docControl.setExtension(suffix);
		docControl.setURI(URI);
		
		//upload to doc versionControl table
		if(uploadNewVersion(docControl)) {
			return true;
		}
		return false;
	}
	
	
	@Override
	@Transactional
	public String downloadFile(List<String> fileNameList,String containerName) {
		
		AzureApp azure = new AzureApp(storageConnectionString);
		azure.downloadFilelist(targetFilepath,fileNameList,containerName);
		System.out.println("download File successfully");
		
		return targetFilepath;
		
	}

	@Override
	@Transactional
	public List<String> uploadFileList(String filePath,String containerName) {
		List<String> resultlist = new ArrayList<String>();
		AzureApp azure = new AzureApp(storageConnectionString);

		List<File> filelist1 = new ArrayList<File>();
		File file = new File(filePath);

		if (file.isDirectory()) {
			
			File filelist[] = file.listFiles();
			for(File f : filelist){
				System.out.println(f.getAbsolutePath());
				filelist1.add(f);
			}
			azure.uploadFromFilelist(filelist1, containerName);
			System.out.println("upload files under folder:"+filePath+" successfully");
			
		}else if (file.isFile()) {
			filelist1.add(file);
			azure.uploadFromFilelist(filelist1,containerName);
			System.out.println("upload file:"+file.getAbsolutePath()+" successfully");
		}
		return resultlist;
		
	}

	@Override
	@Transactional
	public List<FolderHierarchy> findFolderHierarchy() {
		
		List<FolderHierarchy> folderHierarchyList = formDefinitionMapper.findFormHierarchy();
		for (FolderHierarchy folderHierarchy : folderHierarchyList) {
			System.out.println(folderHierarchy.toString());
		}
		return folderHierarchyList;
	}
	
//	@Override
//	public List<DmsDocumentTree> getPolicyDocumentTree(String policyNo) {
//		List<DmsDocumentTree> DocumentsList = findPolicyDocumentsTreeByPolicyNo(policyNo);
//		return DocumentsList;
//	}

//	@Override
//	public List<DmsDocumentTree> searchFileHierarchyList(String keyID) {
//		
//		List<DmsDocumentTree> DocumentsList = findPolicyDocumentsTreeByKeyID(keyID);
		/*List<FolderHierarchy> FolderHierarchyList = findFolderHierarchy();
		List<DmsDocumentTree> treeList = new ArrayList<>();
		
//		List<String> parentFolderIdList = new ArrayList<>();
		for (FolderHierarchy folderHierarchy : FolderHierarchyList) {
			DmsDocumentTree tree = new  DmsDocumentTree();
			String folderID = folderHierarchy.getFolderID();
			String parentFolderID = folderHierarchy.getParentFolderID();
			String folderName = folderHierarchy.getFolderName();
			String formID = folderHierarchy.getFormID();
			tree.setFolderID(folderID);
			tree.setParentFolderID(parentFolderID);
			tree.setFolderName(folderName);
			tree.setType("0");
			tree.setFormID(formID);
			treeList.add(tree);
//			parentFolderIdList.add(parentFolderID);
		}
		for (Document documents : DocumentsList) {
			DmsDocumentTree tree = new  DmsDocumentTree();
			String documentId = documents.getDocID();
			String docParentFolderID = documents.getParentFolderID();
			String fileName = documents.getFileName();
			String formID = documents.getFormID();
			String URI = documents.getURI();
			tree.setFolderID(String.valueOf(documentId));
			tree.setParentFolderID(docParentFolderID);
			tree.setFolderName(fileName);
			tree.setType("1");
			tree.setFormID(formID);
			tree.setURI(URI);
			treeList.add(tree);
//			parentFolderIdList.add(docParentFolderID);
		}*/
		
		/*for (DmsDocumentTree dmsDocumentTree : treeList) {
			String parentFolderId = dmsDocumentTree.getParentFolderId();
			if(parentFolderId != null && !"".equals(parentFolderId)) {
				String folderId = dmsDocumentTree.getFolderId();
				if(parentFolderIdList.contains(parentFolderId)) {
				
					
					for (DmsDocumentTree dmsDocumentTree1 : treeList) {
						if(parentFolderId.equals(dmsDocumentTree1.getFolderId())) {
							List<DmsDocumentTree> children = dmsDocumentTree1.getChildren();
							if(children == null ) {
								List<DmsDocumentTree> children2 = new ArrayList<>();
								children2.add(dmsDocumentTree);
								dmsDocumentTree1.setChildren(children2);
							}else {
								children.add(dmsDocumentTree);
							}
							parentFolderIdList.remove(folderId);
						}
					}
				}
			}
		}
		for (int i = treeList.size()-1; i >=0; i--) {
			DmsDocumentTree dmsDocumentTree = treeList.get(i);
			if(dmsDocumentTree.getType()=="1" || "1".equals(dmsDocumentTree.getType())) {
				
				treeList.remove(i);
				continue;
			}
			if(dmsDocumentTree.getParentFolderId() != null && !"".equals(dmsDocumentTree.getParentFolderId())) {
				System.out.println(dmsDocumentTree.getFolderId() +" 's parentfolderId is "+ dmsDocumentTree.getParentFolderId() +"  remove!");
				treeList.remove(i);
				continue;
			}
			
		}*/
//		return DocumentsList;
//	}
//	
	/*@Override
	public List<DmsDocumentTree> searchFileHierarchy() {
		List<FolderHierarchy> FolderHierarchyList = findFolderHierarchy();
		List<Document> DocumentsList = findDocuments();
		List<DmsDocumentTree> treeList = new ArrayList<>();
		
		
		List<String> folderIDList = new ArrayList<>();
		for (FolderHierarchy folderHierarchy : FolderHierarchyList) {
			folderIDList.add(folderHierarchy.getFolderID());
		}
		
		DmsDocumentTree tree = new  DmsDocumentTree();
		
		List<DmsDocumentTree> recursiveQueryList = RecursiveQuery(folderIDList,FolderHierarchyList,treeList,tree);
		for (DmsDocumentTree recursiveQuery : recursiveQueryList) {
//			if(recursiveQuery.getParentFolderId()!=null) {
//				recursiveQueryList.remove(recursiveQuery);
//			}
			String folderId = recursiveQuery.getFolderId();
			List<DmsDocumentTree> children = recursiveQuery.getChildren();
			
			for (Documents documents : DocumentsList) {
				
				if(folderId.equals(documents.getFolderID())) {
					DmsDocumentTree doc = new DmsDocumentTree();
					doc.setURI(documents.getURI());
					doc.setFileName(documents.getFileName());
					children.add(doc);
					break;
				}
				if(children !=null) {
					querydocument(children,documents);
//					String childrenFolderId = children.getFolderId();
//					if(childrenFolderId.equals(documents.getFolderID())){
//						children.setURI(documents.getURI());
//						children.setFileName(documents.getFileName());
//					}
				}
			}
		}
		return recursiveQueryList;
	}*/
	
	/*public void querydocument(List<DmsDocumentTree>  children,Document documents) {
		for (DmsDocumentTree dmsDocumentTree : children) {
//			if("0".equals(dmsDocumentTree.getType())) {
				String childrenFolderId = dmsDocumentTree.getFolderID();
				List<DmsDocumentTree> children2 = dmsDocumentTree.getChildren();
				if(childrenFolderId.equals(documents.getFolderID())){
					DmsDocumentTree doc = new DmsDocumentTree();
					doc.setURI(documents.getURI());
					doc.setFileName(documents.getFileName());
					children2.add(doc);
					break;
				}
				if(children2 != null) {
					querydocument(children2,documents);
				}
//			}
		}
	}*/
/*
	public List<DmsDocumentTree> RecursiveQuery(List<String> folderIDList,List<DmsFolderHierarchy> FolderHierarchyList,List<DmsDocumentTree> treeList,DmsDocumentTree treeR) {
		
		for (DmsFolderHierarchy folderHierarchy : FolderHierarchyList) {
			
			if(folderIDList.contains(folderHierarchy.getFolderID())) {
				String folderID = folderHierarchy.getFolderID();
				String parentFolderID = folderHierarchy.getParentFolderID();
				String folderLevel = folderHierarchy.getFolderLevel();
				String folderName = folderHierarchy.getFolderName();
				String formID = folderHierarchy.getFormID();
				
				System.out.println("parentFolderID:"+parentFolderID+" folderID:"+folderID+" folderLevel:"+folderLevel+" folderName:"+folderName+" formID:"+formID);
				DmsDocumentTree tree= new DmsDocumentTree();
				if(parentFolderID != null && !"".equals(parentFolderID)) {
					
					for (DmsFolderHierarchy folderHierarchy1 : FolderHierarchyList) {
						DmsDocumentTree tree1= new DmsDocumentTree();
						if(parentFolderID.equals(folderHierarchy1.getFolderID())) {
							String parentFolderID1 = folderHierarchy1.getParentFolderID();
							String folderID1 = folderHierarchy1.getFolderID();
							String folderLevel1 = folderHierarchy1.getFolderLevel();
							String folderName1 = folderHierarchy1.getFolderName();
							String formID1 = folderHierarchy1.getFormID();
							tree.setFolderID(folderID);
							tree.setFolderName(folderName);
							tree.setFormID(formID);
							tree.setParentFolderID(parentFolderID);
							folderIDList.remove(folderID);
//							treeList.add(tree);
//							for (DmsDocumentTree dmsDocumentTree : treeList) {
//								System.out.println(dmsDocumentTree.toString());
//							}
							
							for (DmsDocumentTree dmsDocumentTree : treeList) {
								List<DmsDocumentTree> docChildrenTreeLiet= new ArrayList<DmsDocumentTree>();
								if(parentFolderID.equals(dmsDocumentTree.getFolderID())) {
									docChildrenTreeLiet.add(tree);
									dmsDocumentTree.setChildren(docChildrenTreeLiet);
									System.out.println(dmsDocumentTree.getFolderID()+" setChildren"+folderID);
//									System.out.println(dmsDocumentTree.toString());
//									folderIDList.remove(folderID);
									
								}
								if(dmsDocumentTree.getChildren()!=null && !"".equals(dmsDocumentTree)) {
									queryChildren(dmsDocumentTree,parentFolderID,tree);
								}
								if(folderIDList.contains(folderID1)) {
									tree1.setFolderID(folderID1);
									tree1.setFolderName(folderName1);
									tree1.setFormID(formID1);
									tree1.setParentFolderID(parentFolderID1);
									tree1.setChildren(docChildrenTreeLiet);
									folderIDList.remove(folderID1);
									treeList.add(tree1);
									
									if(parentFolderID1!= null && !"".equals(parentFolderID1)) {
										RecursiveQuery(folderIDList,FolderHierarchyList,treeList,tree1);
									}
								}
							}
						}
					}
				}else {
					tree.setFolderID(folderID);
					tree.setFolderName(folderName);
					tree.setFormID(formID);
					tree.setParentFolderID(parentFolderID);
					folderIDList.remove(folderID);
					treeList.add(tree);
				}
			}
		}
		
		return treeList;
	}*/
	
	/*public void queryChildren(DmsDocumentTree dmsDocumentTree,String parentFolderID,DmsDocumentTree tree) {
		if(dmsDocumentTree.getChildren()!=null) {
			List<DmsDocumentTree> childrenList = dmsDocumentTree.getChildren();
			List<DmsDocumentTree> newchildrenList = dmsDocumentTree.getChildren();
			for (DmsDocumentTree children : childrenList) {
				if(parentFolderID.equals(children.getFolderID())) {
					newchildrenList.add(tree);
					children.setChildren(newchildrenList);
					System.out.println(children.getFolderID()+" setChildren"+tree.getFolderID());
//					System.out.println(children.toString());
					continue;
				}	
				if(children.getChildren()!=null){
					queryChildren(children,parentFolderID,tree);
				}
				
			}
		}
	}*/
	

//	@Transactional
//	public static Map<String, Object> addDocToTreeList(List<Document> findDocumentsList,List<DmsDocumentTree> treeList,List<String>  formIDList){
//		Map<String, Object> map = new HashMap<String, Object>();
//		for (Document document : findDocumentsList) {
//			DmsDocumentTree tree = new  DmsDocumentTree();
//			formIDList.add(document.getFormID());
//			tree.setFolderName(document.getFileName());
//			tree.setFolderID(document.getDocID());
//			tree.setURI(document.getURI());
//			tree.setType("1");
//			tree.setParentFolderID(document.getFormRowID());
//			tree.setIsLeaf("Y");
//			treeList.add(tree);
//		}
//		map.put("treeList", treeList);
//		map.put("formIDList", formIDList);
//		return map;
//		
//	}
	

	@Transactional
	public List<DmsDocumentTree> findPolicyDocumentsTreeByKeyID(MasterFolder masterfolder) {
		String keyNumer = masterfolder.getKeyNumber();
		String keyID = masterfolder.getRowID();
		List<String>  resultList = new ArrayList<>();
		List<DmsDocumentTree> treeList = new ArrayList<>();
		 
		//get docID & formID &URI & DOCName List by policyNO
		List<String>  formIDList = new ArrayList<>();
		List<Document> findDocumentsList = dmsDocumentsMapper.findPolicyDocumentsByKeyID(keyID);
		for (Document document : findDocumentsList) {
			DmsDocumentTree tree = new  DmsDocumentTree();
			
			String fileName = document.getFileName();
			String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
			
			formIDList.add(document.getFormID());
			tree.setFolderName(fileName);
			tree.setFolderID(document.getDocID());
			tree.setURI(document.getURI());
			tree.setType("1");
			tree.setParentFolderID(document.getFormRowID());
			tree.setSuffix(suffix);
			tree.setIsLeaf("Y");
			tree.setIsForm("N");
			treeList.add(tree);
		}
		
//		Map<String, Object> treeListMap = addDocToTreeList(findDocumentsList,treeList,formIDList);
		log.info("1.find policy doc List by PolicyNo: "+treeList.toString());

		
		//get formHierarchy by formID
		List<String>  parentFolderIDList = new ArrayList<>();
		List<FolderHierarchy> formHierarchyList = formDefinitionMapper.findFormHierarchyByFormID(formIDList);
		
		 for (FolderHierarchy folderHierarchy : formHierarchyList) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderID = folderHierarchy.getFolderID();
			 String formID = folderHierarchy.getFormID();
			 String rowID = folderHierarchy.getRowID();
			 tree.setFolderName(formID);
			 tree.setParentFolderID(folderID);
			 tree.setType("0");
//			 tree.setFormId(formID);
			 tree.setFolderID(rowID);
			 tree.setIsLeaf("N");
			 tree.setIsForm("Y");
			 parentFolderIDList.add(folderID);
			 treeList.add(tree);
		}

		log.info("2.get formHierarchy by formID: "+parentFolderIDList.toString());
		
		//get  Folder List By parent folderID
		List<String>  parentFolderIDList1 = new ArrayList<>();
		List<FolderHierarchy> findFolderHierarchyByFolderID = formDefinitionMapper.findFolderHierarchyByFolderID(parentFolderIDList);
		for (FolderHierarchy folderHierarchy : findFolderHierarchyByFolderID) {
			parentFolderIDList1.add(folderHierarchy.getParentFolderID());
		}
		log.info("3.get Folder list by parentFolderID: "+parentFolderIDList1.toString());
		
		//get more parent Folder List By folderID
		List<String>  moreParent = new ArrayList<>();
		List<String>  findParent = new ArrayList<>();
		if(parentFolderIDList1.size() != 0) {
			moreParent = findParent(parentFolderIDList1,findParent);
		}
		log.info("4.get More Folder list by parentFolderID: "+moreParent.toString());
		
		//get result list
		resultList.addAll(parentFolderIDList);
		resultList.addAll(parentFolderIDList1);
		resultList.addAll(moreParent);
		log.info("5.Result List: "+resultList.toString());
		

		//get folder Hierarchy
		 List<FolderHierarchy> resultFolderHierarchyList = formDefinitionMapper.findFolderHierarchyByFolderID(resultList);
		 for (FolderHierarchy folderHierarchy : resultFolderHierarchyList) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderName = folderHierarchy.getFolderName();
			 String folderID = folderHierarchy.getFolderID();
			 String folderLevel = folderHierarchy.getFolderLevel();
			 tree.setParentFolderID(parentFolderID);
			 tree.setType("0");
			 tree.setFolderID(folderID);
			 tree.setIsLeaf("N");
			 tree.setIsForm("N");
			 if(folderLevel=="0" || "0".equals(folderLevel)) {
				 tree.setFolderName(keyNumer);
			 }
			 else{
				 tree.setFolderName(folderName);
			 }
			 treeList.add(tree);
		}

		return treeList;
	}

	private List<String> findParent(List<String> parentFolderIDList1, List<String> findParent) {
		if(parentFolderIDList1 ==null ) {
			return findParent;
		}
		log.info(parentFolderIDList1.toString());
		List<FolderHierarchy> leveMoreList = new ArrayList<>();
		leveMoreList = formDefinitionMapper.findFolderHierarchyByFolderID(parentFolderIDList1);
		List<String> newfolderIDList = new ArrayList<>();
		if(leveMoreList.size() !=0) {
			for (FolderHierarchy string : leveMoreList) {
				findParent.add(string.getParentFolderID());
				newfolderIDList.add(string.getParentFolderID());
				log.info("leve more folder:"+string.getFolderID());
			}
			findParent(newfolderIDList,findParent);
		}
		return findParent;
	}

	@Override
	public List<DocTemplete> findDocTemplete() {
		List<DocTemplete> docTempleteList = dmsDocumentsMapper.findDocTemplete();
		return docTempleteList;
	}
	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_CREATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO)
	@Override
	public boolean addPolicyDocument(Document document) {
		
		return dmsDocumentsMapper.addPolicyDocument(document);
	}

	@Override
	public boolean uploadNewVersion(DocControl docControl) {
		// TODO Auto-generated method stub
		return dmsDocumentsMapper.uploadNewVersion(docControl);
	}

	@Override
	public DocControl findOldVersionByDocID(String docID) {
		// TODO Auto-generated method stub
		return dmsDocumentsMapper.findOldVersionByDocID(docID);
	}

	@Override
	public boolean upatePolicyDocument(Document document) {
		// TODO Auto-generated method stub
		return dmsDocumentsMapper.upatePolicyDocument(document);
	}

	@Override
	public PageResult  findPolicyDocListByKeyID(PageRequest param) {
		Page<Object> startPage = PageUtils.startPage(param);
		String query = param.getPolicyNO();
		MasterFolder masterFolderByKeyNumber = dmsDocumentsMapper.getMasterFolderByKeyNumber(query);
		String keyID = masterFolderByKeyNumber.getRowID();
		List<Map<String, String>> findDocumentListByPolicyNO = dmsDocumentsMapper.findPolicyDocListByKeyID(keyID);
		PageResult pageResult= new PageResult();
		pageResult.setContent(findDocumentListByPolicyNO);
		pageResult.setTotalSize(startPage.getTotal());
		return pageResult;
	}

	@Transactional
	public List<DmsDocumentTree> findAgentDocumentsTreeByKeyID(MasterFolder masterfolder) {
		String keyID = masterfolder.getRowID();
		String keyNumer = masterfolder.getKeyNumber();
		String nric = masterfolder.getNIC();
		String encodeRules = masterfolder.getEncodeRules();
		
		String decryptedNIC = AESUtils.AESDncode(encodeRules, nric);
		List<String>  resultList = new ArrayList<>();
		List<DmsDocumentTree> treeList = new ArrayList<>();
		 
		//get docID & formID &URI & DOCName List by agentNo
		List<String>  formIDList = new ArrayList<>();
		List<Document> findDocumentsList = dmsDocumentsMapper.findAgentDocumentsByKeyID(keyID);
		for (Document document : findDocumentsList) {
			DmsDocumentTree tree = new  DmsDocumentTree();
			formIDList.add(document.getFormID());
			String fileName = document.getFileName();
			tree.setFolderName(document.getFileName());
			tree.setFolderID(document.getDocID());
			tree.setURI(document.getURI());
			tree.setType("1");
			tree.setParentFolderID(document.getFormRowID());
			String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
			tree.setSuffix(suffix);
			tree.setIsLeaf("Y");
			tree.setIsForm("N");
			treeList.add(tree);
		}
		
//		Map<String, Object> treeListMap = addDocToTreeList(findDocumentsList,treeList,formIDList);
		log.info("1.find policy doc List by PolicyNo: "+treeList.toString());

		
		//get formHierarchy by formID
		List<String>  parentFolderIDList = new ArrayList<>();
		List<FolderHierarchy> formHierarchyList = formDefinitionMapper.findFormHierarchyByFormID(formIDList);
		
		 for (FolderHierarchy folderHierarchy : formHierarchyList) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderID = folderHierarchy.getFolderID();
			 String formID = folderHierarchy.getFormID();
			 String rowID = folderHierarchy.getRowID();
			 tree.setFolderName(formID);
			 tree.setParentFolderID(folderID);
			 tree.setType("0");
//			 tree.setFormId(formID);
			 tree.setFolderID(rowID);
			 tree.setIsLeaf("N");
			 tree.setIsForm("Y");
			 parentFolderIDList.add(folderID);
			 treeList.add(tree);
		}

		log.info("2.get formHierarchy by formID: "+parentFolderIDList.toString());
		
		//get  Folder List By parent folderID
		List<String>  parentFolderIDList1 = new ArrayList<>();
		List<FolderHierarchy> findFolderHierarchyByFolderID = formDefinitionMapper.findFolderHierarchyByFolderID(parentFolderIDList);
		for (FolderHierarchy folderHierarchy : findFolderHierarchyByFolderID) {
			parentFolderIDList1.add(folderHierarchy.getParentFolderID());
		}
		log.info("3.get Folder list by parentFolderID: "+parentFolderIDList1.toString());
		
		//get more parent Folder List By folderID
		List<String>  moreParent = new ArrayList<>();
		List<String>  findParent = new ArrayList<>();
		if(parentFolderIDList1.size() != 0) {
			moreParent = findParent(parentFolderIDList1,findParent);
		}
		log.info("4.get More Folder list by parentFolderID: "+moreParent.toString());
		
		//get result list
		resultList.addAll(parentFolderIDList);
		resultList.addAll(parentFolderIDList1);
		resultList.addAll(moreParent);
		log.info("5.Result List: "+resultList.toString());
		

		//get folder Hierarchy
		 List<FolderHierarchy> resultFolderHierarchyList = formDefinitionMapper.findFolderHierarchyByFolderID(resultList);
		 for (FolderHierarchy folderHierarchy : resultFolderHierarchyList) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderName = folderHierarchy.getFolderName();
			 String folderID = folderHierarchy.getFolderID();
			 String folderLevel = folderHierarchy.getFolderLevel();
			 tree.setParentFolderID(parentFolderID);
			 tree.setType("0");
			 tree.setFolderID(folderID);
			 tree.setIsLeaf("N");
			 tree.setIsForm("N");
			 if(folderLevel=="0" || "0".equals(folderLevel)) {
				 if(keyNumer=="" || "".equals(keyNumer)) {
					 tree.setFolderName(decryptedNIC);
				 }else {
					 tree.setFolderName(keyNumer);
				 }
			 }
			 else{
				 tree.setFolderName(folderName);
			 }
			 treeList.add(tree);
		}

		return treeList;
	}
	

	@Override
	@Transactional
	public PageResult getAgentDocListByKeyID(PageRequest param) {
		
		PageResult pageResult= new PageResult();
		List<Map<String, String>>  lm = new ArrayList<Map<String, String>>();
		Map<String, String> m = new HashMap<>();
		
		Page<Object> startPage = PageUtils.startPage(param);
		String agentCode = param.getAgentCode();
		String nic = param.getNIC();
		
		MasterFolder masterFolderByKeyNumber = null;
		if(agentCode != null && !"".equals(agentCode)) {
			log.info("agentCode is not null: "+ agentCode);
			masterFolderByKeyNumber = dmsDocumentsMapper.getMasterFolderByKeyNumber(agentCode);
		}else{
			log.info("agentCode is null， search by NIC:"+nic);
			String searchValue = getEncryptedNIC(nic);
			masterFolderByKeyNumber = getMasterFolderBySearchValue(searchValue);
			
		}
		
		if(masterFolderByKeyNumber ==null) {
			m.put("content", "no record!");
			lm.add(m);
			pageResult.setContent(lm);
			pageResult.setTotalSize(startPage.getTotal());
			return pageResult;
		}
		
		String keyID = masterFolderByKeyNumber.getRowID();
		log.info("keyID:"+keyID);
		List<Map<String, String>> agentDocumentList = dmsDocumentsMapper.getAgentDocListByKeyID(keyID);
		log.info("get agentDocList by KeyID, agentDocumentList is null ?"+agentDocumentList.isEmpty());
		
		pageResult.setContent(agentDocumentList);
		pageResult.setTotalSize(startPage.getTotal());
		return pageResult;
		
	}

	@Override
	@Transactional
	public DocTemplete findDocTempleteByTempleteName(String docType) {
		return dmsDocumentsMapper.findDocTempleteByTempleteName(docType);
	}
	
	
	
	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_CREATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO)
	@Override
	@Transactional
	public boolean addAgentDocument(Document document) {
		return dmsDocumentsMapper.addAgentDocument(document);
	}
	
	
	
	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_CREATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO)
	@Override
	@Transactional
	public boolean addOtherDocument(Document document) {
		return dmsDocumentsMapper.addOtherDocument(document);
		
	}

	@Override
	@Transactional
	public boolean docReindexAgentDoc(Document document) {
		return dmsDocumentsMapper.docReindexAgentDoc(document);
		
	}

	@Override
	@Transactional
	public boolean docReindexOtherDoc(Document document) {
		return dmsDocumentsMapper.docReindexOtherDoc(document);
		
	}

	@Override
	@Transactional
	public boolean docReindexPolicyDoc(Document document) {
		return dmsDocumentsMapper.docReindexPolicyDoc(document);
		
	}

	@Override
	@Transactional
	public DocumentAgent getAgentDocProperties(String docID) {
		return dmsDocumentsMapper.getAgentDocProperties(docID);
	}

	@Override
	@Transactional
	public DocumentOther getOtherDocProperties(String docID) {
		return dmsDocumentsMapper.getOtherDocProperties(docID);
	}

	@Override
	@Transactional
	public DocumentPolicy getPolicyDocProperties(String docID) {
		return dmsDocumentsMapper.getPolicyDocProperties(docID);
	}

	@Override
	@Transactional
	public MasterFolder getMasterFolderByKeyNumber(String keyNumber) {
		return dmsDocumentsMapper.getMasterFolderByKeyNumber(keyNumber);
	}

	@Override
	@Transactional
	public List<DmsDocumentTree> getPolicyDocumentsTreeByKeyID(MasterFolder masterfolder) {
		List<DmsDocumentTree> DocumentsList = findPolicyDocumentsTreeByKeyID(masterfolder);
		return DocumentsList;
	}


	@Override
	@Transactional
	public List<DmsDocumentTree> getAgentDocumentsTreeByKeyID(MasterFolder masterfolder ) {
		List<DmsDocumentTree> DocumentsList = findAgentDocumentsTreeByKeyID(masterfolder);
		return DocumentsList;
	}


	@Override
	@Transactional
	public MasterFolder getMasterFolderBySearchValue(String searchValue) {
		return dmsDocumentsMapper.getMasterFolderBySearchValue(searchValue);
	}

	@Override
	@Transactional
	public String getEncryptedNIC(String nIC) {
		int hashCode = nIC.hashCode();
		String encryptedNIC = MD5Utils.getSaltMD5(String.valueOf(hashCode));
		return encryptedNIC;
	}

	@Override
	@Transactional
	public boolean addAgentCodeByNIC(String agentCode, String searchValue) {
		return dmsDocumentsMapper.addAgentCodeByNIC(agentCode,searchValue);
	}

	
	@Override
	@Transactional
	public boolean addMasterFolder(MasterFolder masterFolder) {
		return dmsDocumentsMapper.addMasterFolder(masterFolder);
		
	}
	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_UPLOAD_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO)
	@Override
	@Transactional
	public boolean uploadDocument(Document document) {
		try {
		String filePath = document.getFilePath();
		String formID = document.getFormID();
		String docType = document.getDocType();
		String policyNumber = document.getPolicyNO();
		String agentCode = document.getAgentCode();
		String nric = document.getNIC();
		log.info("docType======="+docType);
		
		/**
		 * 在上传document的时候，判断是ADMS还是LDMS，
		 * 要向tMasterFolder去检查是否保单或agent已经存在，
		 * 如果否，则创建新数据，如果存在，无需修改，直接插入document。
		 */
		String encryptedNIC = "";
		MasterFolder masterFolder = new MasterFolder();
		MasterFolder masterFolderResult = new MasterFolder();
		if(docType =="policy" || "policy".equals(docType)) {
			MasterFolder masterFolderByKeyNumber = getMasterFolderByKeyNumber(policyNumber);
			if(masterFolderByKeyNumber == null) {
				log.info("MasterFolder is null, set policyNO and keyType to MasterFolder");
				masterFolder.setKeyNumber(policyNumber);
				masterFolder.setKeyType("P");
				if(addMasterFolder(masterFolder)) {
					log.info("addMasterFolder success.");
				}else {
					log.info("addMasterFolder  failed.");
				}
			}else {
				masterFolderResult = getMasterFolderByKeyNumber(policyNumber);
			}
			
		}else if(docType =="agent" || "agent".equals(docType)) {
			encryptedNIC = getEncryptedNIC(nric);
			
			MasterFolder masterFolderBySearchValue = getMasterFolderBySearchValue(encryptedNIC);
			if(masterFolderBySearchValue == null) {
				masterFolder.setKeyNumber(agentCode);
				masterFolder.setKeyType("A");
				masterFolder.setSearchValue(encryptedNIC);
				
				String encodeRules=AESUtils.getRandomEncodeRules();
		        String encryptionResult = AESUtils.AESEncode(encodeRules, nric);
		        
		        masterFolder.setEncodeRules(encodeRules);
		        masterFolder.setNIC(encryptionResult);
				
		        if(addMasterFolder(masterFolder)) {
					log.info("addMasterFolder success.");
				}else {
					log.info("addMasterFolder  failed.");
				}
			}else {
				masterFolderResult = getMasterFolderBySearchValue(encryptedNIC);
			}
		}
		
		String keyID = masterFolderResult.getRowID();
		log.info("getMasterFolderBySearchValue keyID:"+keyID);
		
		DocControl docControl = new DocControl();	
//		Document document = new Document();
		File file = new File(filePath);
		String fileName = file.getName();
		document.setFileName(fileName);
		
		String docID = UUID.randomUUID().toString();
		
		docControl.setDocType(docType);
		docControl.setVersionNum("1");
		docControl.setDocID(docID);
		docControl.setFilePath(filePath);
		docControl.setFileSize(String.valueOf(file.length()));
		docControl.setDocName(fileName);
		String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
		docControl.setExtension(suffix);
		
		//upload to Azure container
		log.info("AzureApp storageConnectionString======="+storageConnectionString);
		AzureApp azureApp = new AzureApp(storageConnectionString); 
		DocTemplete findDocTemplete = findDocTempleteByTempleteName(docType);
		String containerID = findDocTemplete.getContainerID();
		Containers container = containerService.findContainerByID(containerID);
		String URI = azureApp.uploadFile(docID+"."+suffix,file,container.getContainerName());
		log.info("upload to Azure container."+container.getContainerName() +", file:"+file.getAbsolutePath());
					
		
		
		//insert to doc table
		document.setKeyID(keyID);
		document.setURI(URI);
		docControl.setURI(URI);
		document.setDocType(docType);
		document.setDocID(docID);
		document.setVersionNum("1");
		document.setFormID(formID);
		document.setContainerID(containerID);
		docControl.setContainerID(containerID);
		
		log.info("docType======="+docType);
		if (docType == null || "".equals(docType)) {
			addPolicyDocument(document); 
			log.info("insert to PolicyDoc table.");
		}else {
			docControl.setDocType(docType);
			document.setDocType(docType);
			if(docType == "policy" || "policy".equals(docType)) {
				addPolicyDocument(document); 
				log.info("insert to PolicyDoc table.");
			}else if(docType == "agent" || "agent".equals(docType)) {
				addAgentDocument(document); 
				log.info("insert to AgentDoc table.");
			}else {
				addOtherDocument(document); 
				log.info("insert to OtherDoc table.");
			}
		}
		//insert to doc versionControl table
		uploadNewVersion(docControl);
		log.info("insert to doc versionControl table.");
		}catch (Exception e) {
			log.error(e.toString());
			return false;
		}
		return true;
	}


	@Override
	public List<DmsDocumentTree> getPolicyDocumentTree(Document document) {
		log.info("getPolicyDocumentTree  policyNO:"+document.getPolicyNO());
		MasterFolder masterfolder = getMasterFolderByKeyNumber(document.getPolicyNO());
		List<DmsDocumentTree> policyDocumentTree = getPolicyDocumentsTreeByKeyID(masterfolder);
		return policyDocumentTree;
	}

	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_DELETE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO) 
	@Override
	public boolean physicallyDeleteDoc(Document document) {
		String docType = document.getDocType();
		String docID = document.getDocID();
		if(docType =="policy" || "policy".equals(docType)) {
			
			return dmsDocumentsMapper.physicallyDeletePolicyDoc(docID);
		}else if(docType =="agent" || "agent".equals(docType)) {
			
			return dmsDocumentsMapper.physicallyDeleteAgentDoc(docID);
		}
		return dmsDocumentsMapper.physicallyDeletePolicyDoc(docID);
	}

	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_DOC_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_DELETE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_DOC_POJO) 
	@Override
	public boolean LogicDeleteDoc(Document document) {
		String docType = document.getDocType();
		String docID = document.getDocID();
		if(docType =="policy" || "policy".equals(docType)) {
			
			return dmsDocumentsMapper.LogicDeletePolicyDoc(docID);
		}else if(docType =="agent" || "agent".equals(docType)) {
			
			return dmsDocumentsMapper.LogicDeleteAgentDoc(docID);
		}
		return dmsDocumentsMapper.LogicDeletePolicyDoc(docID);
	}



	

}
