package com.example.azure.storage.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.azure.storage.model.DocControl;
import com.example.azure.storage.model.DocTemplete;
import com.example.azure.storage.model.Document;
import com.example.azure.storage.model.DocumentAgent;
import com.example.azure.storage.model.DocumentOther;
import com.example.azure.storage.model.DocumentPolicy;
import com.example.azure.storage.model.MasterFolder;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;

@Mapper
public interface DocumentsMapper {

	public List<Object> getFileList(Object object);
	
	public boolean uploadFileList(List<String> list);
	
	
	public List<DocTemplete> findDocTemplete();
	
	public List<Document> findPolicyDocuments();
	
	public List<Document> findAgentDocuments();
	
	public List<Document> findOtherDocuments();
	
	boolean addPolicyDocument(Document document);
	
	boolean uploadNewVersion(DocControl docControl);
	
	public DocControl findOldVersionByDocID(String docID);
	
	boolean upatePolicyDocument(Document document);

//	public List<Document> findPolicyDocumentsByPolicyNo(String policyNo);

	public List<Map<String, String>> findPolicyDocListByKeyID(String keyID);

//	public List<Document> findAgentDocumentsByAgentNo(String agentNo);

	public List<Map<String, String>> getAgentDocListByKeyID(String keyID);

	public DocTemplete findDocTempleteByTempleteName(@Param("templateName")String docType);

	public boolean addAgentDocument(Document document);

	public boolean addOtherDocument(Document document);

	public boolean docReindexAgentDoc(Document document);

	public boolean docReindexOtherDoc(Document document);

	public boolean docReindexPolicyDoc(Document document);

	public DocumentAgent getAgentDocProperties(String docID);

	public DocumentOther getOtherDocProperties(String docID);

	public DocumentPolicy getPolicyDocProperties(String docID);

	public MasterFolder getMasterFolderByKeyNumber(@Param("query")String query);

	public List<Document> findPolicyDocumentsByKeyID(String keyID);

	public List<Document> findAgentDocumentsByKeyID(String keyID);


	public MasterFolder getMasterFolderBySearchValue(@Param("searchValue")String searchValue);

	public boolean addAgentCodeByNIC(@Param("agentCode")String agentCode, @Param("searchValue")String searchValue);

	public boolean addMasterFolder(MasterFolder masterFolder);

	public boolean physicallyDeletePolicyDoc(String docID);

	public boolean physicallyDeleteAgentDoc(String docID);

	public boolean LogicDeletePolicyDoc(String docID);

	public boolean LogicDeleteAgentDoc(String docID);
	public String getAgentDocName(String docID);
	public String getOtherDocName(String docID);
	public String getPolicyDocName(String docID);
	
	
}
