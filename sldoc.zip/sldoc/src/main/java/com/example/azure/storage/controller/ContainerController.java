package com.example.azure.storage.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.azure.storage.common.JsonResult;
import com.example.azure.storage.enumeration.GlobalEnum;
import com.example.azure.storage.service.ContainerService;
import com.example.azure.storage.service.DmsDocumentsService;
import com.example.azure.storage.util.JsonUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/Container")
public class ContainerController {

	
	@Autowired
	private DmsDocumentsService dmsDocumentsService;
	
	@Autowired
	private ContainerService containerService;
	
	@GetMapping("/createContainer/{containerName}")
	public JsonResult createContainer(@PathVariable String containerName) {
		if(containerService.createContainer(containerName)) {
			log.info("create Container "+containerName+" success");
			return JsonUtils.success("createContainer SUCCESS");
		}
		return JsonUtils.failed("create Container "+containerName+" failed");
	}
	
	@GetMapping("/getContainerList")
	public JsonResult<List<String>> getContainerList() {
		log.info("getContainerList start");
		List<String> findContainerList = containerService.findContainerList();
		log.info("getContainerList end");
		return JsonUtils.success("getContainerList SUCCESS",findContainerList);
	}
	
	@GetMapping("/deleteContainer/{containerName}")
	public JsonResult deleteContainer(String containerName) {
		System.out.println(containerName);
		if(containerService.deleteContainer(containerName)) {
			return JsonUtils.success("deleteContainer SUCCESS");
		}
		return JsonUtils.failed("delete Container "+containerName+" failed");
	}
	/*
	public JsonResult<String> downloadFileByFileName(@PathVariable List<String> fileName,String containerName) throws IOException {
		 String downloadFile = dmsDocumentsService.downloadFile(fileName,containerName);
		 return JsonUtils.success("downloadFileByFileName SUCCESS",downloadFile);
	}

	public JsonResult<List<String>> uploadFile(String filePath,String containerName) throws IOException {
		List<String> uploadFileList = dmsDocumentsService.uploadFileList(filePath,containerName);
		return JsonUtils.success("uploadFile SUCCESS",uploadFileList);
	}*/
	
	
	
	
	/*@GetMapping(value = "/readBoloFileList")
	public String readBlobFileList() throws IOException {

		return "";
	}

	@PostMapping(value = "/writeBoloFileList")
	public String writeBlobFileList(@RequestBody List<String> datalist) throws IOException {

		return "File was updated.\n";
	}*/
}
