package com.example.azure.storage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.example.azure.storage.common.JsonResult;
import com.example.azure.storage.enumeration.GlobalEnum;
import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.model.FormHierarchy;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;
import com.example.azure.storage.service.FormDefinitionService;
import com.example.azure.storage.util.JsonUtils;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/form")
public class FormDefinitionController {

	@Autowired
	private FormDefinitionService dmsFormDefinitionService;
	
	@ApiOperation(value="")
	@PostMapping("/getFormList")
	@ResponseBody
	public PageResult getFormList(@RequestBody PageRequest param) {
		
		 PageResult findPage = dmsFormDefinitionService.findPage(param);
		 return findPage;
//		 return JsonUtils.success(JSONObject.toJSON(findPage));
	}
	
	@PostMapping("/addFormDefinition")
	@ResponseBody
	public JsonResult<FormDefinition> addFormDefinition(@RequestBody FormDefinition param) {
		if(dmsFormDefinitionService.addFormDefinition(param)){
			System.out.println("addFormDefinition"+param.getFormID()+" success." );
		}
		FormDefinition dmsFormDefinition =dmsFormDefinitionService.findFormDefinitionByFormID(param.getFormID());
		return JsonUtils.success("SUCCESS",dmsFormDefinition);
		
	}
	
	
	@PostMapping("/editFormDefinition")
	@ResponseBody
	public JsonResult editFormDefinition(@RequestBody FormDefinition param) {
		if(dmsFormDefinitionService.editFormDefinition(param)) {
			
			return JsonUtils.success("editFormDefinition SUCCESS");
		}
		return JsonUtils.failed("editFormDefinition FAILED");
		
	}
	
	
	@GetMapping("/delFormDefinition/{formDefinitionId}")
	public JsonResult delFormDefinition(@PathVariable String formDefinitionId) {
		if(dmsFormDefinitionService.delFormDefinition(formDefinitionId)) {
			
			return JsonUtils.success("delFormDefinition SUCCESS");
		}
		return JsonUtils.failed("delFormDefinition FAILED");
		
	}
	
	@GetMapping("/getFormDefinitionByFormID/{formID}")
	public JsonResult<FormDefinition> getFormDefinitionByFormID(@PathVariable String formID) {
		FormDefinition dmsFormDefinition =dmsFormDefinitionService.findFormDefinitionByFormID(formID);
		return JsonUtils.success("dmsFormDefinition SUCCESS");
		
	}
	
//	@GetMapping("/getFormDefinitionByID/{formDefinitionId}")
//	public String getFormDefinitionByID(@PathVariable String formDefinitionId) {
//		FormDefinition dmsFormDefinition =dmsFormDefinitionService.findFormDefinitionByID(formDefinitionId);
//		return JsonUtils.success(JSONObject.toJSON(dmsFormDefinition));
//		
//	}
	
	
	
	@GetMapping("/getFileHierarchy/{formType}")
	public JsonResult<List<DmsDocumentTree>> getFileHierarchy(@PathVariable String formType) {
		List<DmsDocumentTree> searchFileHierarchy = dmsFormDefinitionService.findFormHierarchy(formType);
		return JsonUtils.success("getFileHierarchy SUCCESS",searchFileHierarchy);
		
	}
	
	@PostMapping("/addFileHierarchyFolder")
	@ResponseBody
	public JsonResult addFolderHierarchyFolder(@RequestBody FolderHierarchy folderHierarchy) {
		String folderName = folderHierarchy.getFolderName();
		String parentFolderID = folderHierarchy.getParentFolderID();
		if(folderName == null || "".equals(folderName)) {
			return JsonUtils.failed("folderName is blank.");
		}
		if(parentFolderID == null || "".equals(parentFolderID)) {
			return JsonUtils.failed("parentFolderID is empty");
		}
		if(dmsFormDefinitionService.addFileHierarchyFolder(folderName,parentFolderID)){
			System.out.println("addFileHierarchyFolder："+folderName+" success." );
		}
		return JsonUtils.success("addFolderHierarchyFolder SUCCESS");
		
		
	}
	
	@PostMapping("/editFileHierarchyFolder")
	@ResponseBody
	public JsonResult editFileHierarchyFolder(@RequestBody FolderHierarchy folderHierarchy) {
		String folderName = folderHierarchy.getFolderName();
		String folderID = folderHierarchy.getFolderID();
		if(folderName == null || "".equals(folderName)) {
			return JsonUtils.failed("folderName is blank.");
		}
		if(folderID == null || "".equals(folderID)) {
			return JsonUtils.failed("folderID is blank.");
		}
		if(dmsFormDefinitionService.editFileHierarchyFolder(folderHierarchy.getFolderID(),folderHierarchy.getFolderName())){
			System.out.println("editFileHierarchyFolder："+folderName+" success." );
			return JsonUtils.success("editFileHierarchyFolder SUCCESS");
		}
		return JsonUtils.failed("unknow error.");
	}
	
	@GetMapping("/delFileHierarchyFolder/{folderID}")
	public JsonResult delFileHierarchyFolder(@PathVariable String folderID) {
		if(dmsFormDefinitionService.delFileHierarchyFolder(folderID)){
			System.out.println("delFileHierarchyFolder："+folderID+" success." );
		}
		return JsonUtils.success("delFileHierarchyFolder SUCCESS");
		
		
	}
	
	@GetMapping("/getUnassignedForm")
	public JsonResult<List<FormDefinition>> getUnassignedForm() {
		List<FormDefinition> formDefinition = dmsFormDefinitionService.getFormDefinition();
		
		return JsonUtils.success("getUnassignedForm SUCCESS",formDefinition);
	}
	
	@GetMapping("/getAssignedForm")
	public JsonResult<List<FormDefinition>> getAssignedForm() {
		List<FormDefinition> formDefinition = dmsFormDefinitionService.getAssignedForm();
		
		return JsonUtils.success("getAssignedForm SUCCESS",formDefinition);
	}
	
	@PostMapping("/addFileHierarchyForm")
	@ResponseBody
	public JsonResult addFileHierarchyForm(@RequestBody FormHierarchy formHierarchy) {
		String folderID = formHierarchy.getFolderID();
		String formID = formHierarchy.getFormID();
		
		if(folderID == null || "".equals(folderID)) {
			return JsonUtils.failed("folderName is blank.");
		}
		if(formID == null || "".equals(formID)) {
			return JsonUtils.failed("formID is blank");
		}
		if(dmsFormDefinitionService.addFileHierarchyForm(folderID,formID)){
			System.out.println("addFileHierarchyForm："+formID+" success." );
		}
		return JsonUtils.success("addFileHierarchyForm SUCCESS");
		
		
	}


	@PostMapping("/editFileHierarchyForm")
	@ResponseBody
	public JsonResult editFileHierarchyForm(@RequestBody FormHierarchy formHierarchy) {
		String newFormID = formHierarchy.getNewFormID();
		String formID = formHierarchy.getFormID();
		if(newFormID == null || "".equals(newFormID)) {
			return JsonUtils.failed("newFormID is blank.");
		}
		if(formID == null || "".equals(formID)) {
			return JsonUtils.failed("formID is blank.");
		}
		if(dmsFormDefinitionService.editFileHierarchyForm(newFormID,formID)){
			System.out.println("editFileHierarchyForm："+formID+" success." );
			return JsonUtils.success("SUCCESS");
		}
		return JsonUtils.failed("unknow error.");
		
	}
	
	@GetMapping("/delFileHierarchyForm/{formID}")
	public JsonResult delFileHierarchyForm(@PathVariable String formID) {
		if(dmsFormDefinitionService.delFileHierarchyForm(formID)){
			System.out.println("delFileHierarchyForm："+formID+" success." );
			return JsonUtils.success("delFileHierarchyForm SUCCESS");
		}
		return JsonUtils.failed("delFileHierarchyForm failed");
		
	}
	
	
	
}
