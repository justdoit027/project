package com.example.azure.storage.model;

import lombok.Data;

@Data
public class StorageConfig {

	private String rowID;		//	[ROWID]
	private String storageAccountName;//  ,[STORAGE_ACCOUNT_NAME]
	private String key1;	    //  ,[KEY1]
	private String connectionString1;	    //  ,[CONNECTION_STRING1]
	private String key2;	    //  ,[KEY2]
	private String connectionString2;	    //  ,[CONNECTION_STRING2]
	private String account;	    //  ,[ACCOUNT]
	private String createdDate;	    //  ,[CREATED_DATE]
	private String updatedDate;	    //  ,[UPDATED_DATE]
	private String isDeleted;	    //  ,[IS_DELETED]
	
	
}
