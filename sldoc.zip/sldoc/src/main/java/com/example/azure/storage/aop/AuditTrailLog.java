package com.example.azure.storage.aop;

import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME) 
@Documented 
public @interface  AuditTrailLog {
	 String category() default "";
	 String action() default "";
	 String paramType()default "";
}
