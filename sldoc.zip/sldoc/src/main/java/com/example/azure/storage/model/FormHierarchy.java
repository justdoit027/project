package com.example.azure.storage.model;

import lombok.Data;

@Data
public class FormHierarchy {

	private String rowID;	//			[ROWID]
	private String folderID;	      //,[FOLDER_ID]
	private String formID;	      //,[FORM_ID]
	private String createdDate;	      //,[CREATED_DATE]
	private String updatedDate;	      //,[UPDATED_DATE]
	private String isDeleted;	      //,[IS_DELETED]
	
	private String newFormID;	
}
