package com.example.azure.storage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.azure.storage.mapper.AuditTrailMapper;
import com.example.azure.storage.model.AuditTrail;
import com.example.azure.storage.service.AuditTrailService;
@Service
public class AuditTrailServiceImpl implements AuditTrailService{
	
	@Autowired
	private AuditTrailMapper auditTrailMapper;
	@Override
	public List<AuditTrail> getDocAuditTrailList(String docId) {
		
		return auditTrailMapper.getDocAuditTrailList(docId);
	}
	@Override
	public List<AuditTrail> getFormAuditTrailList(String fromId) {
		
		return auditTrailMapper.getFormAuditTrailList(fromId);
	}
	@Override
	public void addFormAuditTrail(AuditTrail auditTrail) {
		auditTrailMapper.addFormAuditTrail(auditTrail);
	}
	@Override
	public void addDocAuditTrail(AuditTrail auditTrail) {
		auditTrailMapper.addDocAuditTrail(auditTrail);
	}

}
