package com.example.azure.storage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.azure.storage.common.JsonResult;
import com.example.azure.storage.model.AuditTrail;
import com.example.azure.storage.service.AuditTrailService;
import com.example.azure.storage.util.JsonUtils;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/audit")
@Slf4j
public class DocAuditController {
	@Autowired
	private AuditTrailService auditTrailService;

	@ApiOperation(value = "For External Systems")
	@GetMapping(value = "/getDocAuditTrail/{documentId}", produces = "application/json;charset=UTF-8")
	public JsonResult getDocAuditTrail(@PathVariable(value = "documentId") String docId) {
		List<AuditTrail> list = auditTrailService.getDocAuditTrailList(docId);
		return JsonUtils.success("suc", list);
	}

	@ApiOperation(value = "For External Systems")
	@GetMapping(value = "/getFormAuditTrail/{formId}", produces = "application/json;charset=UTF-8")
	public JsonResult getFormAuditTrail(@PathVariable(value = "formId") String formId) {
		List<AuditTrail> list = auditTrailService.getFormAuditTrailList(formId);
		return JsonUtils.success("suc", list);
	}

}
