package com.example.azure.storage.aop;

import java.lang.reflect.Method;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.alibaba.fastjson.JSON;
import com.example.azure.storage.common.FunctionTypeValue;
import com.example.azure.storage.mapper.DocumentsMapper;
import com.example.azure.storage.mapper.FormDefinitionMapper;
import com.example.azure.storage.model.AuditTrail;
import com.example.azure.storage.model.Document;
import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.service.AuditTrailService;
@Aspect
@Component
public class AuditTrailAspect {
	private static Logger logger = LoggerFactory.getLogger(AuditTrailAspect.class);
	@Autowired
	AuditTrailService auditTrailService;
	@Autowired
	private DocumentsMapper documentsMapper;
	@Autowired
	private FormDefinitionMapper formDefinitionMapper;
	
    @Pointcut("@annotation(com.example.azure.storage.aop.AuditTrailLog)")
    public void logPoinCut() {
    }
 
    @AfterReturning(returning="rvt", pointcut="logPoinCut()")
    public void saveAuditTrail(JoinPoint joinPoint ,Object rvt) {
    	logger.info("aspect start ...");
        AuditTrail auditTrail = new AuditTrail();
 
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        
        Method method = signature.getMethod();
        String className = joinPoint.getTarget().getClass().getName();
        String methodName = method.getName();
        auditTrail.setFunctionName( className + "." + methodName );
        Object[] args = joinPoint.getArgs();
        String requestBody = JSON.toJSONString(args);
        auditTrail.setRequestBody( requestBody );
        AuditTrailLog myLog = method.getAnnotation(AuditTrailLog.class);
        auditTrail.setCreateBy("system");
        if (myLog != null) {
            auditTrail.setAction( myLog.action() );
            auditTrail.setCategory( myLog.category() );
            doAuditTrail(myLog.paramType(), args[0], auditTrail,myLog.action());
        }
        logger.info(JSON.toJSONString(auditTrail));
       
        logger.info("aspect end ...");
    }

	private void doAuditTrail(String paramType, Object object,AuditTrail auditTrail,String actionDesc) {
		 Document document = new Document();
		if (FunctionTypeValue.FUNCTIONLIST_DOC_POJO.equals(paramType)) {
			document = (Document) object;
			String docType=document.getDocType();
			String docID=document.getDocID();
			String docName=document.getDocID();
			if("".equals(docType) || docType == null) {
				//throws Exception
			}
			if("agent".equals(docType)) {
				docName= documentsMapper.getAgentDocName(docID);
			}else if ("other".equals(docType)) {
				docName = documentsMapper.getOtherDocName(docID);
			}else{
				docName= documentsMapper.getPolicyDocName(docID);
			}
          	auditTrail.setActionDesc(actionDesc+", DocumentName:"+docName);	
          	auditTrail.setDocID(docID);
          	auditTrailService.addDocAuditTrail(auditTrail);
			}else if (FunctionTypeValue.FUNCTIONLIST_FORM_POJO.equals(paramType)) {
				FormDefinition formDefinition = (FormDefinition) object; 
				String formDefinitionId = formDefinition.getFormID();
				String formName=formDefinitionMapper.getFormName(formDefinitionId);
				auditTrail.setFormDefinitionId(formDefinitionId);
				auditTrail.setActionDesc(actionDesc+", FormName:"+formName);
				auditTrailService.addFormAuditTrail(auditTrail);
			}else if(FunctionTypeValue.FUNCTIONLIST_FORM_STR.equals(paramType)){
				String formDefinitionId = (String) object;
				String formName=formDefinitionMapper.getFormName(formDefinitionId);
				auditTrail.setFormDefinitionId(formDefinitionId);
				auditTrail.setActionDesc(actionDesc+", FormName:"+formName);
				auditTrailService.addFormAuditTrail(auditTrail);
			}else if(FunctionTypeValue.FUNCTIONLIST_DOC_STR.equals(paramType)){
				String docId = (String) object;
				String docName= documentsMapper.getPolicyDocName(docId);
				auditTrail.setDocID(docId);
				auditTrail.setActionDesc(actionDesc+", DocumentName:"+docName);
				auditTrailService.addDocAuditTrail(auditTrail);
			}
				
		
	}
	
}
