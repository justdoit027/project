package com.example.azure.storage.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.azure.storage.model.Containers;

@Mapper
public interface ContainersMapper {

	public Containers findContainerByID(String ContainerID);
}
