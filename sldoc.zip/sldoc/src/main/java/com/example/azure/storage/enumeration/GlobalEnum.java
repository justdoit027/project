package com.example.azure.storage.enumeration;

public enum GlobalEnum {

	SUCCESS,
	FAILED
	
}
