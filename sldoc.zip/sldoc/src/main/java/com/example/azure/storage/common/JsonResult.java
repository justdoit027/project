package com.example.azure.storage.common;

import java.io.Serializable;
import java.util.Map;

import com.example.azure.storage.enumeration.GlobalEnum;

public class JsonResult<T> implements Serializable{
	
	private static final long serialVersionUID = 9211889136173018364L;
	
	private String code;
	private String message;
	private Object data;


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public Object getData() {
		return data;
	}


	public void setData(Object data) {
		this.data = data;
	}
	
	public static <T> JsonResult<T> retSuccess(String message) {
		JsonResult<T> response = new JsonResult<T>();
		response.setCode("200");
		response.setMessage(message);
		return response;
	}
	public static <T> JsonResult<T> retSuccess(String message,Object data) {
		JsonResult<T> response = new JsonResult<T>();
		response.setCode("200");
		response.setData(data);
		response.setMessage(message);
		return response;
	}

	public static <T> JsonResult<T> retFailed(String message) {
		JsonResult<T> response = new JsonResult<T>();
		response.setCode("500");
		response.setMessage(message);
		return response;
	}
	public static <T> JsonResult<T> retFailed(String message, Object data) {
		JsonResult<T> response = new JsonResult<T>();
		response.setCode("500");
		response.setData(data);
		response.setMessage(message);
		return response;
	}
	
}
