package com.example.azure.storage.model;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class AuditTrail {
	private BigDecimal rowId;   //	[ROW_ID]
	private String action;      //	[ACTION]
	private String actionDesc;      //	[ACTION_DESC]
	private Date createDate;// ,[CREATED_DATE]
	private String createBy;// ,[CREATED_BY]
	private String functionName;// ,[FUNCTION_NAME]
	private String requestBody;// ,[REQUEST_BODY]
	private String category;// ,[CATEGORY]
	private String docID;		//	[DOC_ID]
	private String formDefinitionId;		//	[FORM_ID]
}
