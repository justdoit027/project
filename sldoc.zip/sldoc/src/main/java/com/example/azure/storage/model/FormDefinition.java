package com.example.azure.storage.model;

import lombok.Data;

@Data
public class FormDefinition {

	private String formDefinitionId;			// [ROWID]
	private String formID;	    	// [FORM_ID]
	private String formName;	    // [FORM_NM]
	private String formCategory;	// [FORM_CATEGORY]
	private String categoryCode;	// [CATEGORY_CODE]
	private String isValid;	    	// [IS_VALID]
	private String formLevel;	    // [FORM_LEVEL]
	private String department;	    // [DEPARTMENT]
	private String createdDate;		//[CREATED_DATE]
	private String updatedDate;		//[UPDATED_DATE]
	private String isTriggerForm;	//[IS_TRIGGER_FORM]
	private String isVisible;	    // [IS_VISIBLE]
	private String isDeleted;	    // [IS_DELETED]
	
    private Integer pageNum;
    private Integer pageSize;
}
