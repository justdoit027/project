package com.example.azure.storage.model;

import lombok.Data;

@Data
public class Containers {
	 private String ContainerID;		//	[ROWID]
	 private String containerName;	    //  ,[CONTAINER_NAME]
	 private String containerType;	    //  ,[CONTAINER_TYPE]
	 private String accessLevel;	    // ,[ACCESS_LEVEL]
	 private String storageAccountName;	    //  ,[STORAGE_ACCOUNT_NAME]
	 private String createdDate;	    //  ,[CREATED_DATE]
	 private String updatedDate;    	//  ,[UPDATED_DATE]
	 private String isDeleted;	    //  ,[IS_DELETED]
	 private String URL;	    //  ,[URL]
	
}
