package com.example.azure.storage.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DmsFormDefinition extends PageRequest{
	
	
	private String formCategory;	// [FORM_CATEGORY]
	private String formID;	    	// [FORM_ID]
	private String formName;	    // [FORM_NM]
	private String formDefinitionId;			// [ROWID]
	private String categoryCode;	// [CATEGORY_CODE]
	private String isValid;	    	// [IS_VALID]
	private String formLevel;	    // [FORM_LEVEL]
	private String isTriggerForm;	// [IS_TRIGGER_FORM]
	private String isVisible;	    // [IS_VISIBLE]
	private String isDeleted;	    // [IS_DELETED]
	private String department;	    // [DEPARTMENT]
	
	
}
