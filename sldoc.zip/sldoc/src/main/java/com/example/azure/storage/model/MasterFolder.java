package com.example.azure.storage.model;

import lombok.Data;

@Data
public class MasterFolder {

	private String rowID; //ROWID
	private String keyType; //KEY_TYPE
	private String keyNumber; //KEY_NUMBER
	private String NIC; //NIC
	private String searchValue; //SEARCH_VALUE
	private String encodeRules; //ENCODE_RULES
	private String createdDate; //CREATED_DATE
	private String updatedDate; //UPDATED_DATE
	private String isDeleted;	//IS_DELETED
}
