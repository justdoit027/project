package com.example.azure.storage.util;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.StringJoiner;

import org.springframework.beans.factory.annotation.Value;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageCredentials;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.BlobContainerPermissions;
import com.microsoft.azure.storage.blob.BlobContainerPublicAccessType;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.SharedAccessBlobPermissions;
import com.microsoft.azure.storage.blob.SharedAccessBlobPolicy;


public class StorageAccessStrategy {

	@Value("${storageConnectionString}")
	private String storageConnectionString;
	
	
	//SetPublicContainerPermissions
	public void SetPublicContainerPermissions (CloudBlobContainer container) {
		try {
			BlobContainerPermissions permissions = container.downloadPermissions();
			permissions.setPublicAccess(BlobContainerPublicAccessType.CONTAINER);
			container.uploadPermissions(permissions);
			
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	
	public void SharedAccessPolicies(CloudBlobContainer blobContainer,String read,String write,String delete,String list) {
		try {
//		CloudStorageAccount storageAccount = CloudStorageAccount.parse(storageConnectionString);
//		
//		CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//		CloudBlobContainer blobContainer;
//			blobContainer = blobClient.getContainerReference("mycontainer");
		
		blobContainer.createIfNotExists();

		BlobContainerPermissions blobPermissions = new BlobContainerPermissions();
		blobPermissions.setPublicAccess(BlobContainerPublicAccessType.OFF);
//		blobPermissions = BlobContainerPublicAccessType.OFF;

		HashMap<String, SharedAccessBlobPolicy> myPolicyMap = new HashMap<String,SharedAccessBlobPolicy>();
		SharedAccessBlobPolicy myPolicy =new SharedAccessBlobPolicy();
		//Create permissions according to what you selected
//		SharedAccessBlobPermissions permissions = SharedAccessBlobPermissions.CREATE;
//		permissions = SharedAccessBlobPermissions.READ;
//		permissions = SharedAccessBlobPermissions.WRITE;
//		permissions = SharedAccessBlobPermissions.DELETE;
//		permissions = SharedAccessBlobPermissions.LIST;
//		SharedAccessBlobPermissions s = SharedAccessBlobPermissions.ADD;
		EnumSet<SharedAccessBlobPermissions> enumSharedAccessBlobPermissions = null;
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.CREATE);
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.READ);
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.WRITE);
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.DELETE);
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.LIST);
		enumSharedAccessBlobPermissions.add(SharedAccessBlobPermissions.ADD);
		myPolicy.setPermissions(enumSharedAccessBlobPermissions);
		
//		myPolicy.Permissions = permissions;
		Date startTime = new Date(); 
		Date endTime = new Date(); 
		myPolicy.setSharedAccessStartTime(startTime);
		myPolicy.setSharedAccessExpiryTime(endTime);
//		    SharedAccessStartTime = DateTimeOffset.UtcNow.AddSeconds(accessStartSeconds);
//		    myPolicy.SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddSeconds(accessExpirySeconds);

		//Add the policy to Blob permissions' SharedAccessPolicies
		//You can add more than one policy
		myPolicyMap.put("mypolicy", myPolicy);
		blobPermissions.setSharedAccessPolicies(myPolicyMap);
//		SharedAccessPolicies.Add("mypolicy", myPolicy);

		//Set the container's permissions
		blobContainer.uploadPermissions(blobPermissions);

		/**
		 // 0 onwer;  
		  * 1 admin; (Read-write-list-delete)
		  * 2 Read-only user; 
		  * 3 Read-write user;
		  * 4 Read-write-list user
		  * 
		 */
//		String groupPolicyIdentifier = null;

		//Get the Signature of "mypolicy"
//		String sasToken = blobContainer.generateSharedAccessSignature(myPolicy, groupPolicyIdentifier);
//				GetSharedAccessSignature(myPolicy);
//		Signature.Text = sasToken;
		
//		} catch (InvalidKeyException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (URISyntaxException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
		catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
