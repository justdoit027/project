package com.example.azure.storage.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.example.azure.storage.common.JsonResult;
import com.example.azure.storage.enumeration.GlobalEnum;
import com.example.azure.storage.model.Containers;
import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.DocControl;
import com.example.azure.storage.model.DocTemplete;
import com.example.azure.storage.model.Document;
import com.example.azure.storage.model.DocumentAgent;
import com.example.azure.storage.model.DocumentOther;
import com.example.azure.storage.model.DocumentPolicy;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.MasterFolder;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;
import com.example.azure.storage.service.ContainerService;
import com.example.azure.storage.service.DmsDocumentsService;
import com.example.azure.storage.util.AESUtils;
import com.example.azure.storage.util.AzureApp;
import com.example.azure.storage.util.JsonUtils;

import io.swagger.annotations.ApiOperation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import lombok.extern.slf4j.Slf4j;
import sun.tools.jar.resources.jar;
import sun.util.logging.resources.logging;

@RestController
@RequestMapping("/document")
@Slf4j
public class DocumentController {

	@Value("${storageConnectionString}")
	private String storageConnectionString;

	@Autowired
	private DmsDocumentsService dmsDocumentsService;

	@ApiOperation(value = "For External Systems")
	@PostMapping("/updateDocument")
	@ResponseBody
	public JsonResult updateDocument(@RequestBody Document document) {
		dmsDocumentsService.updateDocument(document);
		log.info("upload to doc versionControl table.");
		return JsonUtils.success("updateDocument SUCCESS");

	}

	@ApiOperation(value = "For External Systems")
	@PostMapping("/uploadDocument")
	@ResponseBody
	public JsonResult uploadDocument(@RequestBody Document document) {
		// 1.add record in DB
		if (dmsDocumentsService.uploadDocument(document)) {
			return JsonUtils.success("uploadDocument SUCCESS");
		}
		return JsonUtils.failed("uploadDocument failed");
	}

	@GetMapping("/getDocTemplete")
	public JsonResult<List<DocTemplete>> getDocTemplete() {
		List<DocTemplete> searchFileHierarchy = dmsDocumentsService.findDocTemplete();
		return JsonUtils.success("getDocTemplete SUCCESS", searchFileHierarchy);

	}

	@ApiOperation(value = "For External Systems")
	@PostMapping("/getDocumentTree")
	@ResponseBody
	public JsonResult<List<DmsDocumentTree>> getDocumentTree(@RequestBody Document document) {
		String policyNO = document.getPolicyNO();
		String agentCode = document.getAgentCode();
		String NIC = document.getNIC();
		if (policyNO != null && !"".equals(policyNO)) {
			List<DmsDocumentTree> policyDocumentTree = dmsDocumentsService.getPolicyDocumentTree(document);
			return JsonUtils.success("getPolicyDocumentTree SUCCESS", policyDocumentTree);
		}
		if (NIC != null && !"".equals(NIC)) {
			MasterFolder masterfolder = null;
			if (agentCode != null && !"".equals(agentCode)) {
				log.info("agentCode is not null, get agentCode by agentCode:" + agentCode);
				masterfolder = dmsDocumentsService.getMasterFolderByKeyNumber(agentCode);
				if (masterfolder == null) {
					return JsonUtils.failed("there no MasterFolder whitch agentCode=" + agentCode);
				}

			} else {
				log.info("agentCode is null, get agentCode by NIC:" + NIC);
				String searchValue = dmsDocumentsService.getEncryptedNIC(NIC);
				masterfolder = dmsDocumentsService.getMasterFolderBySearchValue(searchValue);
				if (masterfolder == null) {
					return JsonUtils.failed("there no MasterFolder which NIC=" + NIC);
				}

			}
			List<DmsDocumentTree> searchFileHierarchy = dmsDocumentsService.getAgentDocumentsTreeByKeyID(masterfolder);
			return JsonUtils.success("getAgentDocumentTree SUCCESS", searchFileHierarchy);
		}
		return JsonUtils.failed("getAgentDocumentTree failed");
	}

	@ApiOperation(value = "For External Systems")
	@PostMapping("/getDocList")
	@ResponseBody
	public JsonResult<PageResult> getDocList(@RequestBody PageRequest param) {
		String agentCode = param.getAgentCode();
		String nic = param.getNIC();
		String policyNO = param.getPolicyNO();
		if (policyNO != null && !"".equals(policyNO)) {
			PageResult findPage = dmsDocumentsService.findPolicyDocListByKeyID(param);
			return JsonUtils.success("getPolicyDocList SUCCESS", findPage);
		}
		if (nic != null && !"".equals(nic)) {
			PageResult findPage = dmsDocumentsService.getAgentDocListByKeyID(param);
			return JsonUtils.success("getAgentDocList SUCCESS", findPage);
		}
		return JsonUtils.failed("getAgentDocList FAILED");
	}

	/*
	 * @ApiOperation(value="For External Systems")
	 * 
	 * @PostMapping(value= {"/getAgentDocumentTree"})
	 * 
	 * @ResponseBody public JsonResult<List<DmsDocumentTree>>
	 * getAgentDocumentTree(@RequestBody Document document) {
	 * // @PathVariable(value="agentCode",required=false) String
	 * agentCode,@PathVariable String NIC) { String agentCode =
	 * document.getAgentCode(); String NIC = document.getNIC(); MasterFolder
	 * masterfolder = null; if(agentCode != null && !"".equals(agentCode)) {
	 * log.info("agentCode is not null, get agentCode by agentCode:"+agentCode);
	 * masterfolder = dmsDocumentsService.getMasterFolderByKeyNumber(agentCode);
	 * if(masterfolder ==null) { return
	 * JsonUtils.failed("there no MasterFolder whitch agentCode="+agentCode); }
	 * 
	 * }else { log.info("agentCode is null, get agentCode by NIC:"+NIC); String
	 * searchValue = dmsDocumentsService.getEncryptedNIC(NIC); masterfolder =
	 * dmsDocumentsService.getMasterFolderBySearchValue(searchValue);
	 * if(masterfolder ==null) { return
	 * JsonUtils.failed("there no MasterFolder which NIC="+NIC); }
	 * 
	 * } List<DmsDocumentTree> searchFileHierarchy =
	 * dmsDocumentsService.getAgentDocumentsTreeByKeyID(masterfolder); return
	 * JsonUtils.success("getAgentDocumentTree SUCCESS",searchFileHierarchy);
	 * 
	 * 
	 * }
	 */

	/*
	 * @ApiOperation(value="For External Systems")
	 * 
	 * @PostMapping("/getAgentDocList")
	 * 
	 * @ResponseBody public JsonResult<PageResult> getAgentDocList(@RequestBody
	 * PageRequest param) { PageResult findPage =
	 * dmsDocumentsService.getAgentDocListByKeyID(param); return
	 * JsonUtils.success("getAgentDocList SUCCESS",findPage); }
	 */

	@ApiOperation(value = "For External Systems")
	@PostMapping("/docReindex")
	@ResponseBody
	public JsonResult docReindex(@RequestBody Document document) {
		String docType = document.getDocType();
		log.info("docType:" + docType);
		if ("agent".equals(docType)) {
			dmsDocumentsService.docReindexAgentDoc(document);
			return JsonUtils.success("docReindex SUCCESS");
		} else if ("other".equals(docType)) {
			dmsDocumentsService.docReindexOtherDoc(document);
			return JsonUtils.success("docReindex SUCCESS");
		} else {
			dmsDocumentsService.docReindexPolicyDoc(document);
			return JsonUtils.success("docReindex SUCCESS");
		}

	}

	@ApiOperation(value = "For External Systems")
	@GetMapping("/getDocProperties/{docType}/{docID}")
	public JsonResult<Document> getDocProperties(@PathVariable String docType, @PathVariable String docID) {
		if ("".equals(docType) || docType == null) {
			return JsonUtils.failed("docType empty!");
		}
		if ("agent".equals(docType)) {
			DocumentAgent docAgentProperties = dmsDocumentsService.getAgentDocProperties(docID);
			return JsonUtils.success("getDocProperties SUCCESS", docAgentProperties);
		} else if ("other".equals(docType)) {
			DocumentOther docOtherProperties = dmsDocumentsService.getOtherDocProperties(docID);
			return JsonUtils.success("getDocProperties SUCCESS", docOtherProperties);
		} else {
			DocumentPolicy docPolicyProperties = dmsDocumentsService.getPolicyDocProperties(docID);
			return JsonUtils.success("getDocProperties SUCCESS", docPolicyProperties);
		}
	}

	/**
	 * 增加一个同步agentCode的API， 入参是agent code和NIC， 逻辑是通过NIC找到master folder里面的行，把agent
	 * code写入
	 * 
	 * @param masterFolder
	 * @return
	 */
	@ApiOperation(value = "For External Systems")
	@PostMapping("/addAgentCodeByNIC/{agentCode}/{NIC}")
	@ResponseBody
	public JsonResult addAgentCodeByNIC(@PathVariable String agentCode, @PathVariable String NIC) {
		String searchValue = dmsDocumentsService.getEncryptedNIC(NIC);

		if (dmsDocumentsService.addAgentCodeByNIC(agentCode, searchValue)) {
			System.out.println("addAgentCode：" + agentCode + " success.");
			return JsonUtils.success("addAgentCodeByNIC SUCCESS");
		}
		return JsonUtils.failed("addAgentCodeByNIC failed");

	}

	@ApiOperation(value = "For External Systems")
	@PostMapping("/deleteDoc")
	public JsonResult deleteDoc(@RequestBody Document document) {

		String physicallyDeletedFlag = document.getPhysicallyDeletedFlag();
		if ("Y".equals(physicallyDeletedFlag) || physicallyDeletedFlag == "Y") {
			if (dmsDocumentsService.physicallyDeleteDoc(document)) {
				return JsonUtils.success("physically Deleted doc success");
			}
		} else {
			document.setPhysicallyDeletedFlag("N");
			if (dmsDocumentsService.LogicDeleteDoc(document)) {
				return JsonUtils.success("Logic Delete Doc success");
			}
		}
		return JsonUtils.failed("Delete Doc failed");

	}

	/*
	 * //TODO docSplit
	 * 
	 * @PostMapping("/docSplit")
	 * 
	 * @ResponseBody public String docSplit() { return null; }
	 * 
	 * //TODO docExport
	 * 
	 * @PostMapping("/docExport")
	 * 
	 * @ResponseBody public String docExport() { return null; }
	 * 
	 * 
	 * 
	 * //TODO docMask
	 * 
	 * @PostMapping("/docMask/{documentid}")
	 * 
	 * @ResponseBody public String docMask() { return null; }
	 * 
	 * //TODO docVoid
	 * 
	 * @PostMapping("/docVoid/{documentid}")
	 * 
	 * @ResponseBody public String docVoid() { return null; }
	 */

}
