package com.example.azure.storage.model;

import lombok.Data;

@Data
public class DocTemplete {

	private String templateID;			//[TEMPLATE_ID]
	private String templateName;	    //  ,[TEMPLATE_NAME]
	private String tableName;			//  ,[TABLE_NAME]
	private String containerID;	    	//  ,[CONTAINER_ID]
	private String treeViewEnabled;	    //  ,[TREE_VIEW_ENABLED]
	private String rootNode;	    	//  ,[ROOT_NODE]
	private String createdDate;	    	//  ,[CREATED_DATE]
	private String updatedDate;	   		//  ,[UPDATED_DATE]
	private String isDeleted;	    	//  ,[IS_DELETED]
									
}
