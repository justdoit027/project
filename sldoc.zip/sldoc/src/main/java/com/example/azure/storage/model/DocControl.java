package com.example.azure.storage.model;

import lombok.Data;

@Data
public class DocControl {

	private String docID;		//	[DOC_ID]
	private String versionNum;	    // ,[VERSION_NUM]
	private String docName;	    // ,[DOC_NAME]
	private String filePath;	    //  ,[FILE_PATH]
	private String docType;	    //  ,[DOC_TYPE]
	private String containerID;	    //  ,[CONTAINER_ID]
	private String fileSize;	    //  ,[FILE_SIZE]
	private String extension;	    //  ,[EXTENSION]
	private String createdDate;	     // ,[CREATED_DATE]
	private String updatedDate;	    //  ,[UPDATED_DATE]
	private String isDeleted;	    //  ,[IS_DELETED]
	
	private String URI;				//[URI]
}
