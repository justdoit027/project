package com.example.azure.storage.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.MasterFolder;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;
import com.example.azure.storage.model.DmsFolderHierarchy;
import com.example.azure.storage.model.DocControl;
import com.example.azure.storage.model.DocTemplete;
import com.example.azure.storage.model.Document;
import com.example.azure.storage.model.DocumentAgent;
import com.example.azure.storage.model.DocumentOther;
import com.example.azure.storage.model.DocumentPolicy;

public interface DmsDocumentsService {

	public boolean  updateDocument(Document document);
	
	public String downloadFile(List<String> fileName,String containerName);
	
	public List<String> uploadFileList(String filePath,String containerName);

	public List<FolderHierarchy> findFolderHierarchy();
						
//	public List<DmsDocumentTree> findPolicyDocumentsTreeByKeyID(String keyID);
	
//	public List<DmsDocumentTree> searchFileHierarchy();

//	List<DmsDocumentTree> searchFileHierarchyList(String policyNo);
	
//	List<DmsDocumentTree> getPolicyDocumentTree(String policyNo);

	public List<DocTemplete> findDocTemplete();
	
	boolean addPolicyDocument(Document document);
	
	boolean uploadNewVersion(DocControl docControl);
	
	public DocControl findOldVersionByDocID(String docID);

	public boolean upatePolicyDocument(Document document);

	public PageResult findPolicyDocListByKeyID(PageRequest param);

//	public List<DmsDocumentTree> findAgentDocumentsTreeByKeyID(String agentNo);

	public PageResult getAgentDocListByKeyID(PageRequest param);

	public DocTemplete findDocTempleteByTempleteName(String docType);

	public boolean addAgentDocument(Document document);

	public boolean addOtherDocument(Document document);

	public boolean docReindexAgentDoc(Document document);

	public boolean docReindexOtherDoc(Document document);

	public boolean docReindexPolicyDoc(Document document);

	public DocumentAgent getAgentDocProperties(String docID);

	public DocumentOther getOtherDocProperties(String docID);

	public DocumentPolicy getPolicyDocProperties(String docID);

	public MasterFolder getMasterFolderByKeyNumber(String keyNumber);

	public List<DmsDocumentTree> getPolicyDocumentsTreeByKeyID(MasterFolder masterfolder);

	public List<DmsDocumentTree> getAgentDocumentsTreeByKeyID(MasterFolder masterfolder );


	public MasterFolder getMasterFolderBySearchValue(String nRIC);

	public String getEncryptedNIC(String nRIC);

	public boolean addAgentCodeByNIC(String agentCode, String searchValue);

	public boolean addMasterFolder(MasterFolder masterFolder);

	public boolean uploadDocument(Document document);

	public List<DmsDocumentTree> getPolicyDocumentTree(Document document);

	public boolean physicallyDeleteDoc(Document document);

	public boolean LogicDeleteDoc(Document document);


}
