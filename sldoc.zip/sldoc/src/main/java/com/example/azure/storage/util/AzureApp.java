// MIT License
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE

package com.example.azure.storage.util;


import com.microsoft.azure.storage.*;
import com.microsoft.azure.storage.blob.*;

import ch.qos.logback.core.pattern.color.BoldBlueCompositeConverter;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.FileUtils;

@Slf4j
public class AzureApp 
{
	
	private static ExecutorService service = Executors.newCachedThreadPool();
	
	private  CloudStorageAccount storageAccount;
	private  CloudBlobClient blobClient = null;
//	public  CloudBlobContainer container;
	
	public AzureApp() {
		super();
	}
	public AzureApp(String storageConnectionString) {
		log.info("The constructor AzureApp======="+storageConnectionString);
		try {
			storageAccount = CloudStorageAccount.parse(storageConnectionString);
			blobClient = storageAccount.createCloudBlobClient();
//			container = blobClient.getContainerReference(containerString);
			
		}
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	
	public boolean createContainer(String containerName) {
		try {
			CloudBlobContainer container= blobClient.getContainerReference(containerName);

			// Create the container if it does not exist with public access.
			System.out.println("Creating container:" + container.getName());
			container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());		    
			return true;
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean deleteContainerIfExists(String containerName) {
		try {
			CloudBlobContainer container = blobClient.getContainerReference(containerName);
			
			if(container.deleteIfExists()) {
				return true;
			}
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public List<String> findContainerList(){
		List<String> list = new ArrayList<>();
		Iterable<CloudBlobContainer> listContainers = blobClient.listContainers();
		for (CloudBlobContainer cloudBlobContainer : listContainers) {
//			StorageAccessStrategy accessStrategy = new StorageAccessStrategy();
//			accessStrategy.SetPublicContainerPermissions(cloudBlobContainer);
			list.add(cloudBlobContainer.getName());
		}
		return list;
	}
	
	public boolean exitContainer(String containerName) {
		List<String> findContainerList = findContainerList();
		for (String container : findContainerList) {
			if(containerName.equals(container)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * upload From File list
	 * @param filelist
	 */
	public String uploadFile(String fileName,File file,String containerName) {
		String URI="";
		try {
			CloudBlobContainer container = blobClient.getContainerReference(containerName);

//			CloudBlockBlob blob = container.getBlockBlobReference(file.getName());
			CloudBlockBlob blob = container.getBlockBlobReference(fileName);
			if(blob.exists()) {
					CloudBlob createSnapshot = blob.createSnapshot();
					String snapshotID = createSnapshot.getSnapshotID();
					StorageUri snapshotQualifiedStorageUri = createSnapshot.getSnapshotQualifiedStorageUri();
					URI snapshotQualifiedUri = createSnapshot.getSnapshotQualifiedUri();
					System.out.println("blob "+file.getName()+" exist,"
							+ " create Snapshot. snapshotID:"+snapshotID
							+"\r\n snapshotQualifiedStorageUri:"+snapshotQualifiedStorageUri
							+"\r\n snapshotQualifiedUri:"+snapshotQualifiedUri);
			}
				
			//Creating blob and uploading file to it
			blob.uploadFromFile(file.getAbsolutePath());
			System.out.println("Uploading the sample file ,blob name:"+blob.getName()+"\r\n blob uri:"+blob.getUri());
			URI = blob.getUri().toString();
		} 
		catch (StorageException ex)
		{
			System.out.println(String.format("Error returned from the service. Http code: %d and error code: %s", ex.getHttpStatusCode(), ex.getErrorCode()));
		}
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
		return URI;
	}
	
	/**
	 * upload From File list
	 * @param filelist
	 */
	public void uploadFromFilelist(List<File> filelist,String containerName) {
		try {
			CloudBlobContainer container = blobClient.getContainerReference(containerName);
//			String filelist = "D:\\TEMP\\blobfile";
			for (File sourceFile : filelist) {
				//Getting a blob reference
				CloudBlockBlob blob = container.getBlockBlobReference(sourceFile.getName());
				if(blob.exists()) {
					CloudBlob createSnapshot = blob.createSnapshot();
					String snapshotID = createSnapshot.getSnapshotID();
					StorageUri snapshotQualifiedStorageUri = createSnapshot.getSnapshotQualifiedStorageUri();
					URI snapshotQualifiedUri = createSnapshot.getSnapshotQualifiedUri();
					System.out.println("blob "+sourceFile.getName()+" exist,"
							+ " create Snapshot. snapshotID:"+snapshotID
							+"\r\n snapshotQualifiedStorageUri:"+snapshotQualifiedStorageUri
							+"\r\n snapshotQualifiedUri:"+snapshotQualifiedUri);
				}
				
				//Creating blob and uploading file to it
				blob.uploadFromFile(sourceFile.getAbsolutePath());
				System.out.println("Uploading the sample file ,blob name:"+blob.getName()+"\r\n blob uri:"+blob.getUri());
			}
			
			//Listing contents of container
//			for (ListBlobItem blobItem : container.listBlobs()) {
//				System.out.println("URI of blob is: " + blobItem.getUri());
//			}
		} 
		catch (StorageException ex)
		{
			System.out.println(String.format("Error returned from the service. Http code: %d and error code: %s", ex.getHttpStatusCode(), ex.getErrorCode()));
		}
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	/**
	 * upload From Stream
	 * @param filelist
	 */
	public String uploadFromStreamList(List<Map<String, Object>> maplist,String containerName) {
		String URI = "";
		try {
			CloudBlobContainer container = blobClient.getContainerReference(containerName);
			BufferedInputStream bis = null;
			
			for (Map<String, Object> map : maplist) {
				
				InputStream stream = (InputStream)map.get("InputStream");
				String fileNmae = (String)map.get("fileName");
				
				//Getting a blob reference
				CloudBlockBlob blob = container.getBlockBlobReference(fileNmae);
				
				//Creating blob and uploading file to it
				System.out.println("Uploading the sample file ");
				
				bis = new BufferedInputStream(stream);
				blob.upload(bis, 1024);
				URI = blob.getUri().toString();
			}
			bis.close();
		} 
		catch (StorageException ex)
		{
			System.out.println(String.format("Error returned from the service. Http code: %d and error code: %s", ex.getHttpStatusCode(), ex.getErrorCode()));
		}
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
		return URI;
	}
	
	/**
	 * Listing contents of container
	 * @return
	 */
	public List<String> getListContentsOfContainer(String containerName) {
		List<String> list = null;
		CloudBlobContainer container;
		try {
			container = blobClient.getContainerReference(containerName);
		
			list = new ArrayList<String>();
			for (ListBlobItem blobItem : container.listBlobs()) {
				list.add(blobItem.getUri().toString());
	//			System.out.println("URI of blob is: " + blobItem.getUri());
		}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}
	
	/**
	 * download to File by file name list
	 * @param targetFilepath
	 * @param targetFileNamelist
	 */
	public void downloadFilelist(String targetFilepath,List<String> targetFileNamelist,String containerName) {
//		String targetFilepath = "D:\\TEMP\\blobfile\\targetpath";
		File downloadedFile = null;
		CloudBlobContainer container;
		try {
			container = blobClient.getContainerReference(containerName);
			for (String targetFileName : targetFileNamelist) {
				//Getting a blob reference
				CloudBlockBlob blob = container.getBlockBlobReference(targetFileName);
				
				// Download blob. 
				downloadedFile = new File(targetFilepath, targetFileName);
				blob.downloadToFile(downloadedFile.getAbsolutePath());
				System.out.println(downloadedFile.getAbsoluteFile());
			}
			
		} 
		catch (StorageException ex)
		{
			System.out.println(String.format("Error returned from the service. Http code: %d and error code: %s", ex.getHttpStatusCode(), ex.getErrorCode()));
		}
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
	}
	
	
	public void downloadBlobBlocksAsByteArray(final String containerName, final String blobName,String targetFilepath,String containerName1) throws URISyntaxException, StorageException, InterruptedException, ExecutionException {

//        CloudBlockBlob blockBlob = getCloudBlockBlob(containerName, blobName);
		CloudBlobContainer container;
		try {
			container = blobClient.getContainerReference(containerName1);
		
		
		//Getting a blob reference
		CloudBlockBlob blockBlob = container.getBlockBlobReference(blobName);
        final BlobBlocks blobBlocks = new BlobBlocks(blockBlob);
		
        System.out.println("Blob Size " + blobBlocks.getBlobSize());

        List<CompletableFuture> futures = new ArrayList<>();

        long offset = 0;

        for (int blockNum = 0; blockNum < blobBlocks.getNumberOfBlocks(); blockNum++) {
            System.out.println("Downloading block  " + blockNum + ", Block Size " + blobBlocks.getBlockSize(blockNum) + ", Offset " + offset);
            CompletableFuture future = downloadBlockAsync(blockBlob, blobBlocks, blockNum, offset);
            futures.add(future);

            offset += blobBlocks.getBlockSize(blockNum);
        }

        CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(futures.toArray(new CompletableFuture[futures.size()]));
        combinedFuture.get();

        
		FileUtils.writeByteArrayToFile(new File(targetFilepath+"\\"+blobName), blobBlocks.bytes);
		System.out.println("downloadBlobBlocksAsByteArray done.");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StorageException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }

    private CompletableFuture<Void> downloadBlockAsync(CloudBlockBlob blob, BlobBlocks blobBlocks, int blockNumber, long offset) throws InterruptedException {
        CompletableFuture<Void> completableFuture = new CompletableFuture<>();

        CompletableFuture.runAsync(() -> {
            try {
                blob.downloadRangeToByteArray(offset, blobBlocks.getBlockSize(blockNumber), blobBlocks.bytes, (int) offset);

                completableFuture.complete(null);

                System.out.println("Completed download for block num " + blockNumber);

            } catch (StorageException e) {
                e.printStackTrace();
            }
        }, service);

        return completableFuture;
    }

    private class BlobBlocks {

        private final ArrayList<BlockEntry> blocks;
        private final Long blobSize;
        private final byte[] bytes;

        public BlobBlocks(CloudBlockBlob blob) throws StorageException {
            this.blocks = blob.downloadBlockList();
            this.blobSize = blob.getProperties().getLength();
            this.bytes = new byte[blobSize.intValue()];
        }

        public Long getBlobSize() {
            return blobSize;
        }

        public int getNumberOfBlocks(){
            return this.blocks.size();
        }

        public Long getBlockSize(int index){
            return this.blocks.get(index).getSize();
        }
    }
}
