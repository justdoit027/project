package com.example.azure.storage.service;

import java.util.List;

import com.example.azure.storage.model.Containers;

public interface ContainerService {

	public boolean createContainer(String containerName);
	
	public List<String> findContainerList();
	
	
	public boolean deleteContainer(String containerName);

	public Containers findContainerByID(String ContainerID);

}
