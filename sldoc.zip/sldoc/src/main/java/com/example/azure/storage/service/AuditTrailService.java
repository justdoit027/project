package com.example.azure.storage.service;

import java.util.List;


import com.example.azure.storage.model.AuditTrail;

public interface AuditTrailService {
	public List<AuditTrail> getDocAuditTrailList(String docId);
	public List<AuditTrail> getFormAuditTrailList(String formId);
	public void addFormAuditTrail(AuditTrail auditTrail);
	public void addDocAuditTrail(AuditTrail auditTrail);

}
