package com.example.azure.storage.model;

import lombok.Data;

@Data
public class DocumentAgent extends Document {

	private String agentCode;

	private String formName; //FORM_NM;
	private String formCategory; //FORM_CATEGORY;
	private String categoryCode; //CATEGORY_CODE;
}
