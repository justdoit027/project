package com.example.azure.storage.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DmsFolderHierarchy {

	private String folderID;		  //[FOLDER_ID]
	private String folderLevel;	      //[FOLDER_LEVEL]
	private String folderName;	      //[FOLD_NAME]
	private String parentFolderID;	      //[PARENT_FOLDERID]
	private String deleteFlag;	      //[DELETE_FLAG]
	private String formID;		  //[FORM_ID]
	
	
	@Override
	public String toString() {
		return "FolderHierarchy [folderID=" + folderID + ", folderLevel=" + folderLevel + ", folderName=" + folderName
				+ ", parentFolderID=" + parentFolderID + ", deleteFlag=" + deleteFlag + ", formID=" + formID + "]";
	}
	
}
