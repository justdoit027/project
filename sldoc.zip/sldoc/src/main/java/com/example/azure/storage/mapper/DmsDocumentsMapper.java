package com.example.azure.storage.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.azure.storage.model.DmsFolderHierarchy;
import com.example.azure.storage.model.DocTemplete;

@Mapper
public interface DmsDocumentsMapper {

	public List<Object> getFileList(Object object);
	
	public boolean uploadFileList(List<String> list);

	public List<DmsFolderHierarchy> findFolderHierarchy();

	public List<DocTemplete> findDocTemplete();
}
