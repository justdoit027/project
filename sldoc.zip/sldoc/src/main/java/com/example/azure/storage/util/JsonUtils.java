package com.example.azure.storage.util;

import com.example.azure.storage.common.JsonResult;

public class JsonUtils {
	

	public static <T>JsonResult  success(String message) {
		return JsonResult.retSuccess(message);
	}
	public static <T>JsonResult  success(String message,Object data) {
		return JsonResult.retSuccess(message, data);
	}

	public static <T>JsonResult  failed(String message) {
		return JsonResult.retFailed(message);
	}
	public static <T>JsonResult  failed(String message,Object data) {
		return JsonResult.retFailed(message, data);
	}
}
