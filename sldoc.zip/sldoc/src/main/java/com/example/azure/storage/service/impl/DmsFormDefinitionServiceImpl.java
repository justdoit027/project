package com.example.azure.storage.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.azure.storage.aop.AuditTrailLog;
import com.example.azure.storage.common.FunctionTypeValue;
import com.example.azure.storage.mapper.FormDefinitionMapper;
import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.model.PageRequest;
import com.example.azure.storage.model.PageResult;
import com.example.azure.storage.service.FormDefinitionService;
import com.example.azure.storage.util.PageUtils;
import com.github.pagehelper.Page;

import lombok.extern.slf4j.Slf4j;
import sun.util.logging.resources.logging;

@Service
@Slf4j
public class DmsFormDefinitionServiceImpl implements FormDefinitionService{

	@Autowired
	private FormDefinitionMapper dmsFormDefinitionMapper;
	
	public PageResult  findPage(PageRequest param) {
		Page<Object> startPage = PageUtils.startPage(param);
		
		List<FormDefinition> selectPage = dmsFormDefinitionMapper.selectPage(param);
		PageResult pageResult= new PageResult();
		pageResult.setContent(selectPage);
		pageResult.setTotalSize(startPage.getTotal());
		return pageResult;
    }

	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_FORM_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_FORM_CREATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_FORM_POJO) 
	@Override
	public boolean addFormDefinition(FormDefinition param) {
		return dmsFormDefinitionMapper.addFormDefinition(param);
		 
	}


	@Override
	public FormDefinition findFormDefinitionByFormID(String formID) {
		
		return dmsFormDefinitionMapper.findFormDefinitionByFormID(formID);
	}


	@Override
	public boolean editFormDefinition(String formDefinitionId,String formId,String formName,String formCategory) {
		return dmsFormDefinitionMapper.editFormDefinition(formDefinitionId,formId,formName,formCategory);
	}

	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_FORM_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_DOC_DELETE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_FORM_STR) 
	@Override
	public boolean delFormDefinition(String formDefinitionId) {
		
		return dmsFormDefinitionMapper.delFormDefinition(formDefinitionId);
	}

	@AuditTrailLog(category = FunctionTypeValue.FUNCTIONTYPE_FORM_CATEGORY,action=FunctionTypeValue.FUNCTION_TYPE_VALUE_FORM_UPDATE_ACTION,
			paramType=FunctionTypeValue.FUNCTIONLIST_FORM_POJO) 
	@Override
	public boolean editFormDefinition(FormDefinition param) {
		return dmsFormDefinitionMapper.editFormDefinition(param);
	}


	public FormDefinition findFormDefinitionByID(String formDefinitionId) {
		return dmsFormDefinitionMapper.findFormDefinitionByID(formDefinitionId);
	}


	public List<DmsDocumentTree> findFormHierarchy(String param) {
		//get root node leve0
		 FolderHierarchy s  = dmsFormDefinitionMapper.findFolderHierarchyByType(param);
		 String leve0FolderID = s.getFolderID();
		 log.info("root note:"+leve0FolderID);
		 
		 //according root node get leve1 folder
		 List<String> leve0FolderIDList = new ArrayList<>();
		 leve0FolderIDList.add(leve0FolderID);
		 List<FolderHierarchy> leve1List = dmsFormDefinitionMapper.findFolderHierarchyByParentFolderID(leve0FolderIDList);
		 
		 
		//according leve1 folder get leve1+ folder
		 List<String>  leve1FolderIDList = new ArrayList<>();
		 for (FolderHierarchy string : leve1List) {
			 leve1FolderIDList.add(string.getFolderID());
			 log.info("leve1 folder:"+string.getFolderID()+"/n");
		}
		 List<String> leveMoreFolderIDList =  new ArrayList<>();
		 List<String>  findChild = new ArrayList<>();
		 if(leve1FolderIDList != null ) {
			 leveMoreFolderIDList = findChild(leve1FolderIDList,findChild);
		 }
		 
		 //get result List
		 List<String>  resultList = new ArrayList<>();
		 resultList.add(leve0FolderID);
		 resultList.addAll(leve1FolderIDList);
		 resultList.addAll(leveMoreFolderIDList);
		 log.info("resultList:"+resultList.toString());
		 
		 //according result folder id list get all form Hierarchy
		 List<FolderHierarchy> findFormHierarchyByFolderID = dmsFormDefinitionMapper.findFormHierarchyByFolderID(resultList);
		 
		 //get Form Hierarchy
		 List<DmsDocumentTree> treeList = new ArrayList<>();
		 for (FolderHierarchy folderHierarchy : findFormHierarchyByFolderID) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderID = folderHierarchy.getFolderID();
			 String formID = folderHierarchy.getFormID();
			 String rowID = folderHierarchy.getRowID();
			 String folderLevel = folderHierarchy.getFolderLevel();
			 tree.setFolderName(formID);
			 tree.setParentFolderID(folderID);
			 tree.setType("0");
//			 tree.setFormId(formID);
			 tree.setFolderID(rowID);
			 tree.setIsLeaf("Y");
			 tree.setIsForm("Y");
			 treeList.add(tree);
		}
		 //get folder Hierarchy
		 List<FolderHierarchy> resultFolderHierarchyList = dmsFormDefinitionMapper.findFolderHierarchyByFolderID(resultList);
		 for (FolderHierarchy folderHierarchy : resultFolderHierarchyList) {
			 DmsDocumentTree tree = new  DmsDocumentTree();
			 String parentFolderID = folderHierarchy.getParentFolderID();
			 String folderName = folderHierarchy.getFolderName();
			 String folderID = folderHierarchy.getFolderID();
			 String folderLevel = folderHierarchy.getFolderLevel();
			 tree.setFolderName(folderName);
			 tree.setParentFolderID(parentFolderID);
			 tree.setType("0");
			 tree.setFolderID(folderID);
			 tree.setIsLeaf("N");
			 tree.setIsForm("N");
			 treeList.add(tree);
		}
		return treeList;
	}
	
	public List<String>  findChild(List<String> leve1FolderIDList,List<String>  findChild) {
		log.info(leve1FolderIDList.toString());
		List<FolderHierarchy> leveMoreList = new ArrayList<>();
		leveMoreList = dmsFormDefinitionMapper.findFolderHierarchyByParentFolderID(leve1FolderIDList);
		List<String> newfolderIDList = new ArrayList<>();
		if(leveMoreList.size() !=0) {
			for (FolderHierarchy string : leveMoreList) {
				findChild.add(string.getFolderID());
				newfolderIDList.add(string.getFolderID());
				log.info("leve more folder:"+string.getFolderID());
			}
			List<String> findChild2 = findChild(newfolderIDList,findChild);
			findChild.addAll(findChild2);
		}
		return findChild;
		
	}


	@Override
	public boolean addFileHierarchyFolder(String folderName,String parentFolderID) {
		return dmsFormDefinitionMapper.addFileHierarchyFolder(folderName,parentFolderID);
	}


	@Override
	public boolean editFileHierarchyFolder(String folderID, String folderName) {
		// TODO Auto-generated method stub
		return dmsFormDefinitionMapper.editFileHierarchyFolder(folderID,folderName);
	}


	@Override
	public boolean delFileHierarchyFolder(String folderID) {
		
		return dmsFormDefinitionMapper.delFileHierarchyFolder(folderID);
	}


	@Override
	public List<FormDefinition> getFormDefinition() {
		return dmsFormDefinitionMapper.getFormDefinition();
	}


	@Override
	public boolean addFileHierarchyForm(String folderID, String formID) {
		return dmsFormDefinitionMapper.addFileHierarchyForm(folderID,formID);
	}


	@Override
	public boolean editFileHierarchyForm(String newFormID, String formID) {
		return dmsFormDefinitionMapper.editFileHierarchyForm(newFormID,formID);
	}


	@Override
	public boolean delFileHierarchyForm(String formID) {
		return dmsFormDefinitionMapper.delFileHierarchyForm(formID);
	}


	@Override
	public List<FormDefinition> getAssignedForm() {
		return dmsFormDefinitionMapper.getAssignedForm();
	}

	
}
