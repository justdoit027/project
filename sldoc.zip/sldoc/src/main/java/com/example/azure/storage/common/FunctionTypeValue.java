package com.example.azure.storage.common;
public class FunctionTypeValue {
    public static final String FUNCTIONTYPE_DOC_CATEGORY = "Document Management";
    public static final String FUNCTIONTYPE_FORM_CATEGORY = "Form Management";
    
	public static final String FUNCTION_TYPE_VALUE_FORM_CREATE_ACTION = "Create Form";
	public static final String FUNCTION_TYPE_VALUE_DOC_CREATE_ACTION ="Create Document" ;
	public static final String FUNCTION_TYPE_VALUE_DOC_UPLOAD_ACTION ="Upload Document" ;
	
	public static final String FUNCTION_TYPE_VALUE_DOC_UPDATE_ACTION = "Update Document";
	public static final String FUNCTION_TYPE_VALUE_FORM_UPDATE_ACTION = "Update Form";
	public static final String FUNCTION_TYPE_VALUE_DOC_DELETE_ACTION = "Delete Document";
	public static final String FUNCTION_TYPE_VALUE_FORM_DELETE_ACTION = "Delete Form";
	public static final String FUNCTIONLIST_DOC_POJO = "docPojo";
	public static final String FUNCTIONLIST_DOC_STR = "docStr";
	public static final String FUNCTIONLIST_FORM_POJO = "formPojo";
	public static final String FUNCTIONLIST_FORM_STR = "formStr";
}