package com.example.azure.storage.model;

import lombok.Data;

@Data
public class Document {

	private String docID;		  //[DOC_ID]
	private String versionNum;	      //,[VERSION_NUM]
	private String formID;	      //,[FORM_ID]
	private String docType;	      //,[DOC_TYPE]
	private String createdDate;	      //,[CREATED_DATE]
	private String updatedDate;	      //,[UPDATED_DATE]
	private String isDeleted;	      //,[IS_DELETED]
	
	private String parentFolderID;			//,[FOLDER_ID]
	private String fileName;			//,[DOC_NAME]
	private String filePath;			//FILE_PATH
	private String containerID;			//CONTAINER_ID;
	private String URI;					//URI
	private String extension;			//EXTENSION
	
	private String policyNO;			// POLICY_NO;
	private String formRowID;			//ROWID
	private String agentCode;			//AGENT_CODE
	private String NIC;					//NIC
	private String keyID;				//KEY_ID
	
	private String physicallyDeletedFlag;
}
