package com.example.azure.storage.model;

import lombok.Data;

@Data
public class FolderHierarchy {

	private String folderID;		  //[FOLDER_ID]
	private String folderLevel;	      //[FOLDER_LEVEL]
	private String folderName;	      //[FOLD_NAME]
	private String createdDate;		  //[CREATED_DATE]
	private String updatedDate;		  //[UPDATED_DATE]
	private String deleteFlag;	      //[ID_DELETED]
	private String parentFolderID;	  //[PARENT_FOLDERID]
	private String formID;
	
	private String rowID;		//ROWID
}
