package com.example.azure.storage.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.azure.storage.model.DmsDocumentTree;
import com.example.azure.storage.model.FolderHierarchy;
import com.example.azure.storage.model.FormDefinition;
import com.example.azure.storage.model.PageRequest;


@Mapper
public interface FormDefinitionMapper {

	List<FormDefinition> selectPage(PageRequest param);

	boolean addFormDefinition(FormDefinition param);

	FormDefinition findFormDefinitionByFormID(String formID);
	
	boolean editFormDefinition(@Param("formDefinitionId")String formDefinitionId,@Param("formID") String formId,@Param("formName") String formName,@Param("formCategory")String formCategory);

	boolean delFormDefinition(String formDefinitionId);

	boolean editFormDefinition(FormDefinition param);

	FormDefinition findFormDefinitionByID(String formDefinitionId);

	List<FolderHierarchy> findFormHierarchy();

	FolderHierarchy findFolderHierarchyByType(String param);
	
	public List<FolderHierarchy> findFolderHierarchyByParentFolderID(List<String> list);
	
	public List<FolderHierarchy> findFolderHierarchyByFolderID(List<String> list);
	
	
	public List<FolderHierarchy> findFormHierarchyByFolderID(List<String> list);
	public String getFormName(String formDefinitionId);

	List<FolderHierarchy> findFormHierarchyByFormID(List<String> formIDList);

	boolean addFileHierarchyFolder(@Param("folderName")String folderName,@Param("parentFolderID")String parentFolderID);

	boolean editFileHierarchyFolder(@Param("folderID")String folderID, @Param("folderName")String folderName);

	boolean delFileHierarchyFolder(@Param("folderID")String folderID);

	List<FormDefinition> getFormDefinition();

	boolean addFileHierarchyForm(@Param("folderID")String folderID, @Param("formID")String formID);

	boolean editFileHierarchyForm(@Param("newFormID")String newFormID, @Param("formID")String formID);

	boolean delFileHierarchyForm(String formID);

	List<FormDefinition> getAssignedForm();

}
