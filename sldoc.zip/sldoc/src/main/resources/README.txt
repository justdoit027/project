由于公司远程仓库无法下载azure相关jar包，可以按以下步骤下载
1。关掉IE代理，关闭vpn
2.修改远程仓库，maven的setting文件中mirror配置项
3.下载azure相关jar包

关于上传下载测试用例
不需要启动项目，直接进行单元测试。
1.在本地路径准备一些要上传的文件例如D:\\TEMP\\blobfile
2.修改 AzureAppTest测试类中的上传路径
3.由于下载是按照文件名批量下载，所以先测试testuploadFile方法，将文件上传后再测试testdownloadFile方法。


