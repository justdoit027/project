package com.aia.mm_imaging.service;

import java.io.IOException;

import com.aia.mm_imaging.pojo.OutputVO;

public interface DocumentService {
	
	/**
	 * 
	 * @param docList
	 * @return
	 */
	String getDocListByPol(String json, String method);
	/**
	 * 
	 * @return
	 * @throws IOException 
	 */
	String getDocStrById(String json,String method);
	/**
	 * @return List
	 */
	
	OutputVO getCategoryList();
	/**
	 * @param form_category
	 * @return List
	 */
	
	OutputVO getCategoryByCategory(String json);
	
	
	OutputVO uploadFile(String json);
	
}
