package com.aia.mm_imaging.util;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetUtils {
	
	private static Logger m_Logger = LoggerFactory.getLogger(NetUtils.class.getClass());

	public static String getHostName() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException uhe) {
			m_Logger.error("getHostName error,UnknownHostException : " + uhe.getMessage());
//			String host = uhe.getMessage(); // host = "hostname: hostname"
//			if (host != null) {
//				int colon = host.indexOf(':');
//				if (colon > 0) {
//					return host.substring(0, colon);
//				}
//			}
			return "UnknownHost";
		}
	}
	public static String getHostAdress() {
		try {
			return InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException uhe) {
			m_Logger.error("getHostAdress error,UnknownHostException : " + uhe.getMessage());
			return "UnknownHost";
		}
	}
	 
	 
	 
}
