package com.aia.mm_imaging.util;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyUtil {
	
	private PropertyUtil() {}
	
	private static Logger m_Logger = LoggerFactory.getLogger(PropertyUtil.class.getClass());

	static ResourceBundle commProp = null;

	static {

		try {

			commProp = ResourceBundle.getBundle("common");


		} catch (MissingResourceException e) {

			m_Logger.error( "Initialize properties files failed:", e);

		}

	}

	public static String getCommonProperty(String key) {

		if (commProp != null)

			return commProp.getString(key);

		return "";

	}

}
