package com.aia.mm_imaging.util;

import java.util.UUID;

public class StringUtil {
	public static synchronized String getReqUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
}
