package com.aia.mm_imaging.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.aia.mm_imaging.dao.DocumentDao;
import com.aia.mm_imaging.pojo.AuditTrail;
import com.aia.mm_imaging.pojo.DocInfo;
import com.aia.mm_imaging.service.DocumentService;
import com.aia.mm_imaging.util.Base64Util;
import com.aia.mm_imaging.util.DateUtil;
import com.alibaba.fastjson.JSON;
import com.aia.mm_imaging.pojo.OutputVO;
import com.aia.mm_imaging.util.EncryptionUtil;
import com.aia.mm_imaging.util.FileUtil;
import com.aia.mm_imaging.util.ValidateUtil;

@Service
public class DocumentServiceImpl implements DocumentService {

	@Autowired
	private DocumentDao documentDao;

	@SuppressWarnings("unchecked")
	@Override
	public String getDocListByPol(String json, String method) {
		/*
		 * 1.JSON to MAP 2.parse applicationName polList 3.loop to get doc info "
		 */

		Map<String, String> params = new HashMap<String, String>();
		List<Map<String, List<DocInfo>>> docInfoResult = new ArrayList<>();
		OutputVO outputVO = new OutputVO();
		String applicationName = null;
		String loginId = null;
		String formId = null;
		String startDt = null;
		String endDt = null;
		String encryptResult = null;
		// check isNull
		try {
			Map<String, Object> jsonMap = JSON.parseObject(json);
			if (jsonMap == null) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter !");
				return JSON.toJSONString(outputVO);
			}
			loginId = String.valueOf(jsonMap.get("loginId"));
			if ("null".equals(loginId)) {
				
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find loginId !");
				return JSON.toJSONString(outputVO);
			}

			applicationName = String.valueOf(jsonMap.get("applicationName"));
			if (jsonMap.get("formId") != null) {
				formId = String.valueOf(jsonMap.get("formId"));
			}
			if ("null".equals(applicationName)) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find applicationName !");
				return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
			}
			if ("getDocListByAgentCode".equals(method)) { // do getDocListByAgentCode
				startDt = String.valueOf(jsonMap.get("startDt"));
				endDt = String.valueOf(jsonMap.get("endDt"));
				List<String> agentCodeList = (List<String>) jsonMap.get("agentCode");
				if (agentCodeList == null || agentCodeList.size() == 0) {
					outputVO.setCode("E100");
					outputVO.setMessage("Invalid parameter, can not find agentCode !");
					return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
				}
				if ("null".equals(startDt)) {
					outputVO.setCode("E100");
					outputVO.setMessage("Invalid parameter, can not find startDt !");
					return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
				}
				if ("null".equals(endDt)) {
					outputVO.setCode("E100");
					outputVO.setMessage("Invalid parameter, can not find endDt !");
					return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
				}
				// params
				params.put("applicationName", applicationName);
				params.put("formId", formId);
				params.put("startDt", DateUtil.strToDate(startDt, null));
				params.put("endDt", DateUtil.strToDate(endDt, null));
				// query doc info
				for (String agentcode : agentCodeList) {
					params.put("agentCode", agentcode);
					List<DocInfo> docInfoByPolList = documentDao.getDocInfoByPol(params);
					Map<String, List<DocInfo>> docInfoMap = new HashMap<>();
					docInfoMap.put(agentcode, docInfoByPolList);
					docInfoResult.add(docInfoMap);

				}
				// do encrypt
				outputVO.setData(docInfoResult);
				encryptResult = EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
				return encryptResult;
			}

			List<String> polList = (List<String>) jsonMap.get("polList");
			if (polList == null || polList.size() == 0) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find polList !");
				return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
			}
			// params
			params.put("applicationName", applicationName);
			params.put("formId", formId);

			// query doc info

			for (String pol : polList) {
				params.put("pol", pol);
				List<DocInfo> docInfoByPolList = documentDao.getDocInfoByPol(params);
				Map<String, List<DocInfo>> docInfoMap = new HashMap<>();
				docInfoMap.put(pol, docInfoByPolList);
				docInfoResult.add(docInfoMap);
			}
			// do encrypt
			outputVO.setData(docInfoResult);
			encryptResult = EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
		} catch (Exception e) {
			e.printStackTrace();
			outputVO.setData(null);
			outputVO.setCode("E000");
			outputVO.setMessage("Undefined error:" + e.getMessage());
			// outputVO.setMessage("Undefined error !");
			encryptResult = EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
		}
		return encryptResult;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getDocStrById(String json, String method) {
		/*
		 * 1JSON to MAP 2get applicationName ids 3forEach ids get data
		 */
		Map<String, Object> params = new HashMap<String, Object>();
		List<Map<String, String>> docStrList = new ArrayList<>();
		String encryptResult = null;
		OutputVO outputVO = new OutputVO();
		String applicationName = null;
		String loginId = null;
		String agentCode = null;
		String startDt = null;
		String endDt = null;

		try {
			Map<String, Object> jsonMap = JSON.parseObject(json);
			// check isNull
			if (jsonMap == null) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter!");
				return JSON.toJSONString(outputVO);
			}
			agentCode = String.valueOf(jsonMap.get("agentCode"));

			loginId = String.valueOf(jsonMap.get("loginId"));
			if ("null".equals(loginId)) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find loginId !");
				return JSON.toJSONString(outputVO);
			}
			applicationName = String.valueOf(jsonMap.get("applicationName"));
			if ("null".equals(applicationName)) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find applicationName !");
				return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
			}

			List<String> ids = (List<String>) jsonMap.get("docId");
			if (ids == null || ids.size() == 0) {
				outputVO.setCode("E100");
				outputVO.setMessage("Invalid parameter, can not find file !");
				return EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
			}

			// params
			params.put("applicationName", applicationName);
			for (String docId : ids) {
				Map<String, String> doc = new HashMap<>();
				params.put("docId", docId);
				List<DocInfo> docInfoByDocIdList = documentDao.getDocById(params);
				if(docInfoByDocIdList.size()>0){
					DocInfo docInfo = docInfoByDocIdList.get(0);
					// pdfToBase64Str
					String filepath = docInfo.getFilePath();
					String fileName = docInfo.getFileNm();
					File f = new File(filepath + fileName);
					String docStr = Base64Util.PDFToBase64(f);
					doc.put(docId, docStr);
					docStrList.add(doc);
				}else {
					doc.put(docId, "");
					docStrList.add(doc);
				}
				

			}
			// do encrypt
			outputVO.setData(docStrList);
			encryptResult = EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
		} catch (Exception e) {
			e.printStackTrace();
			outputVO.setData(null);
			outputVO.setCode("E000");
			outputVO.setMessage("Undefined error !" + e.getMessage());
			encryptResult = EncryptionUtil.doEncryption(JSON.toJSONString(outputVO), loginId);
		}
		return encryptResult;
	}

	@Override
	public OutputVO getCategoryList() {
		OutputVO outputVO = new OutputVO();
		outputVO.setData(documentDao.getCategoryList());
		return outputVO;
	}

	@Override
	public OutputVO getCategoryByCategory(String json) {
		OutputVO outputVO = new OutputVO();
		String formCategory = "";
		Map<String, Object> jsonMap = JSON.parseObject(json);

		try {
			if (jsonMap == null) {
				outputVO.setCode("E000");
				outputVO.setMessage("Invalid parameter !");
				return outputVO;
			}
			if ("kendoDropDownList".equals(String.valueOf(jsonMap.get("kendoDropDownList")))) {
				outputVO.setData(documentDao.getCategoryByCategory(null));
				return outputVO;
			}

			if (jsonMap.get("formCategory") == null) {
				outputVO.setCode("E000");
				outputVO.setMessage("Invalid parameter, can not find formCategory !");
				return outputVO;
			} else {
				formCategory = String.valueOf(jsonMap.get("formCategory"));
			}

			outputVO.setData(documentDao.getCategoryByCategory(formCategory));
		} catch (Exception e) {
			outputVO.setCode("E000");
			outputVO.setMessage(e.getMessage());
			e.printStackTrace();
		}
		return outputVO;
	}

	@Transactional
	@Override
	public OutputVO uploadFile(String json) {
		OutputVO outputVO = new OutputVO();
		Map<String, Object> jsonMap = JSON.parseObject(json);
		Map<String, String> resultMap = new HashMap<String, String>();
		if (jsonMap == null || jsonMap.get("file") == null) {
			outputVO.setCode("E000");
			outputVO.setMessage("Invalid parameter, can not find file  !");
			return outputVO;
		}  else if (jsonMap.get("formId") == null) {
			outputVO.setCode("E000");
			outputVO.setMessage("Invalid parameter, can not find formId  !");
			return outputVO;
		} else if (jsonMap.get("polNum") == null) {
			outputVO.setCode("E000");
			outputVO.setMessage("Invalid parameter, can not find polNum  !");
			return outputVO;
		}

		try {
			String file = String.valueOf(jsonMap.get("file"));
			String formId = String.valueOf(jsonMap.get("formId"));
			String formCategory = documentDao.getCategoryByFormId(formId);
			if (StringUtils.isEmpty(formCategory)) {
				outputVO.setCode("E000");
				outputVO.setMessage("Invalid parameter, can not find formCategory by formId  !");
				return outputVO;
			}
			String polNum = String.valueOf(jsonMap.get("polNum"));
			DocInfo docInfo = new DocInfo();
			docInfo.setFormId(formId);
			docInfo.setFormCategory(formCategory);

			// Save the uploaded file to this folder
			/*
			 * String uploadPath = "//10.112.101.42//MM_Imaging_fileServer//PolicyDoc//" +
			 * polNum.substring(0, 3) + "//" + polNum.substring(3, 6) + "//" + polNum + "//"
			 * + formCategory + "//" + formId + "//";
			 */
			// Convert File Name
			String filenameStr= polNum + "_" + formId + "_" + "Manual" + "_" + DateUtil.getDateStr();
			String fileNameString = filenameStr + ".pdf";
			String uploadPath =FileUtil.getAbsFilePath(fileNameString, formCategory);
			System.out.println(uploadPath);
			
			docInfo.setSourceSystem("MANUAL");
			docInfo.setFilePath(uploadPath);
			docInfo.setFileNm(fileNameString);
			docInfo.setLastModified(DateUtil.DateToStr(new Date(), null));
			docInfo.setCreateBy("system");
			docInfo.setUpdateBy("system");
			// strToPdf
			Base64Util.base64StringToPdf(file, uploadPath + fileNameString);

			// check if there is doc exist
			Map<String, String> map = new HashMap<String, String>();
			map.put("fileName", fileNameString);
			ValidateUtil.checkExistDoc(map);

			documentDao.saveDocInfo(docInfo);
			String docId = docInfo.getDocId();
			// get docId
			Map<String, String> docMap = new HashMap<String, String>();
			// save to audit trail
			AuditTrail auditTrail = new AuditTrail();
			auditTrail.setAction("upload");
			auditTrail.setActionDesc("upload files");
			// auditTrail.setPolNum("");
			auditTrail.setPolNum(polNum);
			auditTrail.setDocId(docId);
			auditTrail.setCreateBy("system");
			auditTrail.setUpdateBy("system");
			documentDao.insertDocAuditTrail(auditTrail);
			// save to polLink
			docMap.put("docId", docId);
			docMap.put("polNum", polNum);
			documentDao.insertPolLink(docMap);
			resultMap.put("formCategory", formCategory);
			resultMap.put("formId", formId);
			resultMap.put("polNum", polNum);
			outputVO.setData(resultMap);
		} catch (Exception e) {
			outputVO.setCode("E000");
			outputVO.setMessage(e.getMessage());
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

}
