package com.aia.mm_imaging.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.mm_imaging.dao.DocumentDao;
import com.aia.mm_imaging.pojo.AuditTrail;
import com.aia.mm_imaging.pojo.DocInfo;
import com.aia.mm_imaging.util.DateUtil;
import com.aia.mm_imaging.util.FileUtil;
import com.aia.mm_imaging.util.InitUtil;
import com.aia.mm_imaging.util.ValidateUtil;

public class DoCaptureProcess implements Runnable {

	private static Logger logger = LoggerFactory.getLogger(DoCaptureProcess.class);

	private File srcFile;
	private String targetFilePath;
	private String backFilePath;
	private String errorFilePath;
	private String submitChannel;
	private DocumentDao documentDao;
	
	public DoCaptureProcess(DocumentDao documentDao, File srcFile, String targetFilePath, String backFilePath, String errorFilePath,String submitChannel) {
		this.documentDao = documentDao;
		this.srcFile = srcFile;
		this.targetFilePath = targetFilePath;
		this.backFilePath = backFilePath;
		this.errorFilePath = errorFilePath;
		this.submitChannel = submitChannel;	
	}

	@Override
	public void run() {
		
		try {		
			/*
			 * 1.Do validation
			 *  (1)File name format([PolicyNO]_[FORMID]_channel_YYYYMMDDhhmmss.EXT_NAME)
			 *  (2)File size: <= 5*1024 kb
			 *  (3)File type: pdf
			 *  if false, move file to /stage/error folder,log audit trail
			 */
			boolean isValid = false;
			String formCategory = null;
			String fileName = this.srcFile.getName();
			String message = ValidateUtil.checkFileType(fileName);
			if(message.isEmpty()){
				message = ValidateUtil.checkFileSize(this.srcFile.toString());
				if(message.isEmpty()){
					message = ValidateUtil.checkFileName(fileName, submitChannel);
					if(message.contains("FORM_CATEGORY")){
						formCategory = message.split(":")[1];
						isValid = true;
					}				
				}
			}
			logger.info(this.srcFile + ": message======" + message);
			
			if(isValid){
				//Prase file name, save to db/audit trail
				String[] fileFields =  fileName.split("_");
				String policyNo = null;
				String agentCode = null;
						
				String formId = fileFields[1];
				String submissionChannel = fileFields[2].toUpperCase();
				String datetime = fileFields[3];
				String absTargetFilePath = FileUtil.getAbsFilePath(srcFile.getName(), formCategory);
				//String filePath = this.srcFile.getCanonicalPath().substring(0, this.srcFile.getCanonicalPath().lastIndexOf("."));
				DocInfo docInfo = new DocInfo();
				//docInfo.setPolNum(policyNo);
				docInfo.setFormId(formId);
				docInfo.setSourceSystem(submissionChannel);
				docInfo.setFilePath(absTargetFilePath);
				docInfo.setFileNm(fileName);
				docInfo.setCreateBy("system");
				docInfo.setUpdateBy("system");
				docInfo.setLastModified(DateUtil.DateToStr(new Date(srcFile.lastModified()),null));
				//check if there is doc exist
				Map<String,String> map = new HashMap<String, String>();
				map.put("fileName", fileName);	
				ValidateUtil.checkExistDoc(map);
				
				documentDao.saveDocInfo(docInfo);
				//get docId
				String docId = docInfo.getDocId();
				logger.info("Save docId ====== " + docId);
				
				Map<String, String> docMap = null;
				if(InitUtil.getSubmissionChannels().toUpperCase().contains(submitChannel.toUpperCase())){
					policyNo = fileFields[0];
					docMap = new HashMap<String, String>();
					docMap.put("docId", docId);
					docMap.put("polNum", policyNo);
					documentDao.insertPolLink(docMap);
				}else if(InitUtil.getSubmissionChannelsAg().toUpperCase().contains(submitChannel.toUpperCase())){
					agentCode = fileFields[0];
					docMap = new HashMap<String, String>();
					docMap.put("docId", docId);
					docMap.put("agentCode", agentCode);
					documentDao.insertAgentLink(docMap);					
				}
							
				//save to audit trail
				AuditTrail auditTrail = new AuditTrail();
				auditTrail.setAction("Capture");
				auditTrail.setActionDesc("Capture files");
				//auditTrail.setCaptureId("");	
				auditTrail.setPolNum(policyNo);
				auditTrail.setAgentCd(agentCode);
				auditTrail.setDocId(docId);
				auditTrail.setCreateBy("system");
				auditTrail.setUpdateBy("system");
				documentDao.insertDocAuditTrail(auditTrail);
				
				//move to target filestore folder
				moveTargetFolder(formCategory,absTargetFilePath);
				
				// 4.move file to /stage/backups
				moveBackFolder();
			}else{
				//move to error folder
				logger.error(srcFile + " capture failed, and will move to error folder.");
				moveErrorFolder();
			}
									
		}catch(IOException ie){
			logger.error(srcFile + " finally capture failed, and will move to error folder.", ie);
			ie.printStackTrace();
			try{
				moveErrorFolder();
			}catch(Exception e1){
				
			}
			
		}catch (Exception e) {
			logger.error(srcFile + " finally capture failed, and will move to error folder.", e);
			e.printStackTrace();	
			try{
				moveErrorFolder();
			}catch(Exception e2){
				
			}		
		} finally {

		}

	}

	private void moveErrorFolder() throws Exception,IOException {
		
		String errorFileName = null;
		if(errorFilePath.endsWith(File.separator)){
			errorFileName = errorFilePath + srcFile.getName();
		}else{
			errorFileName = errorFilePath + File.separator + srcFile.getName();
		}
		File errorFile = new File(errorFileName);

		// 3.do copy
		FileUtil.moveFile(srcFile, errorFile);
		
		logger.info(srcFile.getName() + " is moved to " + errorFilePath +  " successful!");
	}

	private void moveBackFolder() throws Exception,IOException {
		
		String backtFileName = null;
		if(backFilePath.endsWith(File.separator)){
			backtFileName = backFilePath + srcFile.getName();
		}else{
			backtFileName = backFilePath + File.separator + srcFile.getName();
		}
		File backFile = new File(backtFileName);
		FileUtil.copyFile(srcFile, backFile, true);

		logger.info(srcFile.getName() + " is moved to " + backFilePath +  " successful!");
		
		if (srcFile.delete()) {
			logger.info(srcFile.getName() + " is delete successful!");
		} else {
			logger.info(srcFile.getName() + " is delete failed!");
		}
		
	}

	private void moveTargetFolder(String formCategory, String absTargetFilePath) throws Exception,IOException {
		
		// 2.Prase file name, new target file,
		String targetFileName = null;
		if(absTargetFilePath.endsWith(File.separator)){
			targetFileName = absTargetFilePath + srcFile.getName();
		}else{
			targetFileName = absTargetFilePath + File.separator + srcFile.getName();
		}
		// 3.do copyfileUtil
		//need parase targetFile
		File targetFile = new File(targetFileName);
		FileUtil.copyFile(srcFile, targetFile, true);
					
		logger.info(srcFile.getName() + " is moved to " + absTargetFilePath +  " successful!");
		
	}

}