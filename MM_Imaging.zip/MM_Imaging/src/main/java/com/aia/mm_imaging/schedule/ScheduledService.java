package com.aia.mm_imaging.schedule;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.aia.mm_imaging.service.CaptureService;
import com.aia.mm_imaging.util.StringUtil;
@Component
public class ScheduledService {

	int i=0;
	
	@Autowired
	CaptureService captureService;
	
    public void trigerCaptureJob(String captureFolder,String workingFolder,String backFolder,String errorFolder){
    	i++;
    	// 任务逻辑    
    	String captureId = StringUtil.getReqUUID();
    	System.out.println("captureFolder:" + captureFolder + " - 第"+(i)+"次开始执行操作... " +"时间：【" 
    			+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").format(new Date()) 
    			+ "】"); 
    	captureService.startCapture(captureFolder,workingFolder,backFolder,errorFolder);
    }
    
    public void trigerMoveJob(String captureFolder,String workingFolder,String backFolder,String errorFolder){
    	i++;
    	// 任务逻辑    
    	String captureId = StringUtil.getReqUUID();
    	System.out.println("moveFolder:" + captureFolder + " - 第"+(i)+"次开始执行操作... " +"时间：【" 
    			+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").format(new Date()) 
    			+ "】"); 
    	captureService.startMove(captureFolder,workingFolder,backFolder,errorFolder);
    }

    
    
    
//    @Scheduled(fixedRate = 5*1000 )
//    public void moveDocToWorkFolder() {
//    	System.out.println("1 fixedRate{} " + new Date());
//    }
    
   
   
  
}
