package com.aia.mm_imaging.dao;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.aia.mm_imaging.pojo.AuditTrail;
import com.aia.mm_imaging.pojo.DocInfo;
@Mapper
public interface DocumentDao {

	/**
	 * @param pol_num List
	 * @return polDocList
	 */
	 List<DocInfo> getDocInfoByPol(Map<String,String> params);
	
	
	/**
	 * @param id
	 * @return DocInfo
	 */
	
	 List<DocInfo> getDocById(Map<String,Object> params);
	/**
	 * @return List
	 */
	
	 List<Map<String, String>> getCategoryList();
	/**
	 * @param form_category
	 * @return  List
	 */
	
	 List<Map<String, String>> getCategoryByCategory(@Param("formCategory") String form_category);
	 /**
	 * @param docInfo
	 */
	void saveDocInfo(DocInfo docInfo);
	/**
	 * @param auditTrail
	 */
	void insertDocAuditTrail(AuditTrail auditTrail);
	/**
	 * @param params
	 */
	void insertPolLink(Map<String, String> params);
	
	/**
	 * @param params
	 */
	void insertAgentLink(Map<String, String> params);
	
	/**
	 * @param formId
	 */
	List<Map<String, Object>> isFormExist(Map<String,String> params);
    
    /**
	 * @param policyNo, formId, sourceSystem, fileName
	 */
    List<Map<String, Object>> getDocIdByFileName(Map<String,String> params);
    /**
     * @param policyNo, formId, sourceSystem, fileName
     */
    String getCategoryByFormId(String formId);
    
    void deleteDoc(String docId);
    void deleteDocForPol(String docId);
    void deleteDocForAgent(String docId);

}
