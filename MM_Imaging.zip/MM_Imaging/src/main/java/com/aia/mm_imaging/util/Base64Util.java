package com.aia.mm_imaging.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

public class Base64Util implements AutoCloseable {
	public static void base64StringToPdf(String base64Content,String filePath) throws IOException{
		 byte[] bytes = Base64.getDecoder().decode(base64Content);
		 File file = new File(filePath);
		    File path = file.getParentFile();
		    if(!path.exists()){
		        path.mkdirs();
		    }
		try(
				ByteArrayInputStream byteInputStream = new ByteArrayInputStream(bytes);
				BufferedInputStream bis= new BufferedInputStream(byteInputStream);
				FileOutputStream fos= new FileOutputStream(file);
				BufferedOutputStream bos= new BufferedOutputStream(fos)){
			    byte[] buffer = new byte[1024];
			    int length = bis.read(buffer);
			    while(length != -1){
			        bos.write(buffer, 0, length);
			        length = bis.read(buffer);
			    }
			    bos.flush();
		}
        
            
            
        
    }


    public static String PDFToBase64(File file) throws IOException{
        String base64 = null;
        try(FileInputStream fin = new FileInputStream(file);
        		 BufferedInputStream bin = new BufferedInputStream(fin);
        		 ByteArrayOutputStream baos= new ByteArrayOutputStream();
        		BufferedOutputStream bout = new BufferedOutputStream(baos)){
            
            byte[] buffer = new byte[1024];
            int len = bin.read(buffer);
            while(len != -1){
                bout.write(buffer, 0, len);
                len = bin.read(buffer);
            }
            //刷新此输出流并强制写出所有缓冲的输出字节
            bout.flush();
            byte[] bytes = baos.toByteArray();
            base64= Base64.getEncoder().encodeToString(bytes).trim();      
        } 
        return base64;
    }


	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
}
