package com.aia.mm_imaging.pojo;

public class DocInfo {
	private String docId;
	private String polNum;
	private String formId;
	private String formNm;
	private String formCategory;
	private String fileNm;
	private String filePath;
	private String createBy;
	private String createDate;
	private String updateBy;
	private String updateDate;
	private String LastModified;
	private String LastModifiedBy;
	private Integer isDeleted;
	private String sourceSystem;
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getPolNum() {
		return polNum;
	}
	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getFormNm() {
		return formNm;
	}
	public void setFormNm(String formNm) {
		this.formNm = formNm;
	}
	public String getFormCategory() {
		return formCategory;
	}
	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getLastModified() {
		return LastModified;
	}
	public void setLastModified(String lastModified) {
		LastModified = lastModified;
	}
	public String getLastModifiedBy() {
		return LastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		LastModifiedBy = lastModifiedBy;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	@Override
	public String toString() {
		return "DocInfo [docId=" + docId + ", polNum=" + polNum + ", formId=" + formId + ", formNm=" + formNm
				+ ", formCategory=" + formCategory + ", fileNm=" + fileNm + ", filePath=" + filePath + ", createBy="
				+ createBy + ", createDate=" + createDate + ", updateBy=" + updateBy + ", updateDate=" + updateDate
				+ ", LastModified=" + LastModified + ", LastModifiedBy=" + LastModifiedBy + ", isDeleted=" + isDeleted
				+ ", sourceSystem=" + sourceSystem + "]";
	}
	

	
	
}
