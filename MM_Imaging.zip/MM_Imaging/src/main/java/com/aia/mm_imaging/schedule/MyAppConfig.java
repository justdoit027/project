package com.aia.mm_imaging.schedule;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.util.StringUtils;

import com.aia.mm_imaging.util.NetUtils;
import com.aia.mm_imaging.util.PropertiesUtil;
import com.aia.mm_imaging.util.PropertyUtil;

@Configuration
@EnableScheduling
public class MyAppConfig implements SchedulingConfigurer {

    @Bean
    public ScheduledService mySchedulerService() {
        return new ScheduledService();
    }

    @Bean(destroyMethod = "shutdown")
    public Executor taskExecutor() {
        return Executors.newScheduledThreadPool(10);
    }
    
    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.setScheduler(taskExecutor());

        String captureFolderConfig = PropertiesUtil.getPropertyValues("CAPTURE_FODLER");
        
        String workingFolderName = PropertiesUtil.getPropertyValues("WORKING_FOLDER_NAME");
		String backupFolderName = PropertiesUtil.getPropertyValues("BACKUP_FOLDER_NAME");
		String errorFolderName = PropertiesUtil.getPropertyValues("ERROR_FOLDER_NAME");
		//String serverName = PropertiesUtil.getPropertyValues("SERVER_NAME");
		String serverName = NetUtils.getHostName();
		String workingFolder = "";
		String backFolder = "";
		String errorFolder = "";
		
//		CAPTURE_FODLER=IL_Staging;iPOS_Staging;Agent_Staging
//		#folderpath,captureStatus,captureTimeConfig,moveStatus,moveTimeConfig
//		IL_Staging=\\\\10.112.101.42\\MM_Imaging_Staging\\IL_Staging,Y,60000,Y,5000
//		iPOS_Staging=\\\\10.112.101.42\\MM_Imaging_Staging\\iPOS_Staging,Y,60000,Y,5000
//		Agent_Staging=\\\\10.112.101.42\\MM_Imaging_Staging\\Agent_Staging,Y,60000,Y,5000

		if(captureFolderConfig.indexOf(";")>0){
			String[] captureFolderConfigs = captureFolderConfig.split(";");
			for(String folder : captureFolderConfigs){
				String folderInfo = PropertiesUtil.getPropertyValues(folder);
				if (!StringUtils.isEmpty(folderInfo) && folderInfo.indexOf(",") > 0) {
					String[] folderInfoArray = folderInfo.split(",");
					String captureFolder = folderInfoArray[0];
					String captureStaus = folderInfoArray[1];
					String captureTimeConfig = folderInfoArray[2];
					String moveStatus = folderInfoArray[3];
					String moveTimeConfig = folderInfoArray[4];

					if(captureFolder.endsWith(File.separator)){
						workingFolder = captureFolder + workingFolderName + serverName;
						backFolder = captureFolder + backupFolderName; 
						errorFolder = captureFolder + errorFolderName; 
					}else{
						workingFolder = captureFolder + File.separator + workingFolderName + serverName;
						backFolder = captureFolder + File.separator + backupFolderName; 
						errorFolder = captureFolder + File.separator + errorFolderName; 
					}
					// 1.check folder structure exist,
					// checkFolderStructure(String stagingPath)
					//2.if not, perform initialization
					// stagingFolderInit(String stagingPath)
					File workingFile = new File(workingFolder);  
					if(!workingFile.exists()){
						workingFile.mkdirs();
					}
					File backFile = new File(backFolder);  
					if(!backFile.exists()){
						backFile.mkdirs();
					}
					File errorFile = new File(errorFolder);  
					if(!errorFile.exists()){
						errorFile.mkdirs();
					}
					
					if ("Y".equals(captureStaus)) {
						addTask(taskRegistrar,"capture",captureTimeConfig,captureFolder,workingFolder,backFolder,errorFolder);
					}
					if ("Y".equals(moveStatus)) {
						addTask(taskRegistrar,"move",moveTimeConfig,captureFolder,workingFolder,backFolder,errorFolder);
					}
					
				}
				
			}
		}
		
	}

	private void addTask(ScheduledTaskRegistrar taskRegistrar,String type,String timeConfig,String captureFolder,String workingFolder,String backFolder,String errorFolder) {
		taskRegistrar.addTriggerTask(
                new Runnable() {
                    @Override public void run() {
                    	if("capture".equals(type)){
                    		mySchedulerService().trigerCaptureJob(captureFolder,workingFolder,backFolder,errorFolder);
                    	}
                    	if("move".equals(type)){
                    		mySchedulerService().trigerMoveJob(captureFolder,workingFolder,backFolder,errorFolder);
                    	}
                    	 
                    }
                },
                new Trigger() {
                    @Override 
                    public Date nextExecutionTime(TriggerContext triggerContext) {
                        Calendar nextExecutionTime =  new GregorianCalendar();
                        Date lastActualExecutionTime = triggerContext.lastActualExecutionTime();
                        nextExecutionTime.setTime(lastActualExecutionTime != null ? lastActualExecutionTime : new Date());
                        nextExecutionTime.add(Calendar.MILLISECOND, Integer.valueOf(timeConfig));
                        return nextExecutionTime.getTime();
                    }
                }
        );
	}
}
