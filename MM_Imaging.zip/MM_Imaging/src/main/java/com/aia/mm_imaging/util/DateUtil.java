package com.aia.mm_imaging.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	//format  YYYYMMDDhhmmss
public static String getDateStr() {
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmss");

	return simpleDateFormat.format(new Date());
	
}
/** 
 * String to date 
 * @param seconds 精确到秒的字符串 
 * @param formatStr 
 * @return 
 */  
public static String strToDate(String datestr,String format) {  
    if(datestr == null || datestr.isEmpty() || datestr.equals("null")){  
        return null;  
    }  
    if(format == null || format.isEmpty()){
        format = "dd/MM/yyyy";
    }   
    SimpleDateFormat sdf = new SimpleDateFormat(format); 
    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    Date date = new Date();
	try {
		date = sdf.parse(datestr);
	} catch (ParseException e) {
		e.printStackTrace();
	}
    return sdf2.format(date);
}
/** 
 * String to date 
 * @param seconds 精确到秒的字符串 
 * @param formatStr 
 * @return 
 */  
public static String DateToStr(Date date,String format) {  
	if(date == null ){  
		return null;  
	}  
	if(format == null || format.isEmpty()){
		format = "yyyy-MM-dd HH:mm:ss.SSS";
	}   
	SimpleDateFormat sdf = new SimpleDateFormat(format); 
	
	return sdf.format(date);
}


public static void main(String[] args) {
	
	System.out.println(getDateStr());
	
}
}
