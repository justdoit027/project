package com.aia.mm_imaging.pojo;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.aia.mm_imaging.util.StringUtil;

/**
 * VO for web service output
 * 
 * @author bsnpcc1
 * @date 2019/8/6
 */
public class OutputVO {
	
	public static final String SUCCESS_CODE = "200";
	public static final String SUCCESS_MSG = "success";
	

	public OutputVO() {
		this.transactionId=StringUtil.getReqUUID();
	}


	// 200: success 4: fail . default 200
	private String code = SUCCESS_CODE;

	// if success, empty. else error message. default ""
	private String message = SUCCESS_MSG;
	
	private String transactionId;

	private Object data;
	
	
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	// turn VO to map
	public Map<String, Object> toMap() {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("code", code);
		result.put("message", message);
		result.put("transactionId", transactionId);
		result.put("completedTime", new Date().getTime());
		result.put("data", data);
		return result;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


}