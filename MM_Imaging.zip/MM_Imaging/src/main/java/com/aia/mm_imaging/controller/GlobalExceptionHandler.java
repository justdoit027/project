package com.aia.mm_imaging.controller;

import java.util.Arrays;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RestController;

import com.aia.mm_imaging.pojo.OutputVO;
@RestController
@ControllerAdvice
public class GlobalExceptionHandler {
	Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    //https://jira.spring.io/browse/SPR-14651
    //4.3.5 supports RedirectAttributes redirectAttributes
	@InitBinder
    public void initBinder(WebDataBinder binder) {}
    @ExceptionHandler(value =Exception.class)
    public ResponseEntity<Map<String, Object>> handleException(Exception e ,HttpServletRequest request) {
    	logger.error(Arrays.toString(e.getStackTrace()));
    	logger.error(e.getMessage());
    	OutputVO outputVO = new OutputVO();
    	outputVO.setCode("E000");
		outputVO.setMessage(e.getMessage());
		logger.error(e.getMessage(), request);
		e.printStackTrace();
		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
