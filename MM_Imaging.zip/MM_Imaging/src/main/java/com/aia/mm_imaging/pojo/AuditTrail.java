package com.aia.mm_imaging.pojo;
public class AuditTrail {
	private String rowId;
	private String docId;
	private String action;
	private String actionDesc;
	private String agentCd;
	private String polNum;
	private String captureId;
	private String createBy;
	private String createDate;
	private String updateBy;
	private String updateDate;
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getActionDesc() {
		return actionDesc;
	}
	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}
	public String getAgentCd() {
		return agentCd;
	}
	public void setAgentCd(String agentCd) {
		this.agentCd = agentCd;
	}
	public String getPolNum() {
		return polNum;
	}
	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}
	public String getCaptureId() {
		return captureId;
	}
	public void setCaptureId(String captureId) {
		this.captureId = captureId;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public AuditTrail(String rowId, String docId, String action, String actionDesc, String agentCd, String polNum,
			String captureId, String createBy, String createDate, String updateBy, String updateDate) {
		super();
		this.rowId = rowId;
		this.docId = docId;
		this.action = action;
		this.actionDesc = actionDesc;
		this.agentCd = agentCd;
		this.polNum = polNum;
		this.captureId = captureId;
		this.createBy = createBy;
		this.createDate = createDate;
		this.updateBy = updateBy;
		this.updateDate = updateDate;
	}
	public AuditTrail() {
		super();
	}
	@Override
	public String toString() {
		return "AuditTrail [rowId=" + rowId + ", docId=" + docId + ", action=" + action + ", actionDesc=" + actionDesc
				+ ", agentCd=" + agentCd + ", polNum=" + polNum + ", captureId=" + captureId + ", createBy=" + createBy
				+ ", createDate=" + createDate + ", updateBy=" + updateBy + ", updateDate=" + updateDate + "]";
	}
	
}
