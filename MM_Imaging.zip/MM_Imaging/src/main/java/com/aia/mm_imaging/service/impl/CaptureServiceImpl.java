package com.aia.mm_imaging.service.impl;

import java.io.File;
import java.io.FileFilter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aia.mm_imaging.dao.DocumentDao;
import com.aia.mm_imaging.service.CaptureService;
import com.aia.mm_imaging.util.FileUtil;
import com.aia.mm_imaging.util.InitUtil;

@Service
@Scope("prototype")
public class CaptureServiceImpl extends Thread implements CaptureService {
	
	private static Logger logger = LoggerFactory.getLogger(CaptureServiceImpl.class);
	
	@Autowired
	private DocumentDao documentDao;

	@Override
	public void startCapture(String captureFolder, String workingFolder, String backFolder, String errorFolder) {
		// 1.check folder structure exist, if not, perform initialization
		//FileUtil.checkAndPerformInit(stagingPath);
		// 2.Scan files (lastModifyTime before 15*60 s) to working folder(/stage_serverNm)	
		// 3.loop to do capture
		ExecutorService threadPool = null;
		try {
			String targetFilePath = InitUtil.getFilestoreFolder();
			String fileType = InitUtil.getFileType();
			int extractDocThreadNum = InitUtil.getExtractDocThreadNum();
			long interval = InitUtil.getInterval();
			
			String submitChannel = getSubmitChannel(captureFolder);
			threadPool = Executors.newFixedThreadPool(extractDocThreadNum);
			ThreadPoolExecutor threadPoolExecutor = null;
			
			logger.info(" Processing file path ::" + workingFolder);
			File file = new File(workingFolder);
			//long currentTime = System.currentTimeMillis();
			//long endTime = currentTime + interval;
			
			//while(currentTime<=endTime){}
			

			FileFilter filter = new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					return pathname.isFile();
							//&& pathname.getName().endsWith(fileType);
				}
			};
			File[] tempList = file.listFiles(filter);

			if (tempList.length == 0) {
				// every wait time will be 10 minutes.
				logger.info("No File found for capture, waiting....");
				Thread.sleep(1000);
				//startCapture(captureFolder);
				//continue;
				return;
			}
			
			for (int i = 0; i < tempList.length; i++) {

				logger.info("Current processing file:"
						+ tempList[i].getAbsoluteFile());
				

				if (threadPool instanceof ThreadPoolExecutor) {
					threadPoolExecutor = (ThreadPoolExecutor) threadPool;

				}
				while (null != threadPoolExecutor
						&& threadPoolExecutor.getActiveCount() == extractDocThreadNum) {
					Thread.sleep(1000);
				}
				
				logger.info("active Thread number:" + threadPoolExecutor.getActiveCount());
					
					Thread.sleep((long) (50 * (threadPoolExecutor.getActiveCount() + 0.1)) );
					
					threadPool.execute(new DoCaptureProcess(documentDao,tempList[i],targetFilePath,backFolder,errorFolder,submitChannel));
			}

			while (threadPoolExecutor.getActiveCount() > 0) {
				logger.info("current active thread:"
						+ threadPoolExecutor.getActiveCount());
				Thread.sleep(1000);
			}	
			
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
		} finally {
			logger.info("Leave startCapture() function now...");
		}
		
		if(threadPool!=null){
			threadPool.shutdown();
		}
	
	}

	//@Async
	@Override
	public void startMove(String captureFolder, String workingFolder, String backFolder, String errorFolder) {
		logger.info("------startMove " + captureFolder +" start------");
		
		try {
			
			String fileType = InitUtil.getFileType();
	
			logger.info(" Move from file path ::" + captureFolder);
			System.out.println(" Move from file path ::" + captureFolder);
			File file = new File(captureFolder);
			FileFilter filter = new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					return pathname.isFile();
							//&& pathname.getName().endsWith(fileType);
				}
			};
			File[] tempList = file.listFiles(filter);

			if (tempList.length == 0) {
				// every wait time will be 10 minutes.
				logger.info("No File found for move, waiting....");
			}else{	
				
				for (int i = 0; i < tempList.length; i++) {
					logger.info("Current moving file:" + tempList[i].getAbsoluteFile());
					File newFile = new File(workingFolder, tempList[i].getName());
					String movingFileName = null;
					
					if(workingFolder.endsWith(File.separator)){
						movingFileName = workingFolder + tempList[i].getName();
					}else{
						movingFileName = workingFolder + File.separator + tempList[i].getName();
					}
					File movingFile = new File(movingFileName);
					
					FileUtil.moveFile(tempList[i], movingFile);
					
				}
				
			}
					
		} catch (Exception e) {
			logger.error(e.toString());
			e.printStackTrace();
		}
			
		logger.info("------startMove " + captureFolder +" end------");
					
	}
	
	
	public String getSubmitChannel(String captureFolder){
		String submissionChannel = null;
		String folderNm = null;
		
		if(captureFolder.endsWith(File.separator)){
			String snm = captureFolder.substring(0,captureFolder.length()-1);
			folderNm = snm.substring(snm.lastIndexOf(File.separator)+1, snm.length());
		}else{
			folderNm = captureFolder.substring(captureFolder.lastIndexOf(File.separator)+1,captureFolder.length());
		}
		
		String[] folderNms = folderNm.split("_");
		submissionChannel = folderNms[1];
		
		return submissionChannel;
	}
	
}
