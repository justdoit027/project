package com.aia.mm_imaging.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.apache.commons.io.FileUtils;
import org.springframework.util.StringUtils;

public class FileUtil implements AutoCloseable {
	
	public synchronized static Boolean fileChannelCopy(File s, File t) {
		//logger.info("start copy");
		try(FileInputStream fi = new FileInputStream(s);
			FileOutputStream fo = new FileOutputStream(t);
			FileChannel in = fi.getChannel();
			FileChannel out = fo.getChannel();
			FileInputStream md5ValidationIn = new FileInputStream(t);
			FileChannel md5ValidationInChannel = md5ValidationIn.getChannel()) {
			String oMD5 = generateFileMD5(s, in);
			in.transferTo(0, in.size(), out);
			String nMD5 = generateFileMD5(t, md5ValidationInChannel);

			Boolean res = false;
			if (oMD5 == null) {
				res = false;
			} else {
				if (oMD5.equals(nMD5)) {
					res = true;
				}
			}
			if (!res) {
				if (t != null) {
					t.delete();
				}
			}
			//logger.info("copy over:");
			return res;
		} catch (IOException e) {
			//logger.info("copy error:", e);
		} catch (NoSuchAlgorithmException e) {
			//logger.info("copy error:", e);
		} 
		//logger.info("end copy");
		return false;
	}

	public static String generateFileMD5(File f, FileChannel in)
			throws NoSuchAlgorithmException, IOException {
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		MappedByteBuffer bytebuffer = in.map(FileChannel.MapMode.READ_ONLY, 0,
				f.length());
		md5.update(bytebuffer);
		BigInteger bi = new BigInteger(1, md5.digest());
		String oMD5 = bi.toString();
		return oMD5;
	}

    /**
     * Apache commons-io copy 
     * @param srcFile
     * @param destFile
     * @param preserveFileDate
     * @throws IOException
     */
    public static void copyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
    	if(destFile.isFile()&&destFile.exists()){
    		destFile.delete();
    	}
    	FileUtils.copyFile(srcFile, destFile, preserveFileDate);
    }
    /**
     * Apache commons-io move  
     * When the destination file is on another file system, do a "copy and delete".
     * @param srcFile
     * @param destFile
     * @throws IOException
     */
    public static void moveFile(File srcFile, File destFile) throws IOException {
    	if(destFile.isFile()&&destFile.exists()){
    		destFile.delete();
    	}
    	FileUtils.moveFile(srcFile, destFile);
    }
    /**
     * Apache commons-io move
     * @param srcFile
     * @param destDir
     * @param createDestDir If true create the destination directory, otherwise if false throw an IOException
     * @throws IOException 
     */
    public static void moveFileToDirectory(File srcFile, File destDir, boolean createDestDir) throws IOException {
    	FileUtils.moveFileToDirectory(srcFile, destDir, createDestDir);
    }
    /**
     * Apache commons-io move
     * Moves a file or directory to the destination directory. 
     * When the destination is on another file system, do a "copy and delete".
     * @param src
     * @param destDir
     * @param createDestDir
     * @throws IOException
     */
    public static void moveToDirectory(File src, File destDir, boolean createDestDir) throws IOException {
    	FileUtils.moveToDirectory(src, destDir, createDestDir);
    }
   
	
	/**
	 * copy file
	 * @param fromPath : from folder
	 * @param fromFileName : from file name
	 * @param toPath : to folder
	 * @param toPathFileName : to file name
	 * @param deleteSource : true to delete from file, false to not delete
	 * @return true success . false failed
	 * @author bsnpbys 2017/11/17
	 */
	public static boolean copyFile(String fromPath, String fromFileName, String toPath, String toPathFileName, boolean deleteSource){
		File fFromFile = new File(fromPath + fromFileName);
		File toPathFile = new File(toPath + toPathFileName);
		try(BufferedReader br = new BufferedReader(new FileReader(fFromFile));
				BufferedWriter bw = new BufferedWriter(new FileWriter(toPathFile))){
			if(fromPath == null || "".equalsIgnoreCase(fromPath.trim()) || fromFileName == null || "".equalsIgnoreCase(fromFileName.trim())){
				throw new RuntimeException("copy File failed : unknow from file path fromPath:" + fromPath + " fromFileName:" + fromFileName);
			}
			File fFrom = new File(fromPath);
			if(!fFrom.exists()){
				throw new RuntimeException("copy File failed : unknow from file path :" + fromPath);
			}
			if(!fromPath.endsWith("\\") || !fromPath.endsWith("/")){
				fromPath += File.separator;
			}
			
			if(!fFromFile.exists()){
				throw new RuntimeException("copy File failed : unknow from file path :" + fromPath + fromFileName);
			}
			if(toPathFileName == null || "".equalsIgnoreCase(toPathFileName.trim())){
				toPathFileName = fromFileName;
			}
			File fTo = new File(toPath);
			if(!fTo.exists()){
				fTo.mkdirs();
			}
			if(!toPath.endsWith("\\") || !toPath.endsWith("/")){
				toPath += File.separator;
			}
			
			if(!toPathFile.exists()){
				toPathFile.createNewFile();
			}
			
			String s = "";
			while ((s = br.readLine()) != null) {
				bw.write(s + "\r\n");
			}
			if(deleteSource){
				fFromFile.delete();
			}
		} catch (Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
	static String resourcePath = "";

	public static String getResourcePath() {
		if ("".equals(resourcePath)) {
			try {
				resourcePath = new File(Class.class.getClass().getResource("/")
						.getPath()).getParent();
				resourcePath = resourcePath.replace("%20", " ");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return resourcePath;
	}
	/**
	 * use IO
	 * @return
	 */
	public static boolean moveFile(String fromPath, String fromFileName, String toPath, String toPathFileName) {
		boolean result = copyFile(fromPath, fromFileName, toPath, toPathFileName, true);
		return result;
	}
	/**
	 * get file absolute path in file server
	 * 
	 * @param sfileName
	 * @param formCategory
	 * @return file absolute path in file server
	 */
	public static String getAbsFilePath(String sfileName, String formCategory) {
		if (StringUtils.isEmpty(sfileName) || StringUtils.isEmpty(formCategory)) {
			return null;
		}
		String fileName = sfileName.substring(0,sfileName.lastIndexOf("."));
		String[] fileFields =  fileName.split("_");
		
		String policyNo = fileFields[0];
		String formId = fileFields[1];
		String submissionChannel = fileFields[2];
		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(formId) || StringUtils.isEmpty(submissionChannel)) {
			return null;
		}
		return getAbsFilePath(policyNo,formId,submissionChannel, formCategory);
	}
	/**
	 * get file absolute path in file server
	 * 
	 * @param sfileName
	 * @param policyNo or agent code
	 * @param formId
	 * @param submissionChannel
	 * @param formCategory
	 * @return file absolute path in file server
	 */
	public static String getAbsFilePath(String policyNo,String formId,String submissionChannel, String formCategory) {
		String fileStoreRootPath = PropertyUtil.getCommonProperty("FILESTORE_FOLDER");
		if (StringUtils.isEmpty(fileStoreRootPath)){
			return null;
		}
		String fileRelPath = "";
		if("AGENT".equals(submissionChannel.toUpperCase())){
			// /AgentDoc/AgentCode/Category/Form ID/fileName.pdf
			fileRelPath = File.separator + "AgentDoc" + File.separator + policyNo + File.separator + formCategory + File.separator + formId + File.separator ; 
		}else{
			// /PolicyDoc/First 3 digits of Policy//second 3 digits of Policy /Policy Number /Category /Form ID /fileName.pdf
			fileRelPath = File.separator + "PolicyDoc" + File.separator + policyNo.substring(0, 3) + File.separator
					+ policyNo.substring(3, 6) + File.separator + policyNo + File.separator + formCategory + File.separator + formId + File.separator;
		}
		
		String absTargetFilePath = fileStoreRootPath + fileRelPath;
		File absTargetFile = new File(absTargetFilePath);  
		if(!absTargetFile.exists()){
			absTargetFile.mkdirs();
		}
		return absTargetFilePath;
	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
}
