package com.aia.mm_imaging.util;

public class InitUtil {

	private static long maxFileSize;
	private static String fileType;
	private static String filestoreFolder;
	private static int extractDocThreadNum;
	private static long interval;
	private static String submissionChannels;
	private static String submissionChannelsAg;
	
	public static long getMaxFileSize() {
		maxFileSize = Long.parseLong((String) PropertiesUtil.getPropertyValues("MAX_FILE_SIZE"));
		return maxFileSize;
	}
	public static void setMaxFileSize(long maxFileSize) {
		InitUtil.maxFileSize = maxFileSize;
	}
	public static String getFileType() {
		fileType = PropertiesUtil.getPropertyValues("FILE_TYPE");
		return fileType;
	}
	public static void setFileType(String fileType) {
		InitUtil.fileType = fileType;
	}
	public static String getFilestoreFolder() {
		filestoreFolder = PropertiesUtil.getPropertyValues("FILESTORE_FOLDER");
		return filestoreFolder;
	}
	public static void setFilestoreFolder(String filestoreFolder) {
		InitUtil.filestoreFolder = filestoreFolder;
	}
	public static int getExtractDocThreadNum() {
		extractDocThreadNum = Integer.parseInt(PropertiesUtil.getPropertyValues("EXTRACT_DOC_THREAD_NUM"));
		return extractDocThreadNum;
	}
	public static void setExtractDocThreadNum(int extractDocThreadNum) {
		InitUtil.extractDocThreadNum = extractDocThreadNum;
	}
	public static long getInterval() {
		interval = Long.parseLong((String)PropertiesUtil.getPropertyValues("INTERVAL"));
		return interval;
	}
	public static void setInterval(long interval) {
		InitUtil.interval = interval;
	}
	public static String getSubmissionChannels() {
		submissionChannels = PropertiesUtil.getPropertyValues("SUBMISSION_CHANNELS");
		return submissionChannels;
	}
	public static void setSubmissionChannels(String submissionChannels) {
		InitUtil.submissionChannels = submissionChannels;
	}
	
	public static String getSubmissionChannelsAg() {
		submissionChannelsAg = PropertiesUtil.getPropertyValues("SUBMISSION_CHANNELS_AG");
		return submissionChannelsAg;
	}
	public static void setSubmissionChannelsAg(String submissionChannelsAg) {
		InitUtil.submissionChannelsAg = submissionChannelsAg;
	}
		
}
