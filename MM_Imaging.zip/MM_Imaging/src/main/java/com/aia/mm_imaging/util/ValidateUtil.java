package com.aia.mm_imaging.util;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.mm_imaging.dao.DocumentDao;

@Component
public class ValidateUtil {
	
	private final static String fileType = InitUtil.getFileType();
//	private final static String datetimeFormatString = InitUtil.getDatetimeFormat();
	private final static long maxFileSize = InitUtil.getMaxFileSize();
	private final static String submissionChannels = InitUtil.getSubmissionChannels();
	private final static String submissionChannelAg = InitUtil.getSubmissionChannelsAg();
	
	@Autowired
	private DocumentDao documentDao1;
	
	private static DocumentDao documentDao;
	
	@PostConstruct
	public void init(){
		documentDao = documentDao1;
	}
	
	public static String checkFileName(String sfileName, String submitChannel) throws Exception{
		//File name format([PolicyNO]_[FORMID]_channel_YYYYMMDDhhmmss.EXT_NAME)
		String message = "";
		//boolean isValid = false;		
		if(sfileName==null||sfileName.isEmpty()){
			message = "FileName can't be null or empty." ;
			return message;
		}
		
		String fileName = sfileName.substring(0,sfileName.lastIndexOf("."));
		String[] fileFields =  fileName.split("_");
		if(fileFields.length<4){
			message = "The name of " + sfileName + " contains at least policyNo, formId, submissionChannel, datetime." ;
			return message;
		}
		
		String formId = fileFields[1];
		String submissionChannel = fileFields[2];
		String datetime = fileFields[3];
		if(submissionChannels.toUpperCase().contains(submitChannel.toUpperCase())){
			//IL/iPOS
			String policyNo = fileFields[0];
			message = checkPolicyNo(policyNo,message);
		}else if(submissionChannelAg.toUpperCase().contains(submitChannel.toUpperCase())){
			//Agent
			String agentCode = fileFields[0];
			message = checkAgentCode(agentCode,message);			
		}
		
		if(message.isEmpty()){
			message = checkFormId(formId,message);
			//if(message.isEmpty()){
			if(message.contains("FORM_CATEGORY")){
				message = checkChannel(submissionChannel,message,submitChannel);
				//if(message.isEmpty()){
				if(message.contains("FORM_CATEGORY")){
					message = datetimeFormat(datetime,message);
				}
			}
		}
		
		return message;
		
	}
	
	public static String checkPolicyNo(String policyNo, String message){
		//String message = "";
		if(policyNo==null||policyNo.isEmpty()){
			message = "Policy no can't be null or empty.";
		}else if(policyNo.length()!=10){
			message = "Length of policy no " + policyNo + " should be 10.";
		}	
		return message;
	}
	
	public static String checkAgentCode(String agentCode, String message){
		//String message = "";
		if(agentCode==null||agentCode.isEmpty()){
			message = "Agent code can't be null or empty.";
		}else if(agentCode.length()!=6){
			message = "Length of agent code " + agentCode + " should be 6.";
		}	
		return message;
	}
	
	public static String checkFormId(String formId, String message){		
		String msg = "";
		if(formId==null||formId.isEmpty()){
			msg = "Form id can't be null or empty.";
		}/*else if(formId.length()!=7){  //need confirm, not found in FS
			message = "Length of formId " + formId + " should be 7.";
		}*/else{
			//check in db
			Map<String, String> formMap = new HashMap<String, String>();
			formMap.put("formId", formId);
			
			List<Map<String, Object>> forms = documentDao.isFormExist(formMap);
			if(forms==null||forms.size()==0){
				msg = "FormId " + formId + " is not exist in DB.";
			}else{
				String formCategory = (String) forms.get(0).get("FORM_CATEGORY");
				if(formCategory.isEmpty()){
					msg = "FormId " + formId + " is not exist in DB.";
				}else{
					msg = "FORM_CATEGORY:" + formCategory;
				}
			}		
		}
		return msg;		
	}
	
	public static String checkChannel(String submissionChannel,String message,String submitChannel){
		//String message = "";
		if(submissionChannel==null||submissionChannel.isEmpty()){
			message = "Submission channel can't be null or empty.";
		}else{ 
			
			if(submissionChannels.toUpperCase().contains(submitChannel.toUpperCase())){
				//IL/iPOS
				if(!submissionChannels.toUpperCase().contains(submissionChannel.toUpperCase())){
					
					//need confirm if need check the fixed value 'IL/IPOS'
					message = "Submission channel " + submissionChannel + " is not in " + submissionChannels;
				}
			
			}else if(submissionChannelAg.toUpperCase().contains(submitChannel.toUpperCase())){
				//Agent
				if(!submissionChannelAg.toUpperCase().contains(submissionChannel.toUpperCase())){
					
					//need confirm if need check the fixed value 'IL/IPOS'
					message = "Submission channel " + submissionChannel + " is not in " + submissionChannelAg;
				}
			}
			
		}
			
		return message;
	}
	
	public static String datetimeFormat(String datetime,String message){
		//String message = "";
		if(datetime==null||datetime.isEmpty()){
			message = "Datetime can't be null or empty.";
		}/*else{
			//format datetime //need confirm
			if(datetime.length()!=datetimeFormatString.length()){
				message = "Datetime format should be " + datetimeFormatString;
			}
		}	*/
		return message;		
	}
	
	public static String checkFileType(String fileName) throws Exception{
		String message = "";
		String fileExtension = fileName.substring(fileName.lastIndexOf(".")+1);
		if(!fileName.endsWith(fileType)){
			message = fileExtension + " is not supported, only support " + fileType;
		}		
		return message;	
	}
	
	public static String checkFileSize(String fileName) throws Exception{
		String message = "";
		File file = new File(fileName);
		if(file.exists()&&file.isFile()){
			long fileLength = file.length();
			if(fileLength>maxFileSize){
				message = "The size of the " + fileName + " is more than " + maxFileSize/(1024*1024) + " MB.";
			}		
		}
		
		return message;		
	}
	
	public static void checkExistDoc(Map<String,String> map){
		
		List<Map<String, Object>> docRet = documentDao.getDocIdByFileName(map);
		if(docRet!=null&&docRet.size()>0){
			for(Map<String, Object> doc:docRet){
				
				BigDecimal existDocId = doc.get("DOC_ID")==null?new BigDecimal(0):(BigDecimal) doc.get("DOC_ID");
				String SourceSystem = doc.get("SOURCE_SYSTEM")==null?"": doc.get("SOURCE_SYSTEM").toString();
				if(existDocId!=null||existDocId!=new BigDecimal(0)){
					documentDao.deleteDoc(existDocId.toString());
					if ("AGENT".equals(SourceSystem)) {
						documentDao.deleteDocForAgent(existDocId.toString());
					}
					if ("MANUAL".equalsIgnoreCase(SourceSystem)) {
						documentDao.deleteDocForPol(existDocId.toString());
					}
				}			
			}
		}
	
	}
		
}
