package com.aia.mm_imaging.ws;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.mm_imaging.pojo.OutputVO;
import com.aia.mm_imaging.service.DocumentService;
import com.alibaba.fastjson.JSONObject;

@RestController
public class DocumentController {

	@Autowired
	private DocumentService documentService;
	/**
	 * test //http:127.0.0.1:8080/doc/getDocListByPol
	 * 
	 * @return
	 */
	Logger logger = LoggerFactory.getLogger(DocumentController.class);

	@RequestMapping(value = "doc/getDocListByPol",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getDocListByPol(HttpServletRequest req,HttpServletResponse resp,@RequestBody JSONObject json) {
		logger.info("getDocListByPol start, params:" + json.toJSONString());
		String result = documentService.getDocListByPol(json.toJSONString(),"getDocListByPol");
		logger.info("getDocListByPol end, result:" + result);
		return result;
	}
	@RequestMapping(value = "doc/getDocListByAgentCode",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getDocListByAgentCode(HttpServletRequest req,HttpServletResponse resp,@RequestBody JSONObject json) {
		logger.info("getDocListByPol start, params:" + json.toJSONString());
		String result = documentService.getDocListByPol(json.toJSONString(),"getDocListByAgentCode");
		logger.info("getDocListByPol end, result:" + result);
		return result;
	}

	// http:127.0.0.1:8080/doc/getDocListByAgentCode
	/*
	 * @RequestMapping(value ="doc/getDocByAgentCode",method = RequestMethod.POST,
	 * produces = MediaType.APPLICATION_JSON_VALUE) public String
	 * getDocByAgentCode(HttpServletRequest req,HttpServletResponse
	 * resp,@RequestBody JSONObject json) { logger.info("getDocById start, params:"
	 * + json.toJSONString()); String result =
	 * documentService.getDocStrById(json.toJSONString(),"getDocByAgentCode");
	 * logger.info("getDocById end, result:" + result); return result; }
	 */
	// http:127.0.0.1:8080/doc/getDocById
	@RequestMapping(value ="doc/getDocById",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getDocById(HttpServletRequest req,HttpServletResponse resp,@RequestBody JSONObject json) {
		logger.info("getDocById start, params:" + json.toJSONString());
		String result = documentService.getDocStrById(json.toJSONString(),"getDocById");
		logger.info("getDocById end, result:" + result);
		return result;
	}

	// http:127.0.0.1:8080/form/listFormCategory
	@RequestMapping(value = "form/listFormCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> listFormCategory() {
		OutputVO outputVO = new OutputVO();
		try {
			outputVO = documentService.getCategoryList();
		} catch (Exception e) {
			e.printStackTrace();
			outputVO.setCode("E000");
			outputVO.setMessage(e.getMessage());
		}
		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
	}

	// http:127.0.0.1:8080/form/getFormInfoByCategory
	@RequestMapping(value = "form/getFormInfoByCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getFormInfoByCategory(HttpServletRequest req,HttpServletResponse resp,@RequestBody JSONObject json) {
		OutputVO outputVO = new OutputVO();
		try {
			System.out.println(json);
			System.out.println(json.toJSONString());
			outputVO = documentService.getCategoryByCategory(json.toJSONString());
		} catch (Exception e) {
			e.printStackTrace();
			outputVO.setCode("E000");
			outputVO.setMessage(e.getMessage());
		}
		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
	}
	// http:127.0.0.1:8080/form/upload
	@RequestMapping("form/upload")
	public ResponseEntity<Map<String, Object>> upLoad(@RequestBody String json) {
		OutputVO outputVO = new OutputVO();
		try {
			outputVO = documentService.uploadFile(json);
		} catch (Exception e) {
			outputVO.setCode("E000");
			outputVO.setMessage(e.getMessage());
			e.printStackTrace();
		}

		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);

	}

}
