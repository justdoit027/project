package com.aia.mm_imaging.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
/**
 * 
 * Add for dynamic loading properties change
 *
 */
public class PropertiesUtil {

    private static final String CONFIG_NAME = "common.properties";

    private static Properties prop;

    private static Long lastModified = 0L;

    public static void init() {
        prop = new Properties();
        String filepath = PropertiesUtil.class.getClassLoader().getResource(CONFIG_NAME).getPath();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(filepath);
            prop.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(fis != null){
                    fis.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *  
     * @return returnValue ：true/false
     */
    public static boolean isPropertiesModified() {
        boolean returnValue = false;
        File file = new File(PropertiesUtil.class.getClassLoader().getResource(CONFIG_NAME).getPath());
        if (file.lastModified() > lastModified) {
            lastModified=file.lastModified();
            returnValue = true;
        }
        return returnValue;
    }

    /**
     *  
     * @param key  
     * @return value
     */
    public static String getPropertyValues(String key) {

        if (prop == null || isPropertiesModified()) {
            init();
        }
        String value = prop.get(key).toString();
        return value;
    }

 
 
}
