package com.aia.mm_imaging.service;

public interface CaptureService {
	/**
	 * 
	 * @return severPath,status, desc, pi_schedule
	 */
	void startCapture(String captureFolder, String workingFolder, String backFolder, String errorFolder);
	
	void startMove(String captureFolder,String workingFolder, String backFolder, String errorFolder);
	
}
