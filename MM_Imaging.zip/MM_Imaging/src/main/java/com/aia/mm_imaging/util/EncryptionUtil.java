/**
 * @Project:iPoS_HongKong_Staging
 * @Title:Encryption.java 
 * @Package:aiahk.ipos.security
 * @Author:bsnpb1q
 * @date:2012-8-9
 * @version:
 * @CopyRight:2012 AIA Information Technology (Beijing) Co., Ltd.All Rights reserved
 * 
 * @Description:provide the encryption and zip function 
 */
package com.aia.mm_imaging.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Base64;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.DataHandler;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * 
 * @ClassName:Encryption
 * @Description:TODO
 * @author bsnpb1q
 */
public class EncryptionUtil {
	/**
	 * 
	 * @Title:cryptData
	 * @Description:TODO
	 * @param keyBytes
	 * @param data
	 * @param isEncrypt
	 * @Return byte[]
	 * @Throws
	 * 
	 */
	public byte[] cryptData(byte[] keyBytes, byte[] data, boolean isEncrypt) {
		byte[] ret = null;
		try {
			Security.addProvider(new BouncyCastleProvider());
			SecretKeySpec k = new SecretKeySpec(keyBytes, "AES");
			Cipher c;

			c = Cipher.getInstance("AES/CBC/PKCS7Padding", "BC");
			c.init(isEncrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, k,
					new IvParameterSpec(new byte[16]));
			ret = c.doFinal(data);

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (ExceptionInInitializerError e) {
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ret;
	}


	/**
	 * 
	 * @Title:unzip
	 * @Description:TODO
	 * @param zipData
	 * @Return byte[]
	 * @Throws
	 * 
	 */
	@SuppressWarnings("unused")
	public byte[] unzip(byte[] zipData) {
		if (zipData == null)
			return null;

		ByteArrayOutputStream dest = new ByteArrayOutputStream(zipData.length);
		ByteArrayInputStream fis = new ByteArrayInputStream(zipData);
		ZipInputStream zis = new ZipInputStream(new BufferedInputStream(fis));
		byte[] outData = null;
		try {
			ZipEntry entry;
			while ((entry = zis.getNextEntry()) != null) {
				// System.out.println("Extracting: " + entry);
				int count;
				int BUFFER = 1024;
				byte buffer[] = new byte[BUFFER];
				// write the files to the disk

				while ((count = zis.read(buffer, 0, BUFFER)) != -1) {
					dest.write(buffer, 0, count);
				}
				outData = dest.toByteArray();
				// dest.flush();
				// dest.close();
			}
			fis.close();
			zis.close();
			dest.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return outData;
	}

	/**
	 * 
	 * @Title:toBytes
	 * @Description:TODO
	 * @param dh
	 * @return
	 * @Return byte[]
	 * @Throws
	 * 
	 */
	public byte[] toBytes(DataHandler dh) {

		int INITIAL_SIZE = 1024 * 1024;
		int BUFFER_SIZE = 1024;
		ByteArrayOutputStream bos = new ByteArrayOutputStream(INITIAL_SIZE);

		InputStream in;
		try {
			in = dh.getInputStream();
			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead;

			while ((bytesRead = in.read(buffer)) >= 0) {
				bos.write(buffer, 0, bytesRead);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return bos.toByteArray();
	}

	/**
	 * 
	 * @Title:doSHA256Hashing
	 * @Description:TODO
	 * @param data
	 * @return
	 * @Return byte[]
	 * @Throws
	 * 
	 */

	public byte[] doSHA256Hashing(byte[] data) {
		byte[] bytes=null;
		if (data == null)
			return null;

		MessageDigest md = null;

		try {
			md = MessageDigest.getInstance("SHA-256");
			md.update(data);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		if (md!=null) {
			bytes= md.digest();
		}
		return bytes;
	}

/*	public static void main(String[] args) {
		String test="12342342424vdsfsf";
		String key="12345";
		EncryptionUtil encryption = new EncryptionUtil();
		byte[] bpass = encryption.doSHA256Hashing(key.getBytes());
		
		// encryption
		byte[] en=encryption.cryptData(bpass,test.getBytes(), true);
		String re=new String(Base64.getEncoder().encode(en));
		System.out.println(re);
		// Decrypt
		String aesDecrypt = new String(encryption.cryptData(bpass,Base64.getDecoder().decode(re), false));
		System.out.println(aesDecrypt);
	}*/
	public static String doEncryption(String data, String key) {
		EncryptionUtil encryption = new EncryptionUtil();
		byte[] bpass = encryption.doSHA256Hashing(key.getBytes());
		// encryption
		byte[] en=encryption.cryptData(bpass,data.getBytes(), true);
		return new String(Base64.getEncoder().encode(en));
	}
	public static String decrypt(String data, String key) {
		EncryptionUtil encryption = new EncryptionUtil();
		byte[] bpass = encryption.doSHA256Hashing(key.getBytes());
		// Decrypt
		String decryptResult = new String(encryption.cryptData(bpass,Base64.getDecoder().decode(data), false));
		return decryptResult;
	}
}
