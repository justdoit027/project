var PromptWindow = PromptWindow || {}; 
(function($) {
    /** * @constructor */
    function MessageBox() { 
        var PROMPT_OK = "OK";  
        var PROMPT_CONFIRM = "Confirm";  
        var PROMPT_CANCEL = "Cancel";  
        var PROMPT_DEFAULT_TITLE = "Message"; 
        /** @type {kendo.ui.Window}*/ 
        this.alertPromptWindow = null;
        /** @type {jQuery}*/
        this.$alertPromptWindow = null;
        /** @type {String}*/
        this.promptTitle = null;
        /** @type {String}*/
        this.promptIcon = null;  
        this.promptInfo = null;  
        this.promptType = null;  
        this.funs = [];
        this.ensureFun = null;
        this.deferred = null;  
        this.$prompt_window = null;  
        this.$prompt_button = null;  
        this.initPromptWindow = function () {  
        	var popWin = '<div class="prompt_window" style="padding: 0"><div class="window-content prompt_content"></div>' + '<div class="window-button-box prompt_button text-center"></div></div>';
	        this.$alertPromptWindow = $(popWin).kendoWindow({
	            //pinned: true,
	            modal: true,
	            //animation: true,
	            draggable: true,
	            resizable: false,
	            //visible: false,
	            actions: ["Close"],
	            title: PROMPT_DEFAULT_TITLE,
	            close: function(e) {
	                if (!e.userTriggered) {
	                    return;
	                }
	                this.$alertPromptWindow.parent().unbind("keypress");
	                this.deferred.resolve('close');
	                this.alertPromptWindow.destroy();
	                if (this.ensureFun != null && this.type == PromptWindow.TYPE_ALERT) {
	                    this.ensureFun();
	                    this.ensureFun = null;
	                } else if (this.cancelFun != null && (this.type == PromptWindow.TYPE_CONFIRM || this.type == PromptWindow.TYPE_CUSTOM_PROMPT)) {
	                    this.cancelFun();
	                    this.cancelFun = null;
	                }
	            }.bind(this)
	        });
	        this.$prompt_window = this.$alertPromptWindow.find(".prompt_content");
	        this.$prompt_button = this.$alertPromptWindow.find(".prompt_button");
	        this.alertPromptWindow = this.$alertPromptWindow.data("kendoWindow");
	        this.$alertPromptWindow.parent().mousemove(function(e) {
	            $(this).find(".prompt_button > .active").removeClass('active');
	        });
        };
	    /** 
	     * get content length
	     * @param {String} content 
	     * @returns {Number} 
	     */
	    this.getContentByteLength = function(content) {
	        content = content + "";
	        return content ? content.replace(/[^x00-xFF]/g, '**').length: 0;
	    };
	    /** 
	     * get window width
	     * @returns {number} 
	     */
	    this.getPromptWindowWidth = function() {
	        if (this.promptType === PromptWindow.PROMPT_STRUTS_TYPE_MIDDLE) {
	            return 600;
	        } else if (this.promptType === PromptWindow.PROMPT_STRUTS_TYPE_LARGE) {
	            return 940;
	        } else {
	            if (this.promptInfo != null && this.promptInfo != undefined) {
	                var contentLength = 0;
	                if (this.promptInfo instanceof Array) {
	                    var size = this.promptInfo.length;
	                    for (var i = 0; i < size; i++) {
	                        contentLength = this.getContentByteLength(this.promptInfo[i]);
	                        if (contentLength > 70 && contentLength <= 144) {
	                            return 600;
	                        } else if (contentLength > 144) {
	                            return 940;
	                        }
	                    }
	                } else {
	                    contentLength = this.getContentByteLength(this.promptInfo);
	                    if (contentLength > 70 && contentLength <= 144) {
	                        return 600;
	                    } else if (contentLength > 144) {
	                        return 940;
	                    }
	                }
	            }
	        }
	        return 307;
	    };

	    this.setPromptInformation = function() { 
	        if (this.alertPromptWindow != null && this.alertPromptWindow != undefined) {
	            this.alertPromptWindow.destroy();
	        } 
	        this.initPromptWindow(); 
	        var promptWindowObj = this.$alertPromptWindow.parent();
	        var promptTitlebar = promptWindowObj.find(".k-window-titlebar> span[class='k-window-title']");
	        promptTitlebar.empty();
	        if (this.promptIcon != null && this.promptIcon != undefined && this.promptIcon !== '') {
	            promptTitlebar.append('<img style="padding-right:8px;" src="' + this.promptIcon + '" />');
	        }
	        if (this.promptTitle != null && this.promptTitle != undefined) {
	            promptTitlebar.append('<span>' + this.promptTitle + '</span>');
	        } else {
	            promptTitlebar.append('<span>' + PROMPT_DEFAULT_TITLE + '</span>');
	        } 
			promptWindowObj.width(this.getPromptWindowWidth()); 
	        if (this.promptInfo != null && this.promptInfo != undefined) {
	            if (this.promptInfo instanceof Array) { 
	                var contentHtml = '<p>';
	                var size = this.promptInfo.length;
	                for (var i = 0; i < size; i++) {
	                    contentHtml += this.promptInfo[i];
	                    if (i < size - 1) {
	                        contentHtml += '<br />';
	                    }
	                }
	                contentHtml += '</p>';
	                this.$prompt_window.empty().append(contentHtml);
	            } else { 
	                this.$prompt_window.empty().append('<p class="promptTitle">' + this.promptInfo + '</p>');
	            }
	        }
	    };
	    /** 
	     * @param {String} defaultVal 
	     */
	    this.setPromptInput = function(defaultVal) {
	        var promptInput = $('<input type="text" class="k-textbox txtPromptWindow" value="' + defaultVal + '" style="width:100%;" />');
	        var that = this;
	        promptInput.focus(function() {
	            that.$alertPromptWindow.parent().unbind("keypress");
	        }.bind(this));
	        that.$prompt_window.append(promptInput);
	    };
	    /** 
	     * @param {Function} inputControlFun 
	     */
	    this.controlPromptInput = function(inputControlFun) {
	        if (inputControlFun) {
	            var input = this.$prompt_window.find(".txtPromptWindow");
	            input.keypress(inputControlFun); 
	            input.unbind("paste");
	            input.bind("paste",
	            function() {
	                return false;
	            });
	        }
	    };
	    /**
	     * @param {Function} ensureFun 
	     */
	    this.setAlertButton = function(ensureFun) {
	        this.deferred = new $.Deferred();
	        this.ensureFun = ensureFun;
	        var confirmBtn = $('<a class="button AIA-btn-primary popBtn active">' + PROMPT_OK + '</a>');
	        confirmBtn.click(function() {
	            this.$alertPromptWindow.parent().unbind("keypress"); 
	            this.alertPromptWindow.close();
	            this.alertPromptWindow.destroy();
	            if (ensureFun != null) {
	                ensureFun();
	            }
	            this.deferred.resolve('ok');
	        }.bind(this));
	        this.$prompt_button.empty().append(confirmBtn);
	        var that = this;
	        this.$alertPromptWindow.parent().keypress(function() {
	            var keyCode = event.keyCode;
	            if (keyCode === 13) {
	                that.$alertPromptWindow.parent().unbind("keypress");
	                that.alertPromptWindow.close();
	                that.alertPromptWindow.destroy();
	                if (ensureFun != null) {
	                    ensureFun();
	                }
	                that.deferred.resolve('ok');
	                event.returnValue = true;
	            } else if (keyCode === 27) {
	                that.$alertPromptWindow.parent().unbind("keypress");
	                if (ensureFun != null) {
	                    ensureFun();
	                }
	                that.deferred.resolve('ok');
	                event.returnValue = true;
	            } else {
	                event.returnValue = false;
	            }
	        });
	    };
	    /**   
	     * @param {Function} ensureFun  
	     * @param {Function} cancelFun 
	     */
	    this.setConfirmAndPromptButton = function(ensureFun, cancelFun) {
	        this.deferred = new $.Deferred();
	        this.ensureFun = ensureFun;
	        this.cancelFun = cancelFun;
	        var confirmBtn = $('<a class="button AIA-btn-primary popBtn active"><span class="buttonText">' + PROMPT_CONFIRM + '</span></a>');
	        confirmBtn.click(function() {
	            this.$alertPromptWindow.parent().unbind("keypress");
	            var promptText = this.$prompt_window.find(".txtPromptWindow").val();
	            this.alertPromptWindow.close(); 
	            if (ensureFun != null) {
	                ensureFun(promptText);
	            }
	            this.alertPromptWindow.destroy();
	            this.deferred.resolve('yes');
	        }.bind(this));
	        var that = this;
	        this.$alertPromptWindow.parent().keypress(function() {
	            var keyCode = event.keyCode;
	            var promptText;
	            if (keyCode === 13) {
	                that.$alertPromptWindow.parent().unbind("keypress");
	                that.alertPromptWindow.close();
	                that.alertPromptWindow.destroy();
	                promptText = that.$prompt_window.find(".txtPromptWindow").val();
	                if (ensureFun != null) {
	                    ensureFun(promptText);
	                }
	                that.deferred.resolve('yes');
	                event.returnValue = true;
	            } else if (keyCode === 27) {
	                that.$alertPromptWindow.parent().unbind("keypress");
	                promptText = that.$prompt_window.find(".txtPromptWindow").val();
	                if (cancelFun != null) {
	                    cancelFun(promptText);
	                }
	                that.deferred.resolve('yes');
	                event.returnValue = true;
	            } else {
	                event.returnValue = false;
	            }
	        });
	        var cancelBtn = $('<a class="button AIA-btn-primary popBtn"><span class="buttonText">' + PROMPT_CANCEL + '</span></a>');
	        cancelBtn.click(function() {
	            $(document).unbind("keypress");
	            var promptText = this.$prompt_window.find(".txtPromptWindow").val(); 
				// 取消，注销窗口并执行取消的方法 
	            this.alertPromptWindow.close();
	            this.alertPromptWindow.destroy();
	            if (cancelFun != null) {
	                cancelFun(promptText);
	            }
	            this.deferred.resolve('no');
	        }.bind(this));
	        this.$prompt_button.empty().append(confirmBtn);
	        this.$prompt_button.append(cancelBtn);
	    };
	    /** * 自定义提示框按钮 * @param {{text: String, receiptFun: Function}} buttons */
	    this.setCustomButton = function(buttons) {
	        this.deferred = new $.Deferred();
	        this.ensureFun = null;
	        this.cancelFun = null;
	        if (buttons != null && buttons.length > 0) { // 清空现有按钮 
	            this.$prompt_button.empty();
	            var btnSize = buttons.length;
	            this.funs = [];
	            for (var i = 0; i < btnSize; i++) {
	                var text = buttons[i].text; // 按钮文本 
	                var style = ''; // 按钮样式 
	                if (buttons[i].style) {
	                    style = buttons[i].style;
	                }
	                this.funs.push(buttons[i].receiptFun); 

	                if (buttons[i].type && buttons[i].type == "Cancel") {
	                    this.cancelFun = buttons[i].receiptFun;
	                }
	                var customBtn = null; 
					
	                if (i === 0) {
	                    customBtn = $('<a class="button AIA-btn-primary popBtn" keepWindowOpen="' + buttons[i].keepWindowOpen + '" data-func="' + i + '"><span class="buttonText" style="' + style + '">' + text + '</span></a>');
	                } else {
	                    customBtn = $('<a class="button AIA-btn-primary popBtn" keepWindowOpen="' + buttons[i].keepWindowOpen + '" data-func="' + i + '"><span class="buttonText" style="' + style + '">' + text + '</span></a>');
	                }
	                var that = this;
	                customBtn.click(function(e) {
	                    var $btn = $(this);
	                    window.setTimeout(function() {
	                        if (! (e.currentTarget && e.currentTarget.attributes && e.currentTarget.attributes.keepWindowOpen && e.currentTarget.attributes.keepWindowOpen.value === "true")) {  		     //注销窗口并执行回调的方法 
	                            that.alertPromptWindow.close();
	                            that.alertPromptWindow.destroy();
	                        }
	                        var funId = Number($btn.data("func"));
	                        var receiptFun = that.funs[funId];
	                        if (receiptFun != null) {
	                            receiptFun();
	                        }
	                        that.deferred.resolve(funId);
	                    },
	                    0);
	                });
	                this.$prompt_button.append(customBtn);
	            }
	        }
	    };

	    this.openWindow = function() { 
	        this.alertPromptWindow.center(); 
	        this.cleanPromptParam(); 
	        this.alertPromptWindow.open();
	    };
	    
	    this.closeWindow = function() {
	        this.alertPromptWindow.close();
	    };
	    
	    this.cleanPromptParam = function() {
	        this.promptTitle = PROMPT_DEFAULT_TITLE;
	        this.promptIcon = null;
	        this.promptType = PromptWindow.PROMPT_STRUTS_TYPE_LITTLE;
	        this.promptInfo = null;
	    };
	    /** 
		* @param {Function} ensureFun 
		* @returns {*} 
		*/
	    this.openAlert = function(ensureFun) {
	        this.setPromptInformation();
	        this.setAlertButton(ensureFun);
	        this.openWindow();
	        return this.deferred.promise();
	    };
	    /** 
		* @param {Function} ensureFun 
		* @param {Function} cancelFun 
		* @returns {*} 
		*/
	    this.openConfirm = function(ensureFun, cancelFun) {
	        this.setPromptInformation();
	        this.setConfirmAndPromptButton(ensureFun, cancelFun);
	        this.openWindow();
	        return this.deferred.promise();
	    };
	    /** 
		* @param {String} defaultVal 
		* @param {Function} ensureFun 
		* @param {Function} cancelFun 
		* @param {Function} inputControlFun 
		* @returns {*} 
		*/
	    this.openPrompt = function(defaultVal, ensureFun, cancelFun, inputControlFun) {
	        this.setPromptInformation();
	        this.setPromptInput(defaultVal);
	        this.controlPromptInput(inputControlFun);
	        this.setConfirmAndPromptButton(ensureFun, cancelFun);
	        this.openWindow();
	        return this.deferred.promise();
	    };
	    /** 
		* @param {{text: String, receiptFun: Function}} buttons 
		* @returns {*} 
		*/
	    this.openCustom = function(buttons) {
	        this.setPromptInformation();
	        this.setCustomButton(buttons);
	        this.openWindow();
	        return this.deferred.promise();
	    };
    }
	PromptWindow = (function() {
	    return { // small size(width:307px) 
	        PROMPT_STRUTS_TYPE_LITTLE: 'promptLittle',
	        // middle size(width:600px) 
	        PROMPT_STRUTS_TYPE_MIDDLE: 'promptMiddle',
	        // large size(width:940px) 
	        PROMPT_STRUTS_TYPE_LARGE: 'promptLarge',
	        TYPE_ALERT: "alert",
	        TYPE_CONFIRM: "confirm",
	        TYPE_PROMPT: "prompt",
	        TYPE_CUSTOM_PROMPT: "customPrompt",
	        /** 
	         * @param info {String}   
	         * @param ensureFun {function(string)=}   
	         * @param type {String=} 
	         * @param title {String=}  
	         * @param icon {String=} 
	         */
	        alert: function(info, ensureFun, type, title, icon) {
	            var mb = new MessageBox();
	            mb.promptInfo = info;
	            mb.promptType = type || this.PROMPT_STRUTS_TYPE_MIDDLE;
	            mb.promptTitle = title;
	            mb.promptIcon = icon;
	            mb.type = PromptWindow.TYPE_ALERT;
	            mb.openAlert(ensureFun);
	            return mb;
	        },
	        /** 
			* @param info {String}  
			* @param ensureFun {function(string)}  
			* @param cancelFun {function(string)}  
			* @param type {String=} 
			* @param title {String=} 
			* @param icon {String=}  
			*/
	        confirm: function(info, ensureFun, cancelFun, type, title, icon) {
	            var mb = new MessageBox();
	            mb.promptInfo = info;
	            mb.promptType = type || this.PROMPT_STRUTS_TYPE_MIDDLE;
	            mb.promptTitle = title;
	            mb.promptIcon = icon;
	            mb.type = PromptWindow.TYPE_CONFIRM;
	            return mb.openConfirm(ensureFun, cancelFun);
	        },
	        /**  
	         * @param {String} info   
	         * @param {String} defaultVal  
	         * @param {Function} ensureFun  
	         * @param {Function} cancelFun  
	         * @param {Function=} inputControlFun 
	         * @param {String=} type  
	         * @param {String=} title  
	         * @param {String=} icon
	         */
	        prompt: function(info, defaultVal, ensureFun, cancelFun, inputControlFun, type, title, icon) {
	            var mb = new MessageBox();
	            mb.promptInfo = info;
	            mb.promptType = type;
	            mb.promptTitle = title;
	            mb.promptIcon = icon;
	            mb.type = PromptWindow.TYPE_PROMPT;
	            return mb.openPrompt(defaultVal, ensureFun, cancelFun, inputControlFun);
	        },
	        /**
	         * @param buttons {Array.<*>} format eg. [ {'text':'button1', 'receiptFun':fun1}, {'text':'button2', 'receiptFun':fun2}]
	         * @param info {String}  
	         * @param type {String}  
	         * @param title {String} 
	         * @param [icon] {String}
	         */
	        customPrompt: function(info, buttons, type, title, icon) {
	            var mb = new MessageBox();
	            mb.promptInfo = info;
	            mb.promptType = type || this.PROMPT_STRUTS_TYPE_MIDDLE;
	            mb.promptTitle = title;
	            mb.promptIcon = icon;
	            mb.type = PromptWindow.TYPE_CUSTOM_PROMPT;
	            return mb.openCustom(buttons);
	        }
	    };
	})();
})(jQuery); 