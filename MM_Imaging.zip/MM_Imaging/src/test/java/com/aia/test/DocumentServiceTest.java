package com.aia.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.aia.mm_imaging.pojo.OutputVO;
import com.aia.mm_imaging.service.DocumentService;
import com.aia.mm_imaging.util.ValidateUtil;
import com.alibaba.fastjson.JSON;


@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class DocumentServiceTest {
	@Autowired
	private DocumentService documentService;
	
	@Test
	public  void testGetDocListByPol() {
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> poList = new ArrayList<String>();
		poList.add("H123456788");
		poList.add("H123456789");
		map.put("applicationName", "iAgent");
		map.put("loginId", "iAgent");
		map.put("polList", poList);
		String json =  JSON.toJSONString(map);
		String result= documentService.getDocListByPol(json,null);
		System.out.println(result);
	}
	@Test
	public  void testGetDocById() {
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> docId = new ArrayList<String>();
		docId.add("3");
		map.put("applicationName", "iAgent");
		map.put("loginId", "iAgent");
		map.put("docId", docId);
		String json =  JSON.toJSONString(map);
		String result= documentService.getDocStrById(json,null);
		System.out.println(result);
	}
	@Test
	public  void testGetCategoryList() {
		OutputVO result= documentService.getCategoryList();
		System.out.println(JSON.toJSONString(result));
	}
	@Test
	public  void testGetCategoryByCategory() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("form_category", "Application");
		String json =  JSON.toJSONString(map);
		OutputVO result= documentService.getCategoryByCategory(json);
		System.out.println(JSON.toJSONString(result));
	}
	@Test
	public  void testDel() {
		Map<String, String> map =new HashMap<String, String>();
		map.put("fileName", "A13407_ACCOMR1_AGENT_20190906012948.pdf");
		ValidateUtil.checkExistDoc(map);
	}
	
	
}
