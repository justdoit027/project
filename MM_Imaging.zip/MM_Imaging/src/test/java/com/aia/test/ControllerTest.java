package com.aia.test;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.mm_imaging.pojo.HttpClientResult;
import com.aia.mm_imaging.util.EncryptionUtil;
import com.aia.mm_imaging.util.HttpClientUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class ControllerTest {
	/*
	 * test Data
	 */
	private final String  GETDOCLISTBYPOL ="http://127.0.0.1:8080/doc/getDocListByPol";
	private final String  doclist ="http://pnhdcdwivr010:8086/MM_Imaging/doc/getDocListByPol";
	private final String  UATdoclist ="http://pnhdcuwivr010:8086/MM_Imaging/doc/getDocListByPol";
	
    private final String  UTGETDOCLISTBYPOL ="http://10.112.101.42:8086/MM_Imaging/doc/getDocListByPol";
	private final String  GETDOCBYID ="http://127.0.0.1:8080/MM_Imaging/doc/getDocById";
	private final String  UTGETDOCBYID ="http://10.112.101.42:8086/MM_Imaging/doc/getDocById";
	private final String  docid ="http://pnhdcdwivr010:8086/MM_Imaging/doc/getDocById";
	private final String  UATdocid ="http://pnhdcuwivr010:8086/MM_Imaging/doc/getDocById";
	
	
	private final String  GETDOCLISTBYAGENTCODE ="http://127.0.0.1:8080/doc/getDocListByAgentCode";
	private final String  cd ="http://pnhdcdwivr010:8086/MM_Imaging/doc/getDocListByAgentCode";
	private final String  UATcd ="http://pnhdcuwivr010:8086/MM_Imaging/doc/getDocListByAgentCode";
	private final String  UTGETDOCLISTBYAGENTCODE ="http://10.112.101.42:8086/MM_Imaging/doc/getDocListByAgentCode";
	private final String  GETFORMINFOBYCATEGORY ="http://127.0.0.1:8080/form/getFormInfoByCategory";
	private final String  UPLOAD ="http://127.0.0.1:8080/form/upload";
	Logger logger = LoggerFactory.getLogger(ControllerTest.class);
	

	/**
	 * Description: testGetDocListByPol
	 */
	@Test
	public  void testGetDocListByPol(){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("applicationName", "iAgent");
		jsonObject.put("loginId", "A001001");
		JSONArray poList = new JSONArray();
		poList.add("E007489707");
		poList.add("C123456789");	
		jsonObject.put("polList", poList);
		HttpClientResult result = null;
		try {
			result = HttpClientUtils.doPost(UATdoclist,jsonObject);
			//result = HttpClientUtils.doPost(UTGETDOCLISTBYPOL,jsonObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(EncryptionUtil.decrypt(result.getContent(), "A001001"));
		System.out.println(result);
	}

	/**
	 * Description: testGetDocById
	 */
	@Test
	public  void testGetDocById(){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("applicationName", "iAgent");
		jsonObject.put("loginId", "A001001");
		JSONArray docId = new JSONArray();
		docId.add("30");
		docId.add("1080");
		jsonObject.put("docId", docId);
		HttpClientResult result = null;
		try {
			//result = HttpClientUtils.doPost(docid,jsonObject);
			result = HttpClientUtils.doPost(GETDOCBYID,jsonObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(result);
		System.out.println(EncryptionUtil.decrypt(result.getContent(), "A001001")+"2323");
	}
	/**
	 * Description: testGetDocById
	 */
	@Test
	public  void testGetDocListByAgentCode(){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("applicationName", "iAgent");
		JSONArray agentCodeList = new JSONArray();
		agentCodeList.add("A13327");
		agentCodeList.add("A13484");
		jsonObject.put("agentCode", agentCodeList);
		jsonObject.put("startDt", "30/07/2019");
		jsonObject.put("endDt", "20/09/2019");
		jsonObject.put("loginId", "A001001");
		HttpClientResult result = null;
		try {
			result = HttpClientUtils.doPost(cd,jsonObject);
			//result = HttpClientUtils.doPost(cd,jsonObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String string=EncryptionUtil.decrypt(result.getContent(), "A001001");
		
		System.out.println("suc");
		System.out.println(string);
		System.out.println(result);
	}


	

}
