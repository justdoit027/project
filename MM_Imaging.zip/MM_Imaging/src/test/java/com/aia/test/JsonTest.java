package com.aia.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class JsonTest {
	@Test
	public void readJsonFromUrl() {
		String url = "http://jushi-yanshi.tidemedia.com/a/a/g/list_slide_1_0.json";

		StringBuffer json = new StringBuffer();

		try {
			URL u = new URL(url);

			URLConnection yc = u.openConnection();

			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream(), "UTF-8"));

			String inputline = null;
			while ((inputline = in.readLine()) != null) {

				json.append(inputline);

			}

			in.close();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JSONObject jo = JSON.parseObject(json.toString());
		System.out.println(jo.toString());

	}

}
