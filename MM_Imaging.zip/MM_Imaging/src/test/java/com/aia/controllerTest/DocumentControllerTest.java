package com.aia.controllerTest;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.aia.mm_imaging.pojo.HttpClientResult;
import com.aia.mm_imaging.util.Base64Util;
import com.aia.mm_imaging.util.EncryptionUtil;
import com.aia.mm_imaging.util.HttpClientUtils;
import com.alibaba.fastjson.JSON;

public class DocumentControllerTest {
	/*
	 * 测试数据
	 */
	//private static String url = "http://127.0.0.1:8080";
	private  String url1 = "http://10.112.101.42:8086";
	
	

//	/**
//	 * Description: 测试Post有参请求
//	 */
//	@Test
//	public  void testGetDocListByPolPostHasParam() throws Exception {
//		Map<String, Object> listParam = new HashMap<String, Object>();
//		Map<String, String> listJson = new HashMap<String, String>();
//		/**
//		 * getDocListByPol 数据
//		 */
//		String url2 = "/MM_Imaging/doc/getDocListByPol";
//		String url =url1 + url2;
//	
//		listParam.put("applicationName", "iAgent");
//		listParam.put("loginId", "A001001");
//		List<String> poList = new ArrayList<String>();
//		poList.add("H123456789");
//		poList.add("H123456788");	
//
//		listParam.put("polList", poList);
//		String json=JSON.toJSONString(listParam);
//		listJson.put("json", json);
//		
//		System.out.println(url);
//		System.out.println(listJson);
//		HttpClientResult result = null;
//		try {
//			//result = HttpClientUtils.doPost(url,listJson);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(result);
//		System.out.println(EncryptionUtil.decrypt(result.getContent(), "A001001"));
//		System.out.println(result);
//	}
//
//	@Test
//	public  void testGetDocByIdPostHasParam() throws Exception {
//		Map<String, Object> idsParam = new HashMap<String, Object>();
//		Map<String, String> idsJson = new HashMap<String, String>();
//	 
//		String url2 = "/MM_Imaging/doc/getDocById";
//		String url =url1 + url2;
//		idsParam.put("applicationName", "iAgent");
//		idsParam.put("loginId", "A001001");
//		List<String> docId = new ArrayList<String>();
//		docId.add("1");
//		//docId.add("3");	
//		idsParam.put("docId", docId);
//		String idsjson=JSON.toJSONString(idsParam);
//		idsJson.put("json", idsjson);
//		
//		System.out.println(url);
//		System.out.println(idsJson);
//		HttpClientResult result = null;
//		try {
//			//result = HttpClientUtils.doPost(url,idsJson);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(result);
//		System.out.println(result);
//	}
//	@Test
//	public  void testUpload() throws Exception {
//		File file = new File("//10.112.101.42/MM_Imaging_Staging/aaa123.pdf");
//		String pdfToBase64 = Base64Util.PDFToBase64(file);
//		
//		Map<String, String> uploadMap = new HashMap<String, String>();
//		String url2 = "/MM_Imaging/form/upload";
//		
//		uploadMap.put("file", pdfToBase64);
//		uploadMap.put("formCategory", "formCategory");
//		uploadMap.put("formId", "A001001");
//		uploadMap.put("polNum", "P123456789");
//		
//		HttpClientResult result = null;
//		try {
//			//result = HttpClientUtils.doPost(url1+url2,new HashMap<String, String>(),uploadMap);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println(result);
//	} 

}
