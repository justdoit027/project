package com.aia.sqs.test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;


public class TestForUtil {
	private static List<File> splitTiff;

	public static void main(String[] args) {
		
		getAbsFilePathTest();
		//getAbsFilePathTest();
		//String md5Pass = DigestUtils.md5Hex("password");
		//System.out.println(md5Pass);
		//System.out.println("jiemi");
		//System.out.println(DigestUtils.shaHex(md5Pass));
	}
	
	 
	private static void getAbsFilePathTest() {
		 //String sfileName = "C123456789_TEST111_IL_201908202092234.pdf";
		// String sfileName = "C123456789_TEST111_AGENT_201908202092234.pdf";
		//String formCategory = "TestCategory";
		//String absFilePath = FileUtil.getAbsFilePath(sfileName, formCategory);
		//System.out.println(1);
		Map<String, String> map =new HashMap<String, String>();
		map.put("fileName", "A13407_ACCOMR1_AGENT_20190906012948.pdf");
	}

}
