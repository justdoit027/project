package com.aia.sqs.service.impl;

import com.aia.sqs.service.SequenceService;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Service
public class SequenceServiceImpl implements SequenceService {

    private final Map<String, SequenceInfo> map = new HashMap<>();
    private static final long TWELVE_HOURS = 12 * 60 * 60 * 1000L;

    @Override
    public synchronized boolean isDuplicated(String token, long sequence) {
        if (! map.containsKey(token)) {
            map.put(token, new SequenceInfo(sequence));
            return false;
        }
        SequenceInfo info = map.get(token);
        if (sequence > info.getSequence()) {
            info.setSequence(sequence);
            return false;
        }
        cleanMap();
        return true;
    }

    private void cleanMap(){
        Iterator<String> iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            SequenceInfo value = map.get(key);
            if (isTimeout(value.getUpdatedAt())) {
                map.remove(key);
            }
        }
    }

    private boolean isTimeout(long updatedAt) {
        return System.currentTimeMillis() - updatedAt > TWELVE_HOURS;
    }

    private static class SequenceInfo {
        private long sequence;
        private long updatedAt;

        public SequenceInfo(long sequence) {
            this.sequence = sequence;
            this.updatedAt = System.currentTimeMillis();
        }

        public long getSequence() {
            return sequence;
        }

        public void setSequence(long sequence) {
            updatedAt = System.currentTimeMillis();
            this.sequence = sequence;
        }

        public long getUpdatedAt() {
            return updatedAt;
        }
    }
}
