package com.aia.sqs.common.constant;

public interface DataSourceConstant {

    String DATASOURCE_DEFAULT = "default";

    String DATASOURCE_COMMON = "common";

}
