package com.aia.sqs.service;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.Parameter;

public interface ParameterService {
	OutputVO delete(String parameterId);
	OutputVO getOne(String parameterId);
	OutputVO update(Parameter parameter);
	OutputVO add(Parameter parameter);
	OutputVO findAll(String planId);
	
}
