package com.aia.sqs.dao.listener;

public interface EntityMonitor {

    void prePersisted(Object after);

    void preUpdated(Object entity);

    void preRemoved(Object entity);
}
