package com.aia.sqs.service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.FormularTemplate;

public interface FormularTemplateService {
OutputVO delete(String formularTemplateId);
OutputVO update(FormularTemplate formular);
OutputVO add(FormularTemplate formular);
OutputVO findAll(String planTemplateId);
OutputVO queryById(String formularTemplateId);
}
