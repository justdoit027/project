package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.ParameterTemplate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface ParameterTemplateRepository extends JpaRepository<ParameterTemplate, String>, CrudRepository<ParameterTemplate, String>, JpaSpecificationExecutor {
	List<ParameterTemplate> findAllByPlanTemplateId(String planTemplateId);
	
}
