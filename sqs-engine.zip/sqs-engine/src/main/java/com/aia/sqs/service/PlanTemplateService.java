package com.aia.sqs.service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.alibaba.fastjson.JSONObject;

public interface PlanTemplateService {
OutputVO delete(String planTemplateId);
OutputVO update(PlanTemplate plan);
OutputVO add(PlanTemplate plan);
OutputVO clone(String planTemplateId);
OutputVO findAll(JSONObject json);
OutputVO getOne(String planTemplateId);
}
