package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.Agent;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AgentRepository extends SqsRepository<Agent, String>, JpaSpecificationExecutor {

    Agent getByAgentCode(String agentCode);

}
