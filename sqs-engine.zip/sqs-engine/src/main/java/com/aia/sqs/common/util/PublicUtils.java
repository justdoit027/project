package com.aia.sqs.common.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class PublicUtils {

    public String dobuleToString2(double d){
        DecimalFormat    df   = new DecimalFormat("###########0.00");

        BigDecimal b = new BigDecimal(d);
        double f1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        /*System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>");

        System.out.println(df.format(f1));
        System.out.println(f1);*/

        return df.format(f1);
    }

}
