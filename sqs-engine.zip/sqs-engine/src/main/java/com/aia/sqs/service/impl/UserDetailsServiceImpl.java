package com.aia.sqs.service.impl;


import com.aia.sqs.dao.entity.Agent;
import com.aia.sqs.dao.repository.AgentRepository;
import com.aia.sqs.service.model.Account;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service("userDetailsService")
@Slf4j
public class UserDetailsServiceImpl implements UserDetailsService {

    public enum Authority {
        ROLE_AGENT
    }

    @Autowired
    private AgentRepository agentRepository;

    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.info("userDetailsService.loadUserByUsername()..");
        Account account = Account.fromString(username);
        String agentCode = account.getAgentCode();
        Agent agent = agentRepository.getByAgentCode(agentCode);
        if (agent == null) {
            log.info("agent not found, return empty User..");
            return new User(account.getUsername(), "", Collections.emptyList());
        }

        log.info("return an agent user..");
        String authorityName = Authority.ROLE_AGENT.name();
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority(authorityName);
        List<SimpleGrantedAuthority> authorities = Arrays.asList(authority);
        return new User(account.getUsername(), "", authorities);
    }
}