package com.aia.sqs.dao.entity;

import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;

@Entity
@Table(name = "T_AgentPlatform")
public class AgentPlatform extends AbstractEntity<String> {

    public enum Platform {
        MOBILE_IPOS("1"),
        WEB_IPOS_ICARE("2"),
        WEB_IPOS("3"),
        WEB_ICARE("4");

        private final String code;

        Platform(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }

        public static Platform valueOfCode(String code) {
            if (StringUtils.isEmpty(code)) {
                return null;
            }
            for (Platform value : values()) {
                if (value.code.equals(code)) {
                    return value;
                }
            }
            return null;
        }
    }

    @Id
    @Column(length = 64)
    private String agentCode;
    @Column(length = 2)
    private String platformCode;

    @Override
    public String getId() {
        return agentCode;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getPlatformCode() {
        return platformCode;
    }

    public void setPlatformCode(String platformCode) {
        this.platformCode = platformCode;
    }

    @Transient
    public Platform getPlatform() {
        return Platform.valueOfCode(platformCode);
    }

    @Transient
    public void setPlatform(Platform platform) {
        if (platform == null) {
            this.platformCode = null;
        } else {
            this.platformCode = platform.code;
        }
    }
}
