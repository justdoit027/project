package com.aia.sqs.aop.support;

import java.lang.annotation.*;

/**
 * Support the execution time of the acquisition method
 * We can add to the method that needs to be monitor.
 * @StopWatch
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface StopWatch {
}
