package com.aia.sqs.dao.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name="T_Agent")
public class Agent extends AbstractEntity<String> {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(length = 60)
    private String agentId;
    @Column(length = 32)
    private String idNo;
    @Column(length = 64)
    private String portraitUrl;
    @Column(length = 32)
    private String channelCode;
    @Column(length = 16)
    private String agentStatus;
    @Column(length = 64)
    private String agentCode;
    @Column(length = 64)
    private String agentName;
    @Column(length = 32)
    private String agentType;
    @Column(length = 64)
    private String reportTom;
    @Column(length = 64)
    private String agencyCode;
    @Column(length = 64)
    private String agencyName;
    @Column(length = 64)
    private String staffRank;
    @Column(length = 32)
    private String contactNo;
    @Column(length = 64)
    private String email;
    @Column(length = 128)
    private String address1;
    @Column(length = 128)
    private String address2;
    @Column(length = 128)
    private String address3;
    @Column(length = 128)
    private String address4;
    @Column(length = 128)
    private String address5;
    @Column(length = 50)
    private String country;
    @Column(length = 10)
    private String licenseType;
    @Column(length = 20)
    private String licenseExpDate;
    @Column(length = 50)
    private String partnerBank;
    @Column(length = 50)
    private String bankBranchCode;
    @Column(length = 50)
    private String bankBranchName;
    @Column(length = 1)
    private String agreeLicense;

    @Override
    @Transient
    public String getId() {
        return agentId;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getPortraitUrl() {
        return portraitUrl;
    }

    public void setPortraitUrl(String portraitUrl) {
        this.portraitUrl = portraitUrl;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getAgentStatus() {
        return agentStatus;
    }

    public void setAgentStatus(String agentStatus) {
        this.agentStatus = agentStatus;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getAgentType() {
        return agentType;
    }

    public void setAgentType(String agentType) {
        this.agentType = agentType;
    }

    public String getReportTom() {
        return reportTom;
    }

    public void setReportTom(String reportTom) {
        this.reportTom = reportTom;
    }

    public String getAgencyCode() {
        return agencyCode;
    }

    public void setAgencyCode(String agencyCode) {
        this.agencyCode = agencyCode;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getStaffRank() {
        return staffRank;
    }

    public void setStaffRank(String staffRank) {
        this.staffRank = staffRank;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getAddress3() {
        return address3;
    }

    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    public String getAddress4() {
        return address4;
    }

    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    public String getAddress5() {
        return address5;
    }

    public void setAddress5(String address5) {
        this.address5 = address5;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    public String getLicenseExpDate() {
        return licenseExpDate;
    }

    public void setLicenseExpDate(String licenseExpDate) {
        this.licenseExpDate = licenseExpDate;
    }

    public String getPartnerBank() {
        return partnerBank;
    }

    public void setPartnerBank(String partnerBank) {
        this.partnerBank = partnerBank;
    }

    public String getBankBranchCode() {
        return bankBranchCode;
    }

    public void setBankBranchCode(String bankBranchCode) {
        this.bankBranchCode = bankBranchCode;
    }

    public String getBankBranchName() {
        return bankBranchName;
    }

    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName;
    }

    public String getAgreeLicense() {
        return agreeLicense;
    }

    public void setAgreeLicense(String agreeLicense) {
        this.agreeLicense = agreeLicense;
    }
}
