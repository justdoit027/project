package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.Plan;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface PlanRepository extends JpaRepository<Plan, String>, CrudRepository<Plan, String>, JpaSpecificationExecutor {
	List<Plan> findAllByProductId(String productId);
}
