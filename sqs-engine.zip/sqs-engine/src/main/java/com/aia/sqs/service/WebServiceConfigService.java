package com.aia.sqs.service;

import com.aia.sqs.dao.entity.TWebserviceConfig;

import javax.transaction.Transactional;
import java.util.List;

public interface WebServiceConfigService {

    //@DataSource(DataSourceConstant.DATASOURCE_COMMON)
    List<TWebserviceConfig> finaAll();

    //@DataSource(DataSourceConstant.DATASOURCE_COMMON)
    TWebserviceConfig findById(String id);

    //@DataSource(DataSourceConstant.DATASOURCE_COMMON)
    @Transactional
    void delete(String id);

    //@DataSource(DataSourceConstant.DATASOURCE_COMMON)
    @Transactional
    void save(TWebserviceConfig webserviceConfig);

}
