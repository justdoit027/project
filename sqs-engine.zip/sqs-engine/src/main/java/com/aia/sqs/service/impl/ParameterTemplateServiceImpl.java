package com.aia.sqs.service.impl;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.HandleFile;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.FormularTemplate;
import com.aia.sqs.dao.entity.ParameterTemplate;
import com.aia.sqs.dao.repository.ParameterTemplateRepository;
import com.aia.sqs.service.ParameterTemplateService;
@Service
public class ParameterTemplateServiceImpl implements ParameterTemplateService{
	@Autowired 
	private ParameterTemplateRepository parameterTemplateRepository;
	@Override
	public OutputVO delete(String parameterTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			parameterTemplateRepository.deleteById(parameterTemplateId);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(ParameterTemplate parameterTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (parameterTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			ParameterTemplate sourceTemplate = parameterTemplateRepository.findById(parameterTemplate.getId()).get();
			UpdateTool.copyNullProperties(sourceTemplate, parameterTemplate);
			parameterTemplateRepository.saveAndFlush(parameterTemplate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO add(ParameterTemplate parameterTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (parameterTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			parameterTemplateRepository.saveAndFlush(parameterTemplate);
		
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	

	@Override
	public OutputVO findAll(String planTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			 List<ParameterTemplate> planList = parameterTemplateRepository.findAllByPlanTemplateId(planTemplateId);
			
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}

	@Override
	public OutputVO queryById(String parameterTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			
			ParameterTemplate parameterTemplate=parameterTemplateRepository.findById(parameterTemplateId).get();
		
				outputVO.setData(parameterTemplate);
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	
	

}
