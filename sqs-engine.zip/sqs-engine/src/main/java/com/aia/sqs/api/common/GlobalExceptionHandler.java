package com.aia.sqs.api.common;

import com.aia.sqs.api.model.FailedResponse;
import com.aia.sqs.api.model.OutputVO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;


/**
 * Global exception handler
 * We can handle all exceptions uniformly here
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<FailedResponse> handleConstraintViolationException(
            HttpServletRequest request, ConstraintViolationException exception) {
        log.error("Parameters validation failed:{}", request.getRequestURI());
        FailedResponse response;
        try {
            Set<ConstraintViolation<?>> constraintViolations = exception.getConstraintViolations();

            StringBuilder builder = new StringBuilder();
            for (ConstraintViolation constraintViolation : constraintViolations) {
                builder.append(constraintViolation.getMessage());
                builder.append(";");
            }
            builder.substring(0, builder.length() - 1);
            response = createFailedResponse(builder.toString());
        } catch (Exception e) {
            log.error("Exception when handle ConstraintViolationException", e);
            response = createFailedResponse(e.getMessage());

        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler({Exception.class})
    public ResponseEntity<OutputVO> handleException(
            HttpServletRequest request, RuntimeException exception) {
        String requestURI = request.getRequestURI();
        log.error(String.format("Exception on [%s]", requestURI), exception);
        OutputVO outputVO = new OutputVO();
        outputVO.setCode("-1");
        outputVO.setMessage(exception.getMessage());
        return new ResponseEntity<>(outputVO, HttpStatus.OK);
    }

    private FailedResponse createFailedResponse(String message) {
        return new FailedResponse(appendTimeInfo(message));
    }

    private String appendTimeInfo(String message) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String timeInfo = format.format(new Date());
        return String.format("%s at:%s", message, timeInfo);
    }

}
