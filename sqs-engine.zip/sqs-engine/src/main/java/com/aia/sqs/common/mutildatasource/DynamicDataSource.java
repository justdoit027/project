package com.aia.sqs.common.mutildatasource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import javax.sql.DataSource;
import java.lang.reflect.Field;
import java.util.Map;

/**
 * DynamicDataSource
 */
@Slf4j
public class DynamicDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {

        String key = DataSourceContextHolder.getDataSourceType();

        if (!DataSourceContextHolder.containsDataSource(key)){
            log.debug("can not found DataSource by key: '{}', use default DataSource",key);
        }

        return key;
    }

    @Override
    public void afterPropertiesSet() {
        super.afterPropertiesSet();
        try {
            Field sourceMapField = AbstractRoutingDataSource.class.getDeclaredField("resolvedDataSources");
            sourceMapField.setAccessible(true);
            Map<Object, DataSource> sourceMap = (Map<Object, javax.sql.DataSource>) sourceMapField.get(this);
            DataSourceContextHolder.setDatasourceSet(sourceMap.keySet());
            sourceMapField.setAccessible(false);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            log.error("DynamicDataSource set error",e);
        }
    }
}
