package com.aia.sqs.service;

import org.springframework.web.multipart.MultipartFile;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.RateTemplate;

public interface RateTemplateService {
	OutputVO delete(String RateTemplateId);
	OutputVO queryById(String RateTemplateId);
	OutputVO update(RateTemplate rateTemplate);
	OutputVO add(RateTemplate rateTemplate);
	OutputVO findAll(String planTemplateId);
	OutputVO excelToDb(MultipartFile file,String tableName);
}
