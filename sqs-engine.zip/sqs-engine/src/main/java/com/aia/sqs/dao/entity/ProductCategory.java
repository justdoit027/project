package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="t_product_category")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductCategory extends BaseEntity{

    @Column(name="name")
    private String name;

    @Column(name="category_rule")
    private String categoryRule;


    @Column(name="status")
    private String status;
    
   
    
  
   

}
