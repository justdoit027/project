package com.aia.sqs.conf;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

@Configuration
@Slf4j
public class CurrentUserAwareConfiguration implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        SecurityContext ctx = SecurityContextHolder.getContext();
        if (ctx == null) {
            log.info("ctx is null");
            return Optional.empty();
        }
        if (ctx.getAuthentication() == null) {
            log.info("Authentication is null");
            return Optional.empty();
        }
        if (ctx.getAuthentication().getPrincipal() == null) {
            log.info("Principal is null");
            return Optional.empty();
        }
        String principal = (String)ctx.getAuthentication().getPrincipal();
        log.info("Current Principal is {}",principal);
        return Optional.of(principal);
    }

}
