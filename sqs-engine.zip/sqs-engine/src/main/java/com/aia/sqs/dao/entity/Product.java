package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_product")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product extends BaseEntity{

    @Column(name="product_code")
    private String productCode;
    
    @Column(name="product_name")
    private String productName;
    
    @Column(name="product_type")
    private String productTpye;

    @Column(name="publish_date")
    private Date publishDate;

    @Column(name="expired_date")
    private Date expriredDate;

    @Column(name="status")
    private String status;
    
    @Column(name="tolerance_period")
    private int tolerancePeriod;
    
    @Column(name="product_category_id")
    private String productCategoryId;
    
  
   

}
