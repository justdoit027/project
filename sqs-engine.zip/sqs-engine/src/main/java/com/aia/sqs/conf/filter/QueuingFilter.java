package com.aia.sqs.conf.filter;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import cn.hutool.http.HttpStatus;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

//@Component
//@Order(0)
@Slf4j
public class QueuingFilter implements Filter {

    private static final String DEFAULT_LOCK = QueuingFilter.class.getName();

    @Override
    public void init(FilterConfig filterConfig) {
        log.info("QueuingFilter init");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse hresponse = (HttpServletResponse) response;
		/*
		 * hresponse.setHeader("Access-Control-Allow-Origin", "*");
		 * hresponse.setHeader("Access-Control-Allow-Methods",
		 * "POST, GET, OPTIONS, DELETE"); hresponse.setHeader("Access-Control-Max-Age",
		 * "3600"); hresponse.setHeader("Access-Control-Allow-Headers",
		 * "content-type,x-requested-with,Authorization, x-ui-request,lang");
		 * hresponse.setHeader("Access-Control-Allow-Credentials", "true"); if
		 * (req.getMethod().equals("OPTIONS")) {
		 * hresponse.setStatus(HttpStatus.HTTP_OK);
		 * hresponse.getWriter().write("OPTIONS returns OK"); return; }
		 */

        String lock;
        String token = req.getHeader("token");
        String requestURI = ((HttpServletRequest) request).getRequestURI();
        if (StringUtils.isNotEmpty(token)) {
            lock = token;
        } else {
            lock = requestURI;
        }
        log.info("[{}] will be locked by [{}]", requestURI, lock);
        synchronized (lock.intern()) {
            log.info("[{}] is locked by [{}]", requestURI, lock);
            chain.doFilter(request, response);
        }
        log.info("[{}] is un-locked from [{}]", requestURI, lock);
    }

    @Override
    public void destroy() {
        log.info("QueuingFilter destroy");
    }
}
