package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_plan")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Plan extends BaseEntity{

    @Column(name="plan_code")
    private String planCode;

    @Column(name="plan_name")
    private String planName;

    @Column(name="is_rider")
    private int isRider;

    @Column(name="description")
    private String description;
    
    @Column(name="plan_template_id")
    private String planTemplateId;
    
    @Column(name="product_id")
    private String productId;
    
  
   

}
