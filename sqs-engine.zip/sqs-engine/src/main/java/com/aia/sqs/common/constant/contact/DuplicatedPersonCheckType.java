package com.aia.sqs.common.constant.contact;

public enum  DuplicatedPersonCheckType {

    idNo,
    passportNo,
    birthCertificateNo
}
