package com.aia.sqs.api.model;

import com.aia.sqs.common.constant.ErrorCode;

public class FailedResponse extends AbstractResponse {
    public FailedResponse(String errorMessage) {
        super(ErrorCode.FAILED);
        this.errorMessage = errorMessage;
    }

    public static FailedResponse withErrorMessage(String errorMessage) {
        return new FailedResponse(errorMessage);
    }
}
