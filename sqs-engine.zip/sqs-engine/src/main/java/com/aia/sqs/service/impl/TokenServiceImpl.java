package com.aia.sqs.service.impl;


import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.api.model.TokenGet;
import com.aia.sqs.api.model.TokenGetOutput;
import com.aia.sqs.common.exception.BusinessException;
import com.aia.sqs.service.TokenService;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import java.net.URI;
import java.net.URISyntaxException;

@Slf4j
@Service
public class TokenServiceImpl implements TokenService {

    @Autowired
    private RestTemplateBuilder restTemplateBuilder;
    @Autowired
    private TokenStoreImpl tokenStoreImpl;
    @Value("${sqs.token.validity_seconds}")
    private int validity_seconds;

    @Override
    @Transactional
    public OutputVO getToken(TokenGet request, int localPort, String contextPath) {
    	OutputVO outputVO =new OutputVO();
    	TokenGetOutput tokenGetOutput = new TokenGetOutput();
        log.info("getToken() start");
        log.info("request oauth token..");
        JSONObject oauthResult = requestOAuthToken(
        		request.getUsername(), request.getPassword(), localPort, contextPath);
        log.info("request oauth token done.");
        String msg = oauthResult.getString("message");
        String tokenValue = oauthResult.getString("value");
        if (StringUtils.isEmpty(tokenValue)||!StringUtils.isEmpty(msg)) {
            log.info("unauthorized, error={}", msg);
            outputVO.setMessage(msg);
            outputVO.setCode("-1");
            return outputVO;
        }else {
        	tokenGetOutput.setAccess_token(tokenValue);
        	tokenGetOutput.setValidity_seconds(this.validity_seconds);
        	outputVO.setData(tokenGetOutput);
		}
        return outputVO;
    }

    private JSONObject requestOAuthToken(String username, String password, int localPort, String contextPath) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("grant_type", "password");
        params.add("username", username);
        params.add("password", password);
        final String baseUrl = "http://localhost:" + localPort + contextPath + "/oauth/token";
        URI uri;
        try {
            uri = new URI(baseUrl);
        } catch (URISyntaxException e) {
            log.error("ERROR oAuth URL: ", e);
            return JSONObject.parseObject("{\"error\":\"error_oauth_url\"}");
        }
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/x-www-form-urlencoded");
        String plainCertificate = "ipos-web-client:ipos-web-secret";
        byte[] base64CertificateBytes = Base64.encodeBase64(plainCertificate.getBytes());
        String base64Certificate = new String(base64CertificateBytes);
        headers.add("Authorization", "Basic " + base64Certificate);
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<MultiValueMap<String, String>>(params, headers);
        String response;
        try {
            response = getRestTemplate().postForEntity(uri, httpEntity, String.class).getBody();
            return JSONObject.parseObject(response);
        }catch (HttpClientErrorException e) {
            response = e.getResponseBodyAsString();
            return JSONObject.parseObject(response, Feature.IgnoreAutoType);
        } catch (Exception e) {
            return JSONObject.parseObject("{\"message\":\"unauthorized\"}");
        }
    }


    @Override
    @Transactional
    public OutputVO destoryToken(String accessToken) {
    	OutputVO outputVO =new OutputVO();
    	 log.info("doDisableToken({})..", accessToken);
         OAuth2AccessToken oAuth2AccessToken = tokenStoreImpl.readOriginalAccessToken(accessToken);
         if (oAuth2AccessToken != null) {
             log.info("removeAccessToken from tokenStore");
             tokenStoreImpl.removeAccessToken(oAuth2AccessToken);
         }else {
        	 outputVO.setMessage("accessToken is not exist");
             outputVO.setCode("-1");
		}
		return outputVO;
    }


    protected RestTemplate getRestTemplate() {
        return restTemplateBuilder.build();
    }
}
