package com.aia.sqs.service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.Formular;

public interface FormularService {
OutputVO delete(String formularId);
OutputVO getOne(String formularId);
OutputVO update(Formular formular);
OutputVO add(Formular formular);
OutputVO findAll(String planId);
}
