package com.aia.sqs.service.impl;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.AuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.DefaultAuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.store.InMemoryTokenStore;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Slf4j
public class TokenStoreImpl extends InMemoryTokenStore {

    public static final int DEFAULT_FLUSH_INTERVAL = 100000;

    @Value("${sqs.token.validity_seconds}")
    private int tokenValiditySeconds;

    private AuthenticationKeyGenerator authenticationKeyGenerator = new DefaultAuthenticationKeyGenerator();


    public TokenStoreImpl() {
        setFlushInterval(DEFAULT_FLUSH_INTERVAL);
    }

    @Override
    public OAuth2AccessToken readAccessToken(String tokenValue) {
        OAuth2AccessToken token = super.readAccessToken(tokenValue);
        if (token != null
                && token.getExpiration() != null
                && token instanceof DefaultOAuth2AccessToken) {
            if (new Date().before(token.getExpiration())) {
                DefaultOAuth2AccessToken tokenImpl = (DefaultOAuth2AccessToken)token;
                tokenImpl.setExpiration(new Date(System.currentTimeMillis() + (tokenValiditySeconds * 1000L)));
            }
        }
        return token;
    }

    public OAuth2AccessToken readOriginalAccessToken(String tokenValue) {
        return super.readAccessToken(tokenValue);
    }

    @Override
    public OAuth2AccessToken getAccessToken(OAuth2Authentication authentication) {
        return super.getAccessToken(authentication);
    }
}
