package com.aia.sqs.common.constant;

public enum YesOrNo {
    Y("1"),
    N("0");

    private String code;

    YesOrNo(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

}
