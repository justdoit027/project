package com.aia.sqs.common.constant.contact;

public enum MaritalStatus {
    S("Single"), M("Married"), W("Widowed"), D("Divorced");
    private final String displayName;

    MaritalStatus(String displayName) {
        this.displayName = displayName;
    }

    public static MaritalStatus valueOfDisplayName(String displayName) {
        for (MaritalStatus value : values()) {
            if (value.displayName.equals(displayName)) {
                return value;
            }
        }
        return null;
    }

    public String getDisplayName() {
        return displayName;
    }
}
