package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.FormularTemplate;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface FormularTemplateRepository extends JpaRepository<FormularTemplate, String>, CrudRepository<FormularTemplate, String>, JpaSpecificationExecutor {
	List<FormularTemplate> findAllByPlanTemplateId(String planTemplateId);
	
}
