package com.aia.sqs.common.constant.contact;

public enum  ContactGender {

    M("MALE"),F("FEMALE");

    private final String displayName;

    ContactGender(String displayName) {
        this.displayName = displayName;
    }

    public static ContactGender valueOfDisplayName(String displayName) {
        for (ContactGender value : values()) {
            if (value.displayName.equals(displayName)) {
                return value;
            }
        }
        return null;
    }

    public String getDisplayName() {
        return displayName;
    }
}
