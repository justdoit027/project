package com.aia.sqs.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.Rate;
import com.aia.sqs.dao.repository.RateRepository;
import com.aia.sqs.service.RateService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class RateServiceImpl implements RateService {
	@Autowired
	private RateRepository rateRepository;
	@Autowired
	private JdbcTemplate jdbc;

	@Override
	public OutputVO delete(String rateId) {
		OutputVO outputVO = new OutputVO();
		try {
			rateRepository.deleteById(rateId);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
	@Override
	public OutputVO getOne(String rateId) {
		OutputVO outputVO = new OutputVO();
		try {
			Rate rate = rateRepository.findById(rateId).get();
			outputVO.setData(rate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(Rate rate) {
		OutputVO outputVO = new OutputVO();
		try {
			Rate source = rateRepository.findById(rate.getId()).get();
			UpdateTool.copyNullProperties(source, rate);
			rateRepository.saveAndFlush(rate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;

	}

	@Override
	public OutputVO add(Rate rate) {
		OutputVO outputVO = new OutputVO();
		try {
			rateRepository.saveAndFlush(rate);

		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;

	}

	@Override
	public OutputVO findAll(String productId) {
		OutputVO outputVO = new OutputVO();
		try {
			List<Rate> planList = rateRepository.findAllByProductId(productId);
			
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}


}
