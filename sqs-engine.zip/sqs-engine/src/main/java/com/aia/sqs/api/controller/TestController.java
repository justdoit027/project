package com.aia.sqs.api.controller;


import com.aia.sqs.dao.entity.Contact;
import com.aia.sqs.dao.entity.TWebserviceConfig;
import com.aia.sqs.service.ContactService;
import com.aia.sqs.service.PortalLoginService;
import com.aia.sqs.service.WebServiceConfigService;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.UUID;

@RestController
@CrossOrigin(allowCredentials = "true")
@Slf4j
public class TestController {

    @Autowired
    private ContactService contactService;

    @Autowired
    private WebServiceConfigService webServiceConfigService;

    @Autowired
    private PortalLoginService portalLoginService;

    @RequestMapping(value = "/hello",method = {RequestMethod.GET})
    public String hello(@RequestParam(value = "name") String name)
    {
        System.out.println("hello");
        return "Hello " + name;
    }

    @RequestMapping(value = "/contact/{id}",method = {RequestMethod.GET})
    public ResponseEntity<Contact> findContactById(@PathVariable(name="id") String contactId)
    {
        Contact contact = contactService.findById(contactId);
        return ResponseEntity.ok(contact);
    }

    @RequestMapping(value = "/contact/save",method = {RequestMethod.POST})
    public ResponseEntity save(@RequestBody Contact contact)
    {
        contactService.save(contact);
        return ResponseEntity.ok().build();
    }

    @RequestMapping(value = "/deletecontact/{id}",method = {RequestMethod.GET})
    public String deleteContactById(@PathVariable(name="id") String contactId) throws InterruptedException {
        contactService.delete(contactId);
        Thread.sleep(10000);
        return "delete " + contactId + "successfully";
    }


    @RequestMapping(value = "/config-list",method = {RequestMethod.GET})
    public ResponseEntity<List<TWebserviceConfig>> findConfigs()
    {
        val configList = webServiceConfigService.finaAll();
        return ResponseEntity.ok(configList);
    }

    @RequestMapping(value = "/config/{id}",method = {RequestMethod.GET})
    public ResponseEntity<TWebserviceConfig> findConfigById(@PathVariable(name="id") String id)
    {
        TWebserviceConfig config = webServiceConfigService.findById(id);
        return ResponseEntity.ok(config);
    }

    @RequestMapping(value = "/account/save/{id}",method = {RequestMethod.GET})
    public ResponseEntity<TWebserviceConfig> saveAccount(@PathVariable(name="id") String id)
    {
        portalLoginService.saveAccount(id);
        return ResponseEntity.ok().build();
    }


    @RequestMapping(method = RequestMethod.POST, path = "/upload")
    @ResponseBody
    public String upload(@RequestPart("file") MultipartFile picture) {
        System.out.println(picture.getName());
        System.out.println(picture.getOriginalFilename());
        String extension = FilenameUtils.getExtension(picture.getOriginalFilename());
        String pictureName = UUID.randomUUID().toString() + "." + extension;
        try {
            String fileSavePath = "";
            //picture.transferTo(new File(fileSavePath + pictureName));
            picture.transferTo(new File(fileSavePath + picture.getOriginalFilename()));
        } catch (Exception e) {
            throw new RuntimeException("upload error.");
        }
        return picture.getOriginalFilename();
    }


}
