package com.aia.sqs.api.model;

import com.aia.sqs.common.constant.ErrorCode;

import java.util.Objects;

public class GeneralResponse<R> extends AbstractResponse {

    protected R result;

    public GeneralResponse(R result) {
        super(ErrorCode.SUCCESSFUL);
        this.result = result;
    }

    public GeneralResponse(ErrorCode errorCode) {
        super(errorCode);
    }

    public GeneralResponse(ErrorCode errorCode, String errorMessage) {
        super(errorCode, errorMessage);
    }

    public R getResult() {
        return result;
    }

    public void setResult(R result) {
        this.result = result;
    }


    @Override
    public int hashCode() {
        return Objects.hash(errorMessage, result);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class ContactBasicResponse {\n");

        sb.append("    errorMessage: ").append(toIndentedString(errorMessage)).append("\n");
        sb.append("    result: ").append(toIndentedString(result)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
