package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_rates")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Rate extends BaseEntity{

    @Column(name="name")
    private String name;

    @Column(name="table_name")
    private String tableName;

    @Column(name="r_condition")
    private String condition;

    @Column(name="description")
    private String description;
    
    @Column(name="plan_id")
    private String planId;
    
    @Column(name="product_id")
    private String productId;
    
  
   

}
