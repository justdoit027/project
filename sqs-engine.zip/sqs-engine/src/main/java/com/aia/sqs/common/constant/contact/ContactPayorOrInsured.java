package com.aia.sqs.common.constant.contact;

public enum  ContactPayorOrInsured {

    Payor,
    Insured
}
