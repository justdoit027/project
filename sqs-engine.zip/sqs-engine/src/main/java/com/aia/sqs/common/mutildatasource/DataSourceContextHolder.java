package com.aia.sqs.common.mutildatasource;

import lombok.extern.slf4j.Slf4j;

import java.util.HashSet;
import java.util.Set;

@Slf4j
public class DataSourceContextHolder {

    private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

    private static Set<Object> dataSourceSet = new HashSet<>();  //所有数据源的key集合

    public static void setDataSourceType(String dataSourceType) {
        contextHolder.set(dataSourceType);
    }

    public static String getDataSourceType() {
        return contextHolder.get();
    }

    public static void clearDataSourceType() {
        contextHolder.remove();
    }

    public static void setDatasourceSet(Set<Object> dsSet)
    {
        log.info("set the mutil datasource = {}",dsSet);
        dataSourceSet = dsSet;
    }

    /**
     * 判断指定DataSource当前是否存在
     *
     * @param dataSourceId
     * @return
     */
    public static boolean containsDataSource(String dataSourceId){
        return dataSourceSet.contains(dataSourceId);
    }
}
