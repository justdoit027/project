package com.aia.sqs.conf;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.ClassUtil;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.ValueFilter;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@EnableSwagger2
@Slf4j
public class WebMvcConfiguration extends WebMvcConfigurationSupport {

	@Value("${sqs.api.version}")
	private String version;

	private static final Set<Class> emptyObjectSet = new HashSet<>();

	static {
//		emptyObjectSet.add(SpousePrepareResult.class);
//		emptyObjectSet.add(ContactIdName.class);
//		emptyObjectSet.add(CodeNameValue.class);
//		emptyObjectSet.add(SpousePrepareResultMobilePrimary.class);
//		emptyObjectSet.add(SpousePrepareResultMobileSecondary.class);
//		emptyObjectSet.add(ExpectedPayment.class);
//		emptyObjectSet.add(Mobile.class);
	}
	
	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).select() // Called on the Docket bean instance returns an
																// ApiSelectorBuilder
				.apis(RequestHandlerSelectors.basePackage("com.aia.ipos.api.controller")) // filter the controllers
				// .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class))
				.paths(regex("/*.*")) // filter the methods
				// .paths(PathSelectors.any())
				.build().apiInfo(metaData());

	}

	private ApiInfo metaData() {
		return new ApiInfoBuilder()
				.title("Sqs Open API")
				.description("\"Sqs Open API for Web\"")
				.version(version)
				.license("AIA").licenseUrl("--\"").build();
	}

	@Override
	protected void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
	
	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
		FastJsonConfig fastJsonConfig = new FastJsonConfig();
		fastJsonConfig.setSerializerFeatures(
			SerializerFeature.WriteNullListAsEmpty,
	        SerializerFeature.WriteMapNullValue,
	        SerializerFeature.WriteNullStringAsEmpty,
			SerializerFeature.PrettyFormat
		);
		fastJsonConfig.setDateFormat("dd/MM/yyyy");
		ValueFilter valueFilter = (object, name, value) -> {
			try {
				if(object!=null && value==null) {
					Class clazz = object.getClass();
					Field declaredField = null;
					while (!Object.class.equals(clazz)) {
						declaredField = ClassUtil.getDeclaredField(clazz, name);
						if(declaredField != null) {
							break;
						}
						clazz = clazz.getSuperclass();
					}
					if (declaredField != null && emptyObjectSet.contains(declaredField.getType())) {
						return declaredField.getType().newInstance();
					}
				}
			} catch (Exception e) {
				log.error("", e);
			}

			//String trim
			try{

				if(value instanceof String){

					if(StringUtils.isNotBlank((String) value)){
						value = ((String) value).trim();
					}
				}

			}catch (Exception e){
				log.error("", e);
			}

			return value;
		};
		fastJsonConfig.setSerializeFilters(ArrayUtil.append(fastJsonConfig.getSerializeFilters(), valueFilter));
		fastConverter.setFastJsonConfig(fastJsonConfig);
		converters.add(0,fastConverter);
	}


	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
		.allowedOrigins("*").allowedMethods("PUT", "DELETE","GET","POST")
		.allowedHeaders("*") 
		.exposedHeaders("access-control-allow-headers", 
				"access-control-allow-methods", 
				"access-control-allow-origin", 
				"access-control-max-age", "X-Frame-Options").allowCredentials(false).maxAge(3600);
		
	}
}