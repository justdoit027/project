package com.aia.sqs.api.model;

import com.aia.sqs.common.constant.ErrorCode;


public class TokenDisableResponse extends GeneralResponse<Object> {

  public TokenDisableResponse(ErrorCode errorCode) {
    this(errorCode, null);
  }

  public TokenDisableResponse(ErrorCode errorCode, String errorMessage) {
    super(errorCode, errorMessage);
  }
}

