package com.aia.sqs.common.constant.contact;

public enum  IsContacts {

    PAYOR("1"),
    INSURED("0");

    private String code;

    IsContacts(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
