package com.aia.sqs.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.Formular;
import com.aia.sqs.dao.entity.Parameter;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.aia.sqs.dao.entity.Rate;
import com.aia.sqs.service.FormularService;
import com.aia.sqs.service.ParameterService;
import com.aia.sqs.service.ProductService;
import com.aia.sqs.service.RateService;
import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin(
        origins = "*",
        allowedHeaders = "*",
        allowCredentials = "true",
        exposedHeaders= {"access-control-allow-headers", 
        		"access-control-allow-methods", 
        		"access-control-allow-origin", 
        		"access-control-max-age", "X-Frame-Options"},
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS, RequestMethod.HEAD}
)
@Slf4j
public class ProductController {
	
	@Autowired
	private ProductService productService;
	@Autowired
	private FormularService formularService;
	@Autowired
	private ParameterService parameterService;
	@Autowired
	private RateService rateService;
	@RequestMapping(value = "/api/v1/product/add", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addProduct(@RequestBody(required = false) List<String> productIds) {
		return new ResponseEntity<>(productService.add(productIds), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/release/{productId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> raleaseProduct(@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(productService.ralease(productId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/{productId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> getOneProduct(@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(productService.getOne(productId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/clone/{productId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> cloneProduct(@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(productService.clone(productId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product", produces = { "application/json" }, method = { RequestMethod.POST })
	public ResponseEntity<OutputVO> queryProductList(@RequestBody(required = false) JSONObject json) {
		return new ResponseEntity<>(productService.findAll(json), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/{productId}/plan", produces = { "application/json" }, method = { RequestMethod.GET })
	public ResponseEntity<OutputVO> queryPlanList(@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(productService.findPlanList(productId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleteFormularTemlate(@PathVariable(name = "formularId") String formularId) {
		return new ResponseEntity<>(formularService.delete(formularId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> getOneFormularTemlate(@PathVariable(name = "formularId") String formularId) {
		return new ResponseEntity<>(formularService.getOne(formularId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updateFormularTemlate(@PathVariable(name = "formularId") String formularId,
			@RequestBody Formular formular) {
		formular.setId(formularId);
		return new ResponseEntity<>(formularService.update(formular), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/formular/{productId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addFormularTemlate(@PathVariable(name = "productId") String productId,
			@RequestBody Formular formular) {
		formular.setProductId(productId);
		return new ResponseEntity<>(formularService.add(formular), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/formularList/{productId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryFormularTemlateList(
			@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(formularService.findAll(productId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleteRateTemlate(@PathVariable(name = "rateId") String rateId) {
		return new ResponseEntity<>(rateService.delete(rateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> getOneRateTemlate(@PathVariable(name = "rateId") String rateId) {
		return new ResponseEntity<>(rateService.getOne(rateId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updateRateTemlate(@PathVariable(name = "rateId") String rateId,
			@RequestBody Rate rate) {
		rate.setId(rateId);
		return new ResponseEntity<>(rateService.update(rate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/rates/{productId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addRateTemlate(@PathVariable(name = "productId") String productId,
			@RequestBody Rate rate) {
		rate.setProductId(productId);
		return new ResponseEntity<>(rateService.add(rate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/ratesList/{productId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryRateTemlateList(
			@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(rateService.findAll(productId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleteParameterTemlate(@PathVariable(name = "parameterId") String parameterId) {
		return new ResponseEntity<>(parameterService.delete(parameterId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/product/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> getOneParameterTemlate(@PathVariable(name = "parameterId") String parameterId) {
		return new ResponseEntity<>(parameterService.getOne(parameterId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updateParameterTemlate(@PathVariable(name = "parameterId") String parameterId,
			@RequestBody Parameter parameter) {
		parameter.setId(parameterId);
		return new ResponseEntity<>(parameterService.update(parameter), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/parameter/{productId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addParameterTemlate(@PathVariable(name = "productId") String productId,
			@RequestBody Parameter parameter) {
		parameter.setProductId(productId);
		return new ResponseEntity<>(parameterService.add(parameter), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/product/parameterList/{productId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryParameterTemlateList(
			@PathVariable(name = "productId") String productId) {
		return new ResponseEntity<>(parameterService.findAll(productId), HttpStatus.OK);
	}
	
}
