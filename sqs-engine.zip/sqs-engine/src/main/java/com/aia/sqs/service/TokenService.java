package com.aia.sqs.service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.api.model.TokenGet;

public interface TokenService {

	OutputVO getToken(TokenGet request, int localPort, String contextPath);

	OutputVO destoryToken(String token);
}
