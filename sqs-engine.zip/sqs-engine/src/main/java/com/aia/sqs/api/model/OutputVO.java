package com.aia.sqs.api.model;

import java.util.HashMap;
import java.util.Map;
/**
 * VO for web service output
 * 
 * @author bsnpcc1
 * @date 2019/9/20
 */
public class OutputVO {
	
	public static final String SUCCESS_CODE = "0";
	public static final String SUCCESS_MSG = "success";
	
	// 0200: success -1: fail . default 0
	private String code = SUCCESS_CODE;

	// if success,"success" else error message. default "success"
	private String message = SUCCESS_MSG;
	

	private Object data;
	
	
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	// turn VO to map
	public Map<String, Object> toMap() {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("code", code);
		result.put("message", message);
		result.put("data", data);
		return result;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
