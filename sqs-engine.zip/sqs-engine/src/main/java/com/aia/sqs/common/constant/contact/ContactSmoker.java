package com.aia.sqs.common.constant.contact;

public enum  ContactSmoker {

    Yes("YES"),No("NO");
    private final String displayName;

    ContactSmoker(String displayName) {
        this.displayName = displayName;
    }

    public static ContactSmoker valueOfDisplayName(String displayName) {
        for (ContactSmoker value : values()) {
            if (value.displayName.equals(displayName)) {
                return value;
            }
        }
        return null;
    }

    public String getDisplayName() {
        return displayName;
    }
}
