package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.Formular;
import com.aia.sqs.dao.entity.FormularTemplate;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface FormularRepository extends JpaRepository<Formular, String>, CrudRepository<Formular, String>, JpaSpecificationExecutor {
	List<Formular> findAllByProductId(String productId);
	
}
