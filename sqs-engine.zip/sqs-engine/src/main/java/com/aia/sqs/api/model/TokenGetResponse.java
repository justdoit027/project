package com.aia.sqs.api.model;

import com.aia.sqs.common.constant.ErrorCode;


public class TokenGetResponse extends GeneralResponse<TokenGetResult> {

    public TokenGetResponse(TokenGetResult result) {
        super(result);
    }

    public TokenGetResponse(ErrorCode errorCode) {
        super(errorCode);
    }

    public TokenGetResponse(ErrorCode errorCode, String errorMessage) {
        super(errorCode, errorMessage);
    }
}

