package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.AgentPlatform;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface AgentPlatformRepository extends SqsRepository<AgentPlatform, String>, JpaSpecificationExecutor {
}
