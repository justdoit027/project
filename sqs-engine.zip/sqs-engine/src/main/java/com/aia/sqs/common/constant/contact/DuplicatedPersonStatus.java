package com.aia.sqs.common.constant.contact;

public enum DuplicatedPersonStatus {

    DUPLICATED("1"),
    NOT_DUPLICATED("0");

    DuplicatedPersonStatus(String code) {
        this.code = code;
    }

    private String code;

    public String getCode() {
        return code;
    }
}
