package com.aia.sqs.service.impl;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.HandleFile;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.RateTemplate;
import com.aia.sqs.dao.repository.RateTemplateRepository;
import com.aia.sqs.service.RateTemplateService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j

public class RateTemplateServiceImpl implements RateTemplateService {
	@Autowired
	private RateTemplateRepository rateTemplateRepository;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public OutputVO delete(String rateTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			rateTemplateRepository.deleteById(rateTemplateId);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(RateTemplate rateTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (rateTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			RateTemplate sourceTemplate = rateTemplateRepository.findById(rateTemplate.getId()).get();
			UpdateTool.copyNullProperties(sourceTemplate, rateTemplate);
			rateTemplateRepository.saveAndFlush(rateTemplate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;

	}

	@Override
	public OutputVO add(RateTemplate rateTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (rateTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			
			rateTemplateRepository.saveAndFlush(rateTemplate);

		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;

	}

	@Override
	public OutputVO findAll(String planTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			List<RateTemplate> planList = rateTemplateRepository.findAllByPlanTemplateId(planTemplateId);
			
			
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}

	@Override
	public OutputVO excelToDb(MultipartFile file, String tableName) {
		OutputVO outputVO = new OutputVO();
		InputStream inputStream = null;
		try {
			if (file.isEmpty()||"".equals(tableName)||tableName==null||file==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			inputStream = file.getInputStream();
			List<List<String>> list = HandleFile.parseExcel(inputStream, file.getOriginalFilename());
			if (list.isEmpty()||list.get(0).isEmpty()) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}else if(existTable(tableName)){
				String sqlString = "DROP TABLE"+ tableName;
				jdbcTemplate.update(sqlString);
			}else {
				List<String> column = list.get(0);
				createTable(tableName, column);
				for (int i = 1; i < list.size(); i++) {
					saveObj(tableName, column, list.get(i));
				}
				
			}

		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		} finally {
			try {
				inputStream.close();
			} catch (Exception e) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				e.printStackTrace();
			}
		}

		return outputVO;
	}

	
/** 
 * 保存方法，注意这里传递的是实际的表的名称 
 */  
public  void saveObj(String tableName,List<String> column,List<String> data){  
    try{              
        String sql = " insert into " + tableName +"_template"+ " (";  
        for(String key : column){  
            sql += (key + ",");  
        }  
       sql= sql.substring(0,sql.length()-1)+")";
        sql += " values ( ";  
        for(String value : data){  
            sql += ("'" + value + "',");  
        }  
        sql=sql.substring(0,sql.length()-1)+")";
         jdbcTemplate.update(sql);          
    } catch (Exception e) {  
        e.printStackTrace();  
    }         
}   
	/** 
     * 根据表名称创建一张表 
     * @param tableName 
     */  
    public  void createTable(String tableName,List<String> list){  
        StringBuffer sb = new StringBuffer("");  
        sb.append("CREATE TABLE `" + tableName +"_template"+ "` (");  
        for(String key : list){  
            sb.append("`" + key + "` varchar(255) DEFAULT '',");  
        }  
        sb.deleteCharAt(sb.length()-1);
        sb.append(") ENGINE=InnoDB DEFAULT CHARSET=utf8;");  
        try {  
        	System.out.println(sb.toString());
        	jdbcTemplate.update(sb.toString());  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }     
	/** 
     * 查询数据库是否有某表 
     * @param cnn 
     * @param tableName 
     * @return 
     * @throws Exception 
     */  
	public boolean existTable(String tableName) throws Exception {
		Connection conn = jdbcTemplate.getDataSource().getConnection();
		ResultSet tabs = null;
		try {
			DatabaseMetaData dbMetaData = conn.getMetaData();
			String[] types = { "TABLE" };
			tabs = dbMetaData.getTables(null, null, tableName+"_Template", types);
			if (tabs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tabs.close();
			conn.close();
		}
		return false;
	}
	@Override
	public OutputVO queryById(String rateTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			
			RateTemplate rateTemplate=rateTemplateRepository.findById(rateTemplateId).get();
			if (rateTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
			}else {
				outputVO.setData(rateTemplate);
			}
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
}
