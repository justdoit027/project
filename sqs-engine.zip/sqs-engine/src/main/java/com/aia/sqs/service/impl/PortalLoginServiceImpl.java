package com.aia.sqs.service.impl;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.crypto.SecureUtil;
import com.aia.sqs.dao.entity.Agent;
import com.aia.sqs.dao.entity.SysUser;
import com.aia.sqs.dao.repository.AgentRepository;
import com.aia.sqs.dao.repository.SysUserRepository;
import com.aia.sqs.service.PortalLoginService;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class PortalLoginServiceImpl implements PortalLoginService {

    @Autowired
    private RestTemplateBuilder restTemplateBuilder;

    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    private SysUserRepository sysUserRepository;

//    @Value("${portal.login.url}")
//    private String portalLoginUrl;

//    @Value("${ipos.debug.dev_accounts}")
//    private String[] devAccounts;

//    @Value("${ipos.debug.enable}")
//    private String debugEnable;

    public static final String NO_USER_NAME = "no_username";

    @Override
    public String authenticate(String username, String password) {

        SysUser user = sysUserRepository.findByUsername(username);

        if (user == null)
        {
            return NO_USER_NAME;
        }

        String salt = user.getSalt();

        String encryptPwd = SecureUtil.md5(password+salt);


        if (!StringUtils.equals(encryptPwd,user.getPassword()))
        {
            return NO_USER_NAME;
        }

        return null;
    }

    @Override
    @Transactional
    public void saveAccount(String username) {

        String salt = username + RandomUtil.randomInt();
        String password = "12345678";
        String encryptPwd = SecureUtil.md5(password+salt);

        SysUser user = new SysUser();
        user.setUsername(username);
        user.setPassword(encryptPwd);
        user.setSalt(salt);
        user.setStatus(0);
        //user.setCreateTime(new Date());
        //user.setLastUpdateTime(new Date());
        //user.setCreateBy("system");
        //user.setLastupdateBy("system");

        sysUserRepository.save(user);
    }

    @Override
    @Transactional
    public void updateAccount(String username, String password) {
        SysUser user = sysUserRepository.findByUsername(username);

        if (user == null)
        {
            throw new RuntimeException("User not exist");
        }

        String newEncryptPwd = SecureUtil.md5(password+user.getSalt());
        user.setPassword(newEncryptPwd);

    }


    private String findIdNo(String agentCode) {
        log.info("findIdNo() start");
        Agent agent = agentRepository.getByAgentCode(agentCode);
        log.info("findIdNo() done");
        return agent == null ? null : agent.getIdNo();
    }

    private void saveAgent(JSONObject object, String idNo) {
        log.info("PortalLoginServiceImpl.saveAgent()..");
        String agentCode = object.getString("agentCode");
        Agent agent = agentRepository.getByAgentCode(agentCode);
        if (agent == null) {
            agent = new Agent();
            agent.setAgentCode(agentCode);
        }
        agent.setIdNo(idNo);
        agent.setCountry(object.getString("country"));
        agent.setBankBranchCode(object.getString("bankBranchCode"));
        agent.setAgentName(object.getString("agentName"));
        agent.setAgentStatus(object.getString("agentStatus"));
        agent.setReportTom(object.getString("reportTom"));
        agent.setAgencyCode(object.getString("agencyCode"));
        agent.setAgencyName(object.getString("agencyName"));
        agent.setPartnerBank(object.getString("partnerBank"));
        agent.setLicenseType(object.getString("licenceType"));
        agent.setLicenseExpDate(object.getString("licenseExpDate"));
        agent.setStaffRank(object.getString("staffRank"));
        agent.setAddress1(object.getString("address1"));
        agent.setAddress2(object.getString("address2"));
        agent.setAddress3(object.getString("address3"));
        agent.setAddress4(object.getString("address4"));
        agent.setAddress5(object.getString("address5"));
        agent.setAgentType(object.getString("agentType"));
        agent.setEmail(object.getString("email"));
        agent.setChannelCode(object.getString("channelCode"));
        agent.setContactNo(object.getString("contactNo"));
        agentRepository.save(agent);
    }

//    private JSONObject login(String agentCode, String idNo, String password) {
//        if (StringUtils.isAnyEmpty(agentCode, password)) {
//            JSONObject fail = new JSONObject();
//            fail.put("status", "fail");
//            fail.put("message", "userId is required.");
//            return fail;
//        }
//        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
//        String vc = DigestUtils.sha256Hex(password + date);
//        String url = portalLoginUrl + "?agentcode={agentcode}&idno={idno}&password={password}&programname={programname}&hardwardId={hardwardId}&vc={vc}&date={date}";
//        Map<String, Object> params = new HashMap<>();
//        params.put("agentcode", agentCode);
//        params.put("idno", idNo);
//        params.put("password", password);
//        params.put("programname", "iMO");
//        params.put("hardwardId", "");
//        params.put("vc", vc);
//        params.put("date", date);
//        String responseBody;
//        try {
//            ResponseEntity<String> response = restTemplateBuilder.build()
//                    .getForEntity(url, String.class, params);
//            responseBody = response.getBody();
//        } catch (HttpClientErrorException e) {
//            responseBody = e.getResponseBodyAsString();
//        }
//
//        return JSON.parseObject(responseBody);
//
//
//    }

}
