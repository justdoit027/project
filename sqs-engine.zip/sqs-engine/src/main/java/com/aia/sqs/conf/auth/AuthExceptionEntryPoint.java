package com.aia.sqs.conf.auth;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.aia.sqs.api.model.OutputVO;

public class AuthExceptionEntryPoint implements AuthenticationEntryPoint
{

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
        AuthenticationException authException) throws ServletException {
        Throwable cause = authException.getCause();
        ObjectMapper mapper = new ObjectMapper();
    	OutputVO outputVO =new OutputVO();
    	   Map<String, Object> map = new HashMap<String, Object>();
        if(cause instanceof InvalidTokenException) {
        
        	outputVO.setMessage("invalid_token");
            outputVO.setCode("-1");
            try {
				mapper.writeValue(response.getOutputStream(), outputVO);
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
        map.put("data", authException.getMessage());
        map.put("success", false);
        map.put("path", request.getServletPath());
        map.put("timestamp", String.valueOf(new Date().getTime()));
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        try {
           
            mapper.writeValue(response.getOutputStream(), map);
        } catch (Exception e) {
            throw new ServletException();
        }
    }


}
