package com.aia.sqs.service.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.PageOutPut;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.aia.sqs.dao.repository.PlanTemplateRepository;
import com.aia.sqs.service.PlanTemplateService;
import com.alibaba.fastjson.JSONObject;
@Service
public class PlanTemplateServiceImpl<T> implements PlanTemplateService{
	@Autowired 
	private PlanTemplateRepository planTemplateRepository;
	@Override
	public OutputVO delete(String PlanTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			planTemplateRepository.deleteById(PlanTemplateId);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
	@Override
	public OutputVO getOne(String PlanTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			PlanTemplate planTemplate = planTemplateRepository.findById(PlanTemplateId).get();
			outputVO.setData(planTemplate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(PlanTemplate planTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (planTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			PlanTemplate sourceTemplate = planTemplateRepository.findById(planTemplate.getId()).get();
			UpdateTool.copyNullProperties(sourceTemplate, planTemplate);
			planTemplateRepository.saveAndFlush(planTemplate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO clone(String PlanTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			PlanTemplate plan = planTemplateRepository.findById(PlanTemplateId).get();
			PlanTemplate clonePlan= new PlanTemplate(); 
			if(plan!=null) {
				clonePlan.setDescription(plan.getDescription());	
				clonePlan.setIsRider(plan.getIsRider());
				clonePlan.setPlanName(plan.getPlanName());
				clonePlan.setPlanCode(plan.getPlanCode());
				planTemplateRepository.save(clonePlan);
			}else {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
				}
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public OutputVO findAll(JSONObject json) {
		OutputVO outputVO = new OutputVO();
		
		Integer page=0;
		Integer size=10;
		PlanTemplate planTemplate=new PlanTemplate();
		try {
			if (json!=null) {
				page=json.getInteger("page")==null?0:json.getInteger("page")-1;
				size=json.getInteger("size")==null?10:json.getInteger("size");
				planTemplate.setPlanName(json.get("plan_name")==null?"":json.get("plan_name").toString());
				planTemplate.setPlanCode(json.get("plan_code")==null?"":json.get("plan_code").toString());

			}
							
			 Pageable pageable =  PageRequest.of(page, size, Sort.Direction.DESC, "createTime");
			 List<PlanTemplate> list =  planTemplateRepository.findAll(new Specification<PlanTemplate>(){
					@Override
					public Predicate toPredicate(Root<PlanTemplate> root, CriteriaQuery<?> query,CriteriaBuilder criteriaBuilder) {
						  List<Predicate> list = new ArrayList<Predicate>();
			                if(null!=planTemplate.getPlanName()&&!"".equals(planTemplate.getPlanName())){
			                    list.add(criteriaBuilder.equal(root.get("planName").as(String.class),"%"+planTemplate.getPlanName()+"%"));
			                }
			                if(null!=planTemplate.getPlanCode()&&!"".equals(planTemplate.getPlanCode())){
			                	list.add(criteriaBuilder.equal(root.get("planCode").as(String.class), "%"+planTemplate.getPlanCode()+"%"));
			                }
			                Predicate[] p = new Predicate[list.size()];
			                return criteriaBuilder.and(list.toArray(p));
					}
		        });

				
			 Page<PlanTemplate> planTemplatePage = planTemplateRepository.findAll(new Specification<PlanTemplate>(){
					@Override
					public Predicate toPredicate(Root<PlanTemplate> root, CriteriaQuery<?> query,CriteriaBuilder criteriaBuilder) {
						  List<Predicate> list = new ArrayList<Predicate>();
			                if(null!=planTemplate.getPlanName()&&!"".equals(planTemplate.getPlanName())){
			                    list.add(criteriaBuilder.equal(root.get("planName").as(String.class), "%"+planTemplate.getPlanName()+"%"));
			                }
			                if(null!=planTemplate.getPlanCode()&&!"".equals(planTemplate.getPlanCode())){
			                	list.add(criteriaBuilder.equal(root.get("planCode").as(String.class), "%"+planTemplate.getPlanCode()+"%"));
			                }
			                Predicate[] p = new Predicate[list.size()];
			                return criteriaBuilder.and(list.toArray(p));
					}
		        },pageable);
			 	Map<String, Object> map = new HashMap<String, Object>();
			 	PageOutPut pageOutPut= new PageOutPut();
			 	pageOutPut.setCurrent(page+1);
			 	pageOutPut.setTotal(planTemplatePage.getContent().size());
			 	
			 	map.put("list", planTemplatePage.getContent());
			 	map.put("page", pageOutPut);
			 	
				outputVO.setData(map);
				
			 
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO add(PlanTemplate plan) {
		OutputVO outputVO = new OutputVO();
		try {
			if (plan==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
				planTemplateRepository.save(plan);
			
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
	}

}
