package com.aia.sqs.aop;

import com.aia.sqs.aop.support.DataSource;
import com.aia.sqs.common.mutildatasource.DataSourceContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;


@Aspect
@Component
@Slf4j
@Order(1)   //need before spring transtion manager execute.
public class MutilDataSourceAop{


    @Pointcut(value = "@annotation(com.aia.sqs.aop.support.DataSource)")
    private void cut() {

    }

    @Around("cut()")
    public Object around(ProceedingJoinPoint point) throws Throwable {

        Signature signature = point.getSignature();
        MethodSignature methodSignature = null;
        if (!(signature instanceof MethodSignature)) {
            throw new IllegalArgumentException("@DataSource only can use to method.");
        }
        methodSignature = (MethodSignature) signature;

        Object target = point.getTarget();
        Method currentMethod = target.getClass().getMethod(methodSignature.getName(), methodSignature.getParameterTypes());

        DataSource datasource = currentMethod.getAnnotation(DataSource.class);
        if(datasource != null){
            DataSourceContextHolder.setDataSourceType(datasource.value());
            log.debug("Set Current DataSource：" + datasource.value());
        }

        try {
            return point.proceed();
        } finally {
            log.debug("Clear datasource configuration！");
            DataSourceContextHolder.clearDataSourceType();
        }
    }

}
