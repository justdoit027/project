package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.SysUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface SysUserRepository extends JpaRepository<SysUser, String>, CrudRepository<SysUser, String>, JpaSpecificationExecutor {

    SysUser findByUsername(String username);

    SysUser findByUsernameAndPassword(String username,String password);

}
