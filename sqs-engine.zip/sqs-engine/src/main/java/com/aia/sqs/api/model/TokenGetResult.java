package com.aia.sqs.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenGetResult {
  private String registeredAgent;
  private String token;
  private String agentCode;
  private String portraitUrl;
  private String agentName;
  private String agencyCode;
  private String agencyName;
  private String managerName;
  private String licenseType;
  private String licenseExpiryDate;
  private String contactNo;
  private String currentVersion;
  private String buildId;
  private String email;
  private String agreeLicense;
  private String hasOtherToken;
  private List<String> platformList;
}

