package com.aia.sqs.common.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.io.*;
import java.util.Base64;

/**
 * File Handle Util
 */
@Slf4j
public class FileUtil {

    public static Integer getBase64StringSize(String content){
        if(StringUtils.isEmpty(content)){
            return 0;
        }

        byte[] bytes = content.getBytes();
        int bytesLength = bytes.length;

        return bytesLength/1024;
    }

    public static byte[] getFileData(File file) {

        FileInputStream fileInputStream = null;
        BufferedInputStream bufferedInputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {

            fileInputStream = new FileInputStream(file);
            bufferedInputStream = new BufferedInputStream(fileInputStream);

            byteArrayOutputStream = new ByteArrayOutputStream();

            int size = (int) (1024 * 1024 * 0.5);
            int len;
            byte[] buffer = new byte[size];

            while ((len = bufferedInputStream.read(buffer)) > 0) {
                byteArrayOutputStream.write(buffer, 0, len);
            }
            byteArrayOutputStream.flush();

            return byteArrayOutputStream.toByteArray();

        } catch (Exception e) {
            log.error("", e);
            throw new RuntimeException("getFileDataByPath error");

        } finally {

            if (byteArrayOutputStream != null) {
                try {
                    byteArrayOutputStream.close();
                } catch (IOException e) {
                    log.error("", e);
                }
            }

            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    log.error("", e);
                }
            }

            if (bufferedInputStream != null) {
                try {
                    bufferedInputStream.close();
                } catch (IOException e) {
                    log.error("", e);
                }
            }

        }
    }


    public static byte[] getFileDataByPath(String path) {

       return getFileData(new File(path));

    }

    /**
     * create file by path
     */
    public static File createFile(String path) {
        File file = null;
        try {
            if (StringUtils.isEmpty(path)) {
                throw new RuntimeException("empty file path");
            }

            file = new File(path);

            if (file.exists()) {
                file.delete();
            } else {
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
            }

            file.createNewFile();

            return file;

        } catch (Exception e) {
            log.error("", e);
            throw new RuntimeException("create file error");
        }
    }

    /**
     * create file by path
     */
    public static File createDir(String path) {
        File file = null;
        try {
            if (StringUtils.isEmpty(path)) {
                throw new RuntimeException("empty file path");
            }

            file = new File(path);

            if (file.exists()) {

               return file;

            } else {
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
            }

            file.mkdir();

            return file;

        } catch (Exception e) {
            log.error("", e);
            throw new RuntimeException("create file error");
        }
    }


    public static void copyInputStreamToFile(InputStream inputStream, File file) {
        int size = (int) (1024 * 1024 * 0.5);
        int len;
        byte[] buffer = new byte[size];

        FileOutputStream fileOutputStream = null;
        BufferedOutputStream bufferedOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream(file);
            bufferedOutputStream = new BufferedOutputStream(fileOutputStream);

            while ((len = inputStream.read(buffer)) > 0) {
                bufferedOutputStream.write(buffer, 0, len);
            }

            bufferedOutputStream.flush();

        } catch (IOException e) {
            log.error("copyInputStreamToFile error", e);

            throw new RuntimeException("write data to file error");

        } finally {

            try {
                if (bufferedOutputStream != null) {
                    bufferedOutputStream.close();
                }
            } catch (IOException e) {
                log.error("bufferedOutputStream.close error", e);
            }

            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            } catch (IOException e) {
                log.error("fileOutputStream.close error", e);
            }

            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                log.error("inputStream.close error", e);
            }
        }
    }

    public static void exportBase64FileToPdf(String content,String path){

        try{
            byte[] pdfData = Base64.getDecoder().decode(content);
            FileOutputStream fileOutputStream = new FileOutputStream(path);
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);

            bufferedOutputStream.write(pdfData);
            bufferedOutputStream.flush();

        }catch (Exception e){
            log.error("",e);
        }

    }

    public static void exportBase64FileToPdf(byte[] content,String path){

        try(FileOutputStream fileOutputStream  = new FileOutputStream(path);
            BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
            ) {

            bufferedOutputStream.write(content);
            bufferedOutputStream.flush();

        }catch (Exception e){
            log.error("",e);
        }

    }
}
