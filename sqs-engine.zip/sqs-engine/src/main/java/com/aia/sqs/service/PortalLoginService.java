package com.aia.sqs.service;

import com.aia.sqs.dao.entity.SysUser;

public interface PortalLoginService {

    String authenticate(String name, String password);

    void saveAccount(String account);

    void updateAccount(String account,String password);

    //SysUser findByAccount(String account);

}
