package com.aia.sqs.service.impl;


import com.aia.sqs.dao.entity.Contact;
import com.aia.sqs.dao.repository.ContactRepository;
import com.aia.sqs.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactServiceImpl implements ContactService {

    @Autowired
    private ContactRepository contactRepository;


    @Override
    public List<Contact> finaAll() {
        return contactRepository.findAll();
    }

    @Override
    public Contact findById(String contactId) {
        return contactRepository.findById(contactId).get();
    }

    @Override
    public void delete(String contactId) {
        contactRepository.deleteById(contactId);
    }

    @Override
    public void save(Contact contact) {
        contactRepository.save(contact);
    }
}
