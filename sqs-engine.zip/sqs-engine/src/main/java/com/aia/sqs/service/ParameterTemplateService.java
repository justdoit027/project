package com.aia.sqs.service;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.ParameterTemplate;

public interface ParameterTemplateService {
	OutputVO delete(String parameterTemplateId);
	OutputVO queryById(String parameterTemplateId);
	OutputVO update(ParameterTemplate parameterTemplate);
	OutputVO add(ParameterTemplate parameterTemplate);
	OutputVO findAll(String planTemplateId);
	
}
