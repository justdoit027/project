package com.aia.sqs.service.impl;

import com.aia.sqs.dao.entity.SysUser;
import com.aia.sqs.dao.repository.SysUserRepository;
import com.aia.sqs.service.SysUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SysUserServiceImpl implements SysUserService {

    @Autowired
    private SysUserRepository sysUserRepository;

    @Override
    public SysUser findByUserName(String username) {
        return sysUserRepository.findByUsername(username);
    }

    @Override
    public SysUser authenticate(String username, String password) {
        return sysUserRepository.findByUsernameAndPassword(username,password);
    }

}
