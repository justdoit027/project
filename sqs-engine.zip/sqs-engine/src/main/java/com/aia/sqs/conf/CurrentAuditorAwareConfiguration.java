//package com.aia.sqs.conf;
//
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.domain.AuditorAware;
//import org.springframework.security.oauth2.provider.OAuth2Authentication;
//import org.springframework.security.oauth2.provider.token.TokenStore;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.util.Optional;
//
//@Configuration
//@Slf4j
//public class CurrentAuditorAwareConfiguration implements AuditorAware<String> {
//
//	@Autowired
//	private TokenStore tokenStore;
//
//	@Override
//	public Optional<String> getCurrentAuditor() {
//		log.info("getCurrentAuditor() start");
//		ServletRequestAttributes requestAttrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//		if (requestAttrs == null) {
//			log.info("requestAttrs null, return empty");
//			return Optional.empty();
//		}
//		HttpServletRequest request = requestAttrs.getRequest();
//		String token = request.getHeader("token");
//
//		if (StringUtils.isEmpty(token))
//		{
//			token = request.getParameter("token");
//		}
//
//		if (StringUtils.isEmpty(token)) {
//			log.info("token is blank, return empty");
//			return Optional.empty();
//		}
//
//		OAuth2Authentication authentication = tokenStore.readAuthentication(token);
//		if (authentication == null) {
//			log.info("no authentication, return empty");
//			return Optional.empty();
//		}
//		String principal = (String) authentication.getUserAuthentication().getPrincipal();
//		log.info("getCurrentAuditor() principal={}",principal);
//
//		if (StringUtils.isEmpty(principal)) {
//			log.info("no principal, return empty");
//			return Optional.empty();
//		}
//		//Account account = Account.fromString(principal);
//
//		log.info("getCurrentAuditor() end");
//
//		return Optional.of(principal);
//	}
//
//}
