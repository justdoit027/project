package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="sys_user",schema = "hiposuu")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysUser extends BaseEntity{

    @Column(name="username")
    private String username;

    @Column(name="password")
    private String password;

    @Column(name="salt")
    private String salt;

    @Column(name="status")
    private Integer status;

   

}
