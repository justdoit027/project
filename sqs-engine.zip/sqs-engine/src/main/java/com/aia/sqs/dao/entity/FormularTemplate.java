package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_formular_template")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormularTemplate extends BaseEntity{

    @Column(name="formular_key")
    private String formularKey;

    @Column(name="formular_name")
    private String formularName;
    @Column(name="formular_expression")
    private String formularExpression;
    @Column(name="default_value")
    private String defaultValue;
    @Column(name="rounding")
    private int rounding;
    @Column(name="type")
    private String type;
    @Column(name="description")
    private String description;
    
    @Column(name="plan_template_id")
    private String planTemplateId;
    
   
  
   

}
