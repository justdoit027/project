package com.aia.sqs.common.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SqsLoggerFactory {

    public static Logger getLogger(String name) {
        return LoggerFactory.getLogger(" sqs-engine " + name);
    }

    public static Logger getLogger(Class<?> clazz) {
        return getLogger(clazz.getSimpleName());
    }
}
