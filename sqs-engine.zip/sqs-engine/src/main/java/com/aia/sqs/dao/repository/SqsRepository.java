package com.aia.sqs.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.NoRepositoryBean;

import javax.persistence.LockModeType;
import java.util.List;

@NoRepositoryBean
public interface SqsRepository<T, ID> extends JpaRepository<T, ID> {

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    void delete(T var1);

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    void deleteAll(Iterable<? extends T> var1);

    @Deprecated
    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    void deleteById(ID var1);

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    <S extends T> List<S> saveAll(Iterable<S> entities);

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    <S extends T> S saveAndFlush(S entity);

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    <S extends T> S save(S entity);

}

