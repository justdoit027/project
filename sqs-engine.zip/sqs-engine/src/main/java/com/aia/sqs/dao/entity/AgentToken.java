package com.aia.sqs.dao.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="T_AgentToken")
public class AgentToken extends AbstractEntity<String>{
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(length = 60)
    private String agentTokenId;
    @Column(length = 64,updatable = false)
    protected String agentCode;
    @Column(length = 64, nullable = false, updatable = false)
    private String accessToken;
    @Temporal(TemporalType.TIMESTAMP)
    private Date validTo;
    @Temporal(TemporalType.TIMESTAMP)
    private Date disabledAt;

    @Override
    public String getId() {
        return agentTokenId;
    }

    public String getAgentTokenId() {
        return agentTokenId;
    }

    public void setAgentTokenId(String agentTokenId) {
        this.agentTokenId = agentTokenId;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public Date getDisabledAt() {
        return disabledAt;
    }

    public void setDisabledAt(Date disabledAt) {
        this.disabledAt = disabledAt;
    }
}
