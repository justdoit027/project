package com.aia.sqs.dao.entity;


import com.aia.sqs.common.constant.contact.ContactGender;
import com.aia.sqs.common.constant.contact.ContactSmoker;
import com.aia.sqs.common.constant.contact.IsContacts;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Nationalized;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name="contact",schema = "hiposuu")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Contact{

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name="contactid")
	private String id;

	@Column(name="createdby")
	private String createdBy;

	@Column(name="updatedby")
	private String updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="createddatetime")
	private Date createdDatetime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="lastupdatedatetime")
	private Date lastUpdateDatetime;

	@Column(name="titleid")
	private String titleId;

	@Column(name="lastname_en")
	private String lastnameEn;

	@Column(name="firstname_en")
	private String firstnameEn;

	@Column(name="alias")
	private String alias;

	@Nationalized
	@Column(name="name_chn")
	private ContactGender nameChn;

	@Column(name="gender")
	private String gender;

	@Column(name="accesscode")
	private String accessCode;

	@Column(name="agentcode")
	private String agentCode;

	@Column(name="citizenshipcode")
	private IsContacts citizenShipCode;

	@Column(name="othercitizenship")
	private String otherCitizenShip;

	@Column(name="nationalitycode")
	private String nationalityCode;

	@Column(name="othernationality")
	private String otherNationality;

	@Column(name="residentialcode")
	private String residentialCode;

	@Column(name="otherresidential")
	private String otherResidential;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="dob")
	private Date dob;

	@Column(name="age")
	private Integer age;

	@Column(name="maritalstatus")
	private String maritalStatus;

	@Column(name="ssn")
	private String ssn;

	@Column(name="contacttype")
	private String contactType;

	@Column(name="processstatus")
	private String processStatus;

	@Column(name="prc")
	private Integer prc;

	@Column(name="originalcontactid")
	private String originalContactId;

	@Column(name="businesscertificateno")
	private String businessCertificateNo;

	@Column(name="smoker")
	private Integer smoker;

	@Column(name="remark")
	private String remark;

	@Column(name="iampcustomerid")
	private String iampCustomerId;

	@Column(name="servercontactid")
	private ContactSmoker serverContactId;

	@Column(name="duplicate")
	private Integer duplicate;

	@Column(name="citycode")
	private String cityCode;

	@Column(name="authorizedperson")
	private String authorizedPerson;

	@Column(name="authorizedpersontitle")
	private String authorizedPersonTitle;

	@Column(name="occupationcode")
	private String occupationCode;

	@Column(name="industrycode")
	private String industryCode;

}