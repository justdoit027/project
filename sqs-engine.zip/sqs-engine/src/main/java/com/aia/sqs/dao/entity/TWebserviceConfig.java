package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
    Test Used
*/
@Entity
@Table(name="T_WEBSERVICECONFIG",schema = "dbo")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TWebserviceConfig implements java.io.Serializable {

	@Id
	@GenericGenerator(name="idGenerator", strategy="assigned")
	@GeneratedValue(generator="idGenerator")
	@Column(name="WEBSERVICECONFIGID")
	private String id;

	@Column(name="KEYVALUE")
	private String keyValue;

	@Column(name="URLINFO")
	private String urlInfo;

	@Column(name="TARGETNAMESPACE")
	private String targetNameSpace;

	@Column(name="SERVICENAME")
	private String serviceName;

	@Column(name="CREATEBY")
	private String createBy;

	@Column(name="UPDATEBY")
	private String updateBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATEDDATETIME")
	private Date createdDatetime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LASTUPDATEDATETIME")
	private Date lastUpdateDatetime;

	@Column(name="VERSIONCONTROL")
	private String versionControl;

	@Column(name="MMURLINFO")
	private String mmUrlinfo;
}
