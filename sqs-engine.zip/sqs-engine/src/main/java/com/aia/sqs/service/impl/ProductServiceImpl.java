package com.aia.sqs.service.impl;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.StringUtil;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.Formular;
import com.aia.sqs.dao.entity.FormularTemplate;
import com.aia.sqs.dao.entity.PageOutPut;
import com.aia.sqs.dao.entity.Parameter;
import com.aia.sqs.dao.entity.ParameterTemplate;
import com.aia.sqs.dao.entity.Plan;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.aia.sqs.dao.entity.Product;
import com.aia.sqs.dao.entity.Rate;
import com.aia.sqs.dao.entity.RateTemplate;
import com.aia.sqs.dao.repository.FormularRepository;
import com.aia.sqs.dao.repository.FormularTemplateRepository;
import com.aia.sqs.dao.repository.ParameterRepository;
import com.aia.sqs.dao.repository.ParameterTemplateRepository;
import com.aia.sqs.dao.repository.PlanRepository;
import com.aia.sqs.dao.repository.PlanTemplateRepository;
import com.aia.sqs.dao.repository.ProductRepository;
import com.aia.sqs.dao.repository.RateRepository;
import com.aia.sqs.dao.repository.RateTemplateRepository;
import com.aia.sqs.service.ProductService;
import com.alibaba.fastjson.JSONObject;
@Service
@Transactional(rollbackFor=Exception.class)
public class ProductServiceImpl implements ProductService{
	@Autowired 
	private ProductRepository productRepository;
	@Autowired 
	private PlanRepository planRepository;
	@Autowired 
	private FormularRepository formularRepository;
	@Autowired 
	private FormularTemplateRepository formularTemplateRepository;
	@Autowired 
	private ParameterRepository parameterRepository;
	@Autowired 
	private ParameterTemplateRepository parameterTemplateRepository;
	@Autowired 
	private PlanTemplateRepository planTemplateRepository;
	
	@Autowired
	private RateRepository rateRepository;
	@Autowired
	private RateTemplateRepository rateTemplateRepository;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public OutputVO ralease(String ProductId) {
		OutputVO outputVO = new OutputVO();
		try {
			Product product = productRepository.findById(ProductId).get();
			if (product==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}else {
				product.setStatus("completed");
				productRepository.saveAndFlush(product);
			}
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
	public OutputVO getOne(String ProductId) {
		OutputVO outputVO = new OutputVO();
		try {
			Product product = productRepository.findById(ProductId).get();
			outputVO.setData(product);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO findPlanList(String productId) {
		OutputVO outputVO = new OutputVO();
		try {
			if (productId==null||"".equals(productId)) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}else {
				outputVO.setData(planRepository.findAllByProductId(productId));
			}
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO clone(String ProductId) {
		OutputVO outputVO = new OutputVO();
		try {
			Product product = productRepository.findById(ProductId).get();
			
			Product clonePlan= new Product(); 
			if(product!=null) {
				UpdateTool.copyNullProperties(product, clonePlan);
				clonePlan.setId(null);
				productRepository.saveAndFlush(clonePlan);
			}else {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
				}
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public OutputVO findAll(JSONObject json) {
		OutputVO outputVO = new OutputVO();
		
		Integer page=0;
		Integer size=10;
		Product product=new Product();
		try {
			if (json!=null) {
				page=json.getInteger("page")==null?0:json.getInteger("page")-1;
				size=json.getInteger("size")==null?10:json.getInteger("size");
				product.setProductCode(json.get("product_code")==null?"":json.get("product_code").toString());
				product.setProductCategoryId(json.get("product_category_id")==null?"":json.get("product_category_id").toString());

			}
			 List<Product> list =  productRepository.findAll(new Specification<Product>(){
					@Override
					public Predicate toPredicate(Root<Product> root, CriteriaQuery<?> query,CriteriaBuilder criteriaBuilder) {
						  List<Predicate> list = new ArrayList<Predicate>();
			                if(null!=product.getProductCode()&&!"".equals(product.getProductCode())){
			                    list.add(criteriaBuilder.like(root.get("productCode").as(String.class), "%"+product.getProductCode()+"%"));
			                }
			                if(null!=product.getProductCategoryId()&&!"".equals(product.getProductCategoryId())){
			                	list.add(criteriaBuilder.like(root.get("productCategoryId").as(String.class), "%"+product.getProductCategoryId()+"%"));
			                }
			                Predicate[] p = new Predicate[list.size()];
			                return criteriaBuilder.and(list.toArray(p));
					}
		        });

		        
							
			 Pageable pageable =  PageRequest.of(page, size, Sort.Direction.DESC, "createTime");
			 Page<Product> productPage = productRepository.findAll(new Specification<Product>(){
					@Override
					public Predicate toPredicate(Root<Product> root, CriteriaQuery<?> query,CriteriaBuilder criteriaBuilder) {
						  List<Predicate> list = new ArrayList<Predicate>();
			                if(null!=product.getProductCode()&&!"".equals(product.getProductCode())){
			                	list.add(criteriaBuilder.like(root.get("productCode").as(String.class), "%"+product.getProductCode()+"%"));
			                }
			                if(null!=product.getProductCategoryId()&&!"".equals(product.getProductCategoryId())){
			                	list.add(criteriaBuilder.like(root.get("productCategoryId").as(String.class), "%"+product.getProductCategoryId()+"%"));
			                }
			                Predicate[] p = new Predicate[list.size()];
			                return criteriaBuilder.and(list.toArray(p));
					}
		        },pageable);
				Map<String, Object> map = new HashMap<String, Object>();
			 	PageOutPut pageOutPut= new PageOutPut();
			 	pageOutPut.setCurrent(page+1);
			 	pageOutPut.setTotal(list.size());
			 	
			 	map.put("list", productPage.getContent());
			 	map.put("page", pageOutPut);
			 	
				outputVO.setData(map);
			
			 
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO add(List<String> planTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			if (planTemplateId.size()<=0) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}else {
				for (String id : planTemplateId) {
					Boolean flag=domain(id);
					if (!flag) {
						outputVO.setCode("-1");
						outputVO.setMessage("Invalid parameter");
						return outputVO;
					}
				}
			}
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
	}
	public Boolean domain(String planTemplateId) {
		Boolean flag = true;
		List<Parameter> parameters= new ArrayList<Parameter>();
		List<Rate> rates= new ArrayList<Rate>();
		List<Formular> formulars= new ArrayList<Formular>();
		PlanTemplate planTemplate=planTemplateRepository.findById(planTemplateId).get();
		List<FormularTemplate> formularTemplateList = formularTemplateRepository.findAllByPlanTemplateId(planTemplateId);
		List<RateTemplate> rateTemplatesList = rateTemplateRepository.findAllByPlanTemplateId(planTemplateId);
		List<ParameterTemplate> parameterList = parameterTemplateRepository.findAllByPlanTemplateId(planTemplateId);
		if (planTemplate==null||formularTemplateList.size()<=0||rateTemplatesList.size()<=0||parameterList.size()<=0) {
			flag=false;
		}else {
			Product product= new Product();
			String productCode = StringUtil.getUUID();
			product.setProductCode(productCode);
			productRepository.saveAndFlush(product);
			product = productRepository.findByProductCode(productCode);
			Plan plan = new Plan();
			BeanUtils.copyProperties(planTemplate, plan);
			plan.setPlanTemplateId(planTemplateId);
			plan.setProductId(product.getId());
			
			planRepository.saveAndFlush(plan);
			for (ParameterTemplate parameterTemplate : parameterList) {
				Parameter parameter =new Parameter();
				BeanUtils.copyProperties(parameterTemplate, parameter);
				parameter.setProductId(product.getId());
				parameter.setPlanId(plan.getId());
				parameters.add(parameter);
			}
			for (RateTemplate rateTemplate : rateTemplatesList) {
				
				Rate rate =new Rate();
				BeanUtils.copyProperties(rateTemplate, rate);
				String tableName= rate.getTableName().replaceAll("_template", "").trim();
				if (existTable(tableName)) {
					flag=false;
				}
				rate.setProductId(product.getId());
				rate.setTableName(tableName);
				//copy table  del  "_Template"
				String sql="create table "+tableName+" select * from "+rateTemplate.getTableName();
				jdbcTemplate.update(sql);
				rate.setPlanId(plan.getId());
				rates.add(rate);
			}
			for (FormularTemplate formularTemplate : formularTemplateList) {
				Formular formular =new Formular();
				BeanUtils.copyProperties(formularTemplate, formular);
				formular.setProductId(product.getId());
				formular.setPlanId(plan.getId());
				formulars.add(formular);
			}
			formularRepository.saveAll(formulars);
			rateRepository.saveAll(rates);
			parameterRepository.saveAll(parameters);
		}
		return flag;
	}
	
	/** 
     * 查询数据库是否有某表 
     * @param cnn 
     * @param tableName 
     * @return 
     * @throws Exception 
     */  
	public boolean existTable(String tableName)  {
		Connection conn=null;
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet tabs = null;
		try {
			DatabaseMetaData dbMetaData = conn.getMetaData();
			String[] types = { "TABLE" };
			tabs = dbMetaData.getTables(null, null, tableName, types);
			if (tabs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				tabs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}
}
