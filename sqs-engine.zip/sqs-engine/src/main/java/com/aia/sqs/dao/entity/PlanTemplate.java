package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.mysql.cj.jdbc.Blob;
@Entity
@Table(name="t_plan_template")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PlanTemplate extends BaseEntity{

    @Column(name="plan_code")
    private String planCode;

    @Column(name="plan_name")
    private String planName;

    @Column(name="is_rider")
    private int isRider;

    @Column(name="description")
    private String description;
    
   
    
  
   

}
