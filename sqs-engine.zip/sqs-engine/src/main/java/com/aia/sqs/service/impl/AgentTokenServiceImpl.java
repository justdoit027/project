package com.aia.sqs.service.impl;


import com.aia.sqs.api.model.TokenDisableResponse;
import com.aia.sqs.api.model.TokenGetRequest;
import com.aia.sqs.api.model.TokenGetResponse;
import com.aia.sqs.api.model.TokenGetResult;
import com.aia.sqs.common.constant.ErrorCode;
import com.aia.sqs.common.exception.BusinessException;
import com.aia.sqs.dao.entity.Agent;
import com.aia.sqs.dao.entity.AgentPlatform;
import com.aia.sqs.dao.entity.AgentToken;
import com.aia.sqs.dao.repository.AgentPlatformRepository;
import com.aia.sqs.dao.repository.AgentRepository;
import com.aia.sqs.dao.repository.AgentTokenRepository;
import com.aia.sqs.service.AgentTokenService;
import com.aia.sqs.service.model.Account;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.aia.sqs.dao.entity.AgentPlatform.Platform;

@Slf4j
@Service
public class AgentTokenServiceImpl implements AgentTokenService {

    @Autowired
    private RestTemplateBuilder restTemplateBuilder;
    @Autowired
    private AgentRepository agentRepository;
    @Autowired
    private AgentTokenRepository agentTokenRepository;
    @Autowired
    private AgentPlatformRepository agentPlatformRepository;
    @Autowired
    private TokenStoreImpl tokenStoreImpl;


    @Override
    @Transactional
    public TokenGetResponse getToken(TokenGetRequest request, int localPort, String contextPath) {
        log.info("getToken() start");
        String agentCode = request.getUserId();
        String idNo = request.getIdNo();

        log.info("listPlatforms..");
        List<String> platformConfigurationList = listPlatforms(agentCode);
        if (!platformConfigurationList.contains(Platform.WEB_IPOS.name())) {
            log.info("platforms not contains web_ipos..");
            return new TokenGetResponse(ErrorCode.PLATFORM_WRONG);
        }

        log.info("request oauth token..");
        Account account = Account.generateAccount(agentCode, idNo);
        JSONObject oauthResult = requestOAuthToken(
                account.asString(), request.getPassword(), localPort, contextPath);
        log.info("request oauth token done.");

        String error = oauthResult.getString("message");
        if (PortalLoginServiceImpl.NO_USER_NAME.equals(error)){
            log.info("no idNo.");
            TokenGetResult result = new TokenGetResult();
            result.setRegisteredAgent("0");
            return new TokenGetResponse(result);
        }

        if ("Agent Code not exists".equals(error)) {
            log.info("Agent code not exists.");
            return new TokenGetResponse(ErrorCode.AGENT_NOT_EXISTED, error);
        }
        if ("User ID is Locked.".equals(error)){
            log.info("User ID is locked.");
            return new TokenGetResponse(ErrorCode.AGENT_LOCKED, error);
        }
        if ("Wrong password".equals(error)){
            log.info("Wrong password.");
            return new TokenGetResponse(ErrorCode.AGENT_PASSWORD_WRONG, error);
        }
        if ("Wrong ID Number !".equals(error)) {
            log.info("Wrong ID number.");
            return new TokenGetResponse(ErrorCode.AGENT_ID_NO_WRONG, error);
        }
        if ("not_ag_channel".equals(error)) {
            log.info("not AG channel");
            return new TokenGetResponse(ErrorCode.NOT_AG_CHANNEL, error);
        }
        String tokenValue = oauthResult.getString("value");
        if (StringUtils.isEmpty(tokenValue)) {
            log.info("unauthorized, error={}", error);
            throw BusinessException.UNAUTHORIZED;
        }

        log.info("check other tokens..");
        List<AgentToken> otherEnabledTokens =
                agentTokenRepository.findAllByDisabledAtIsNullAndAgentCodeEqualsAndAccessTokenNot(
                agentCode, tokenValue);
        if (CollectionUtils.isNotEmpty(otherEnabledTokens)) {
            List<AgentToken> otherActiveTokens = otherEnabledTokens.stream()
                    .filter(this::isTokenActive)
                    .collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(otherActiveTokens)
                    && !"1".equals(request.getDisableOtherToken())) {
                log.info("return hasOtherToken, accessToken:{}", tokenValue);
                TokenGetResult result = new TokenGetResult();
                result.setHasOtherToken("1");
                return new TokenGetResponse(result);
            }

            log.info("disable other sessions: {}", otherEnabledTokens);
            for (AgentToken otherToken : otherEnabledTokens) {
                doDisableToken(otherToken.getAccessToken());
            }
        }
        log.info("record AgentToken..");
        recordAgentToken(agentCode, tokenValue);

        log.info("create TokenGetResponse..");
        Agent agent = agentRepository.getByAgentCode(agentCode);
        TokenGetResult result = new TokenGetResult();
        List<String> platformList = new ArrayList<>();
        if (platformConfigurationList.contains(Platform.WEB_IPOS_ICARE.name()) ||
                platformConfigurationList.contains(Platform.WEB_IPOS.name())) {
            platformList.add("IPOS");
        }
        if (platformConfigurationList.contains(Platform.WEB_IPOS_ICARE.name()) ||
                platformConfigurationList.contains(Platform.WEB_ICARE.name())) {
            platformList.add("ICARE");
        }
        result.setPlatformList(platformList);
        result.setHasOtherToken("0");
        result.setRegisteredAgent("1");
        result.setToken(tokenValue);
        result.setAgentCode(agent.getAgentCode());
        result.setPortraitUrl(agent.getPortraitUrl());
        result.setAgentName(agent.getAgentName());
        result.setAgencyCode(agent.getAgencyCode());
        result.setAgencyName(agent.getAgencyName());
        result.setManagerName(agent.getReportTom());
        result.setLicenseType(agent.getLicenseType());
        result.setLicenseExpiryDate(agent.getLicenseExpDate());
        result.setContactNo(agent.getContactNo());
        result.setLicenseType(agent.getLicenseType());
        result.setCurrentVersion(null);
        result.setBuildId(null);
        result.setEmail(agent.getEmail());
        String agreeLicense = agent.getAgreeLicense();
        result.setAgreeLicense("1".equals(agreeLicense) ? "1" : "0");
        return new TokenGetResponse(result);
    }

    private boolean isTokenActive(AgentToken agentToken) {
        String accessToken = agentToken.getAccessToken();
        OAuth2AccessToken originalAccessToken =
                tokenStoreImpl.readOriginalAccessToken(accessToken);
        if (originalAccessToken == null) {
            return false;
        }
        return !originalAccessToken.isExpired();
    }

    private List<String> listPlatforms(String agentCode) {
        List<String> platFormList = new ArrayList<>();
        Optional<AgentPlatform> agentPlatformOpt = agentPlatformRepository.findById(agentCode);
        if (!agentPlatformOpt.isPresent()) {
            platFormList.add(Platform.WEB_IPOS.name());
            platFormList.add(Platform.WEB_ICARE.name());
        } else {
            AgentPlatform agentPlatform = agentPlatformOpt.get();
            Platform platform = agentPlatform.getPlatform();
            if (Platform.WEB_IPOS_ICARE.equals(platform)) {
                platFormList.add(Platform.WEB_IPOS.name());
                platFormList.add(Platform.WEB_ICARE.name());
            } else {
                platFormList.add(platform.name());
            }
        }
        return platFormList;
    }

    private JSONObject requestOAuthToken(String agentCode, String password, int localPort, String contextPath) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("grant_type", "password");
        params.add("username", agentCode);
        params.add("password", password);
        final String baseUrl = "http://localhost:" + localPort + contextPath + "/oauth/token";
        URI uri;
        try {
            uri = new URI(baseUrl);
        } catch (URISyntaxException e) {
            log.error("ERROR oAuth URL: ", e);
            return JSONObject.parseObject("{\"error\":\"error_oauth_url\"}");
        }
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/x-www-form-urlencoded");
        String plainCertificate = "ipos-web-client:ipos-web-secret";
        byte[] base64CertificateBytes = Base64.encodeBase64(plainCertificate.getBytes());
        String base64Certificate = new String(base64CertificateBytes);
        headers.add("Authorization", "Basic " + base64Certificate);
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<MultiValueMap<String, String>>(params, headers);
        String response;
        try {
            response = getRestTemplate().postForEntity(uri, httpEntity, String.class).getBody();
            return JSONObject.parseObject(response);
        }catch (HttpClientErrorException e) {
            response = e.getResponseBodyAsString();
            return JSONObject.parseObject(response, Feature.IgnoreAutoType);
        } catch (Exception e) {
            return JSONObject.parseObject("{\"message\":\"unauthorized\"}");
        }
    }

    private void recordAgentToken(String agentCode, String tokenValue) {
        log.info("recordAgentToken() start, tokenValue={}", tokenValue);
        AgentToken agentToken = agentTokenRepository.findByAccessToken(tokenValue);
        if (agentToken == null) {
            log.info("new agentToken..");
            agentToken = new AgentToken();
            agentToken.setAgentCode(agentCode);
        }
        agentToken.setAccessToken(tokenValue);
        agentTokenRepository.save(agentToken);
        log.info("recordAgentToken() done, tokenValue={}", tokenValue);
    }



    @Override
    @Transactional
    public TokenDisableResponse disableToken(String accessToken) {
        doDisableToken(accessToken);
        return new TokenDisableResponse(ErrorCode.SUCCESSFUL);
    }

    private void doDisableToken(String  accessToken) {
        log.info("doDisableToken({})..", accessToken);
        OAuth2AccessToken oAuth2AccessToken = tokenStoreImpl.readOriginalAccessToken(accessToken);
        if (oAuth2AccessToken != null) {
            log.info("removeAccessToken from tokenStore");
            tokenStoreImpl.removeAccessToken(oAuth2AccessToken);
        }

        log.info("find agentToken ..");
        List<AgentToken> agentTokens = agentTokenRepository.findAllByAccessToken(accessToken);
        if (agentTokens != null) {
            for (AgentToken agentToken : agentTokens) {
                agentToken.setDisabledAt(new Date());
            }
        }
        agentTokenRepository.saveAll(agentTokens);
        log.info("doDisableToken({}) done", accessToken);
    }

    protected RestTemplate getRestTemplate() {
        return restTemplateBuilder.build();
    }
}
