package com.aia.sqs.common.constant.contact;

/**
 * ADDRESS_TYPE_CODE
 */
public enum AddressType {

    RESIDENTIAL("1101"),OFFICE("1102"),BENEFICIARY("1103");

    private final String addressTypeCode;

    AddressType(String addressTypeCode) {
        this.addressTypeCode = addressTypeCode;
    }

    public String getAddressTypeCode() {
        return addressTypeCode;
    }

    public static AddressType valueOfCode(String addressTypeCode) {
        for (AddressType value : values()) {
            if (value.addressTypeCode.equals(addressTypeCode)) {
                return value;
            }
        }
        return null;
    }
}
