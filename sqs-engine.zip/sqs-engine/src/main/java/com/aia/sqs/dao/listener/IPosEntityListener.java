package com.aia.sqs.dao.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.aspectj.ConfigurableObject;
import org.springframework.stereotype.Component;

import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

@Component
public class IPosEntityListener implements ConfigurableObject {

    private static EntityMonitor[] entityMonitors;

    private static final Logger logger = LoggerFactory.getLogger(IPosEntityListener.class);

    @PrePersist
    public void prePersist(Object object) {
        if (methodMultipleInStack("prePersist")) {
            logger.info("prePersist multiple in stack.");
            return;
        }
        try {
            if (entityMonitors == null) {
                logger.warn("no entityMonitors found!");
                return;
            }
            for (EntityMonitor it : entityMonitors) {
                it.prePersisted(object);
            }
        } catch (Throwable t) {
            logger.error("Error when prePersist", t);
        }
    }

    @PreUpdate
    public void preUpdate(Object object) {
        if (methodMultipleInStack("preUpdate")) {
            logger.info("preUpdate multiple in stack.");
            return;
        }
        try {
            if (entityMonitors == null) {
                logger.warn("no entityMonitors found!");
                return;
            }
            for (EntityMonitor it : entityMonitors) {
                it.preUpdated(object);
            }
        } catch (Throwable t) {
            logger.error("Error when preUpdate", t);
        }

    }

    @PreRemove
    public void preRemove(Object object) {
        if (methodMultipleInStack("preRemove")) {
            logger.info("preUpdate multiple in stack.");
            return;
        }
        try {
            if (entityMonitors == null) {
                logger.warn("no entityMonitors found!");
                return;
            }
            for (EntityMonitor it : entityMonitors) {
                it.preRemoved(object);
            }
        } catch (Throwable t) {
            logger.error("Error when preUpdate", t);
        }
    }

    private boolean methodMultipleInStack(String methodName) {
        int count = 0;
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        for (StackTraceElement element : stackTrace) {
            if (IPosEntityListener.class.getName().equals(element.getClassName())
                    && methodName.equals(element.getMethodName())) {
                count ++;
                if (count > 1) {
                    return true;
                }
            }
        }
        return false;
    }

//    @Autowired
//    public void setEntityMonitors(EntityMonitor[] entityMonitors) {
//        this.entityMonitors = entityMonitors;
//    }
}
