package com.aia.sqs.common.constant;

public class CommonConstant {

    public static final String error_message_0 = "success";

    public static final String SIMPLE_DD_MM_YYYY_STRING= "dd/MM/yyyy";
    
    public static final String CFF_PRIORITY_RANK_ONE = "UNFULFILLED RETIREMENT";
    public static final String CFF_PRIORITY_RANK_TWO = "UNEXPECTED DEPARTURE";
    public static final String CFF_PRIORITY_RANK_THREE = "CHILDREN'S FUTURE";
    public static final String CFF_PRIORITY_RANK_FOUR = "WEALTH ACCUMULATION";
    public static final String CFF_PRIORITY_RANK_FIVE = "PHYSICALLY DISABLED";
    
    public static final String FIXED_ASSETS_NAME = "fixedAssets";
    public static final String SAVING_AND_INVERSTMENT_NAME = "savings";
    public static final String OTHER_PROVIDENT_FUNDS_NAME = "otherFunds";
    public static final String OTHERS_NAME = "others";
   
    public static final String LOANS_NAME = "loans";
    public static final String LOANS_OTHERS_NAME = "others";
    
    public static final String EMPLOYMENT_INCOME_NAME = "employment";
    public static final String BUSINESS_INCOME_NAME = "business";
    public static final String RENTAL_OR_INVESTMENT_INCOME_NAME = "rental";
    public static final String MOTHLY_EXPENSES_OTHERS_NAME = "others";
    
    public static final String LOAN_REPAYMENT_NAME = "loan";
    public static final String HOUSEHOLD_EXPENSES_NAME = "household";
    public static final String PARENTAL_SUPPORT_NAME = "parental";
    public static final String REGULAR_SAVINGS_NAME = "regular";
    public static final String INSURANCE_PREMIUM_NAME = "insurance";
    public static final String EXPENSES_OTHERS_NAME = "others";
    
    public String readOnly = "0";


    public String getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(String readOnly) {
        this.readOnly = readOnly;
    }



}
