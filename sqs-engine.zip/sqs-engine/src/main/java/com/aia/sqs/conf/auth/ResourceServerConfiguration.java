package com.aia.sqs.conf.auth;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.authentication.BearerTokenExtractor;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.cors.CorsConfiguration;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableResourceServer
@Slf4j
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
	@Autowired
    TokenStore tokenStore;
    private static final String[] MATCHERS = {
    		"/api/v1/template/**",
    		"/hello/**"
    };

    private static final String[] IGNORE_URLS = {
           "/api/v1/token",
           "/oauth/token"
    };

    @Override
    public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
    	 //这里把自定义异常加进去
    	resources.tokenStore(tokenStore).authenticationEntryPoint(new AuthExceptionEntryPoint());
        resources.tokenExtractor(new BearerTokenExtractor() {
            protected String extractToken(HttpServletRequest request) {
                String token = this.extractHeaderToken(request);
                if (token == null) {
                    boolean ignore = false;
                    String requestURI = request.getRequestURI();
                    for (String ignoreUrl : IGNORE_URLS) {
                        if (StringUtils.startsWithIgnoreCase(requestURI, ignoreUrl)) {
                            ignore = true;
                            break;
                        }
                    }
                    if (!ignore) {
                        token = request.getHeader("token");

                        if (StringUtils.isEmpty(token))
                        {
                            token = request.getParameter("token");
                        }

                        if (token == null) {
                            log.info("Token not found in request parameters.  Not an OAuth2 request.");
                        } else {
                            request.setAttribute(OAuth2AuthenticationDetails.ACCESS_TOKEN_TYPE, "Bearer");
                        }
                    }
                }
                return token;
            }
        });
        super.configure(resources);
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http.anonymous().disable();

//        http.authorizeRequests()
//                .antMatchers("/api/agent/token/**")
//                .permitAll();

        http.authorizeRequests()
                .antMatchers(MATCHERS)
                .authenticated(); // Specify URLs are allowed by any authenticated user.

        http.authorizeRequests().antMatchers(MATCHERS)
                .access("hasRole('AGENT')");

//        http.exceptionHandling().accessDeniedHandler(new OAuth2AccessDeniedHandler());

        http.cors().configurationSource(request -> {
            CorsConfiguration corsConfiguration = new CorsConfiguration();
            corsConfiguration.addAllowedOrigin("*");
            corsConfiguration.setAllowCredentials(true);
            return corsConfiguration
                    .applyPermitDefaultValues();
        });
    }

}