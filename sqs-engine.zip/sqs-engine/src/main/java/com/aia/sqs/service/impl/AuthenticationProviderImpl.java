package com.aia.sqs.service.impl;

import com.aia.sqs.service.PortalLoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
@Slf4j
public class AuthenticationProviderImpl implements AuthenticationProvider {

    @Autowired
    private PortalLoginService portalLoginService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        Object credentials = authentication.getCredentials();
        String password = credentials.toString();

        log.info("AuthenticationProviderImpl.authenticate()..{}--{}",username,password); //77771--12345678

        String failedMessage = portalLoginService.authenticate(username, password);
        if (null != failedMessage) {
            throw new BadCredentialsException(failedMessage);
        }

        return new UsernamePasswordAuthenticationToken(
        		username,
                password,
                Arrays.asList(
                        new SimpleGrantedAuthority("ROLE_AGENT")));
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return aClass.equals(UsernamePasswordAuthenticationToken.class);
    }
}
