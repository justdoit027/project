package com.aia.sqs.common.exception;

public class BusinessException extends RuntimeException {

    public static final BusinessException INVALID_TOKEN = new BusinessException("invalid_token");
    public static final BusinessException INVALID_TOKEN_AUDITOR = new BusinessException("invalid_token_auditor");
    public static final BusinessException UNAUTHORIZED = new BusinessException("unauthorized");

    public static final BusinessException CALCULATE_RESULT_NULL = new BusinessException("calculate_return_data_null");

    public static final BusinessException AGENT_CODE_EMPTY = new BusinessException("agent_code_empty");
    public static final BusinessException AGENT_NOT_FOUND = new BusinessException("agent_not_found");
    public static final BusinessException AGENT_ID_NO_EMPTY = new BusinessException("agent_id_no_empty");
    public static final BusinessException AGENT_NO_LICENSE = new BusinessException("agent_no_license");

    public static final BusinessException CONTACT_ID_EMPTY = new BusinessException("contact_id_empty");
    public static final BusinessException CONTACT_NOT_FOUND = new BusinessException("contact_not_found");
    public static final BusinessException CONTACT_ID_ERROR = new BusinessException("contact_id_not found");
    public static final BusinessException CFF_NOT_FOUND = new BusinessException("cff_not_found");

    public static final BusinessException SPOUSE_ID_INCORRECT = new BusinessException("spouse_id_incorrect");

    public static final BusinessException BENEFICIARY_ID_EMPTY = new BusinessException("beneficiary_id_empty");
    public static final BusinessException BENEFICIARY_NOT_FOUND = new BusinessException("beneficiary_not_found");
    public static final BusinessException BENEFICIARY_CONTACT_NOT_FOUND = new BusinessException("beneficiary_contact_not_found");

    public static final BusinessException CHILDREN_OR_DEPENDENT_NOT_FOUND = new BusinessException("children_or_dependent_not_found");
    public static final BusinessException CHILDREN_OR_DEPENDENT_CONTACT_NOT_FOUND = new BusinessException("children_or_dependent_contact_not_found");

    public static final BusinessException OTHER_INSURANCE_ID_EMPTY = new BusinessException("other_insurance_id_empty");
    public static final BusinessException OTHER_INSURANCE_NOT_FOUND = new BusinessException("other_insurance_not_found");
    public static final BusinessException PAYOR_AGE_IS_NULL = new BusinessException("payor_age_is_null");
    public static final BusinessException INSURED_AGE_IS_NULL = new BusinessException("insured_age_is_null");

    public static final BusinessException OTHER_DEPENDENT_NOT_FOUND = new BusinessException("other_dependent_not_found");
    public static final BusinessException OTHER_DEPENDENT_CONTACT_NOT_FOUND = new BusinessException("other_dependent_contact_not_found");

    public static final BusinessException APPLICATION_ID_EMPTY = new BusinessException("application_id_empty");
    public static final BusinessException APPLICATION_NOT_FOUND = new BusinessException("application_not_found");
    public static final BusinessException CONTACT_APPLICATION_ID_EMPTY = new BusinessException("contact_application_id_empty");

    public static final BusinessException OWNER_ID_NOT_FOUND = new BusinessException("owner_id_not_found");
    public static final BusinessException OWNER_NOT_FOUND = new BusinessException("owner_not_found");
    public static final BusinessException INSURED_ID_NOT_FOUND = new BusinessException("insured_id_not_found");
    public static final BusinessException INSURED_NOT_FOUND = new BusinessException("insured_not_found");

    public static final BusinessException QUOTATION_ID_EMPTY = new BusinessException("quotation_id_empty");
    public static final BusinessException QUOTATION_NOT_FOUND = new BusinessException("quotation_not_found");
    public static final BusinessException E_CASE_NOT_FOUND = new BusinessException("e_case_not_found");
    public static final BusinessException QUOTATION_DELETE_NOT_DRAFT = new BusinessException("quotation_delete_not_draft");

    public static final BusinessException PLAN_NOT_FOUND = new BusinessException("plan_not_found");

    public static final BusinessException INSURED_AGE_LESS_THEN_16 = new BusinessException("insured_age_less_then_16");

    public static final BusinessException BASICPLANSELECTION_NOT_FOUND = new BusinessException("BasicSelection_not_found");

    public static final BusinessException E_APP_NOT_FOUND = new BusinessException("e_app_not_found");

    public static final BusinessException HEALTH_QUESTIONS_ITEM_ERROR = new BusinessException("health_questions_item_error");

    public static final BusinessException E_SUBMIT_INCORRECT_RESPONSE = new BusinessException("e_submit_incorrect_response");

    public static final BusinessException  Call_SQS_server= new BusinessException("Failed to call the SQS service, please try again later.");


    public BusinessException() {
    }

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(Throwable cause) {
        super(cause);
    }

    public BusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
