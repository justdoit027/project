package com.aia.sqs.service.impl;


import com.aia.sqs.common.constant.DataSourceConstant;
import com.aia.sqs.aop.support.DataSource;
import com.aia.sqs.dao.entity.TWebserviceConfig;
import com.aia.sqs.dao.repository.WebServiceConfigRepository;
import com.aia.sqs.service.WebServiceConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WebServiceConfigServiceImpl implements WebServiceConfigService {

    @Autowired
    private WebServiceConfigRepository webServiceConfigRepository;


    @DataSource("ipos")
    @Override
    public List<TWebserviceConfig> finaAll() {
        return webServiceConfigRepository.findAll();
    }

    @DataSource("ipos")
    @Override
    public TWebserviceConfig findById(String contactId) {
        return webServiceConfigRepository.findById(contactId).get();
    }

    @DataSource("ipos")
    @Override
    public void delete(String contactId) {
        webServiceConfigRepository.deleteById(contactId);
    }

    @DataSource("ipos")
    @Override
    public void save(TWebserviceConfig contact) {
        webServiceConfigRepository.save(contact);
    }
}
