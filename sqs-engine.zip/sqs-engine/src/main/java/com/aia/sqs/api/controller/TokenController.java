package com.aia.sqs.api.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.api.model.TokenGet;
import com.aia.sqs.service.TokenService;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class TokenController {
	@Autowired
	private TokenService tokenService;
	@RequestMapping(value = "/api/v1/token", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> agentTokenGet(@RequestBody TokenGet body,HttpServletRequest request) {
		int localPort = request.getLocalPort();
		String contextPath = request.getContextPath();
		OutputVO response = tokenService.getToken(body, localPort, contextPath);
		return new ResponseEntity<>(response.toMap(), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/token", produces = { "application/json" }, method = RequestMethod.DELETE)
	public ResponseEntity<Map<String, Object>> destoryToken(@RequestHeader(value = "token") String token) {
		OutputVO response = tokenService.destoryToken(token);
		return new ResponseEntity<>(response.toMap(), HttpStatus.OK);
	}
	 
	 
}
