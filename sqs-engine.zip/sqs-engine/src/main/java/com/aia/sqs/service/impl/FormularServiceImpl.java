package com.aia.sqs.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.Formular;
import com.aia.sqs.dao.repository.FormularRepository;
import com.aia.sqs.service.FormularService;
@Service
public class FormularServiceImpl implements FormularService{
	@Autowired 
	private FormularRepository formularRepository;
	@Override
	public OutputVO delete(String formularId) {
		OutputVO outputVO = new OutputVO();
		try {
			formularRepository.deleteById(formularId);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
	public OutputVO getOne(String formularId) {
		OutputVO outputVO = new OutputVO();
		try {
			Formular formular = formularRepository.findById(formularId).get();
			outputVO.setData(formular);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(Formular formular) {
		OutputVO outputVO = new OutputVO();
		try {
			Formular source = formularRepository.findById(formular.getId()).get();
			UpdateTool.copyNullProperties(source, formular);
			formularRepository.saveAndFlush(formular);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO add(Formular formular) {
		OutputVO outputVO = new OutputVO();
		try {
			formularRepository.saveAndFlush(formular);
		
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	

	@Override
	public OutputVO findAll(String productId) {
		OutputVO outputVO = new OutputVO();
		try {
			 List<Formular> planList = formularRepository.findAllByProductId(productId);
			
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}

	

}
