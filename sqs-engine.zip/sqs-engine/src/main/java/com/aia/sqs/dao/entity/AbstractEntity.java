package com.aia.sqs.dao.entity;

import com.aia.sqs.dao.listener.IPosEntityListener;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@MappedSuperclass
@EntityListeners({AuditingEntityListener.class, IPosEntityListener.class})
public abstract class AbstractEntity <ID> {
    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    protected Date createDate;
    
    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    protected Date lastUpdateDate;
    
    @CreatedBy
    protected String createBy;
    
    @LastModifiedBy
    protected String updateBy;

    @Version
    @Column(columnDefinition = "bigint not null default 0")
    protected Long version = 0L;


    @Transient
    abstract public ID getId();

}
