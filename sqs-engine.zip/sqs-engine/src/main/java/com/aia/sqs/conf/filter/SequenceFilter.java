package com.aia.sqs.conf.filter;


import com.aia.sqs.api.model.FailedResponse;
import com.aia.sqs.service.SequenceService;
import com.alibaba.fastjson.JSON;

import cn.hutool.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

//@Component
//@Order(1)  // TODO disabled for debug only
@Slf4j
public class SequenceFilter implements Filter {

    @Autowired
    private SequenceService sequenceService;

    @Override
    public void init(FilterConfig filterConfig) {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse hresponse = (HttpServletResponse) response;
		/*
		 * hresponse.setHeader("Access-Control-Allow-Origin", "*");
		 * hresponse.setHeader("Access-Control-Allow-Methods",
		 * "POST, GET, OPTIONS, DELETE"); hresponse.setHeader("Access-Control-Max-Age",
		 * "3600"); hresponse.setHeader("Access-Control-Allow-Headers",
		 * "content-type,x-requested-with,Authorization, x-ui-request,lang");
		 * hresponse.setHeader("Access-Control-Allow-Credentials", "true"); if
		 * (req.getMethod().equals("OPTIONS")) {
		 * hresponse.setStatus(HttpStatus.HTTP_OK);
		 * hresponse.getWriter().write("OPTIONS returns OK"); return; }
		 */
        String token = req.getHeader("token");
        if (StringUtils.isEmpty(token)) {
           chain.doFilter(request, response);
           return;
        }
        String timestamp = req.getHeader("timestamp");
        if (!NumberUtils.isDigits(timestamp)) {
            log.warn("missing the timestamp with token {} ", token);
            responseFailed(response, "Missing timestamp");
            return;
        }
        long sequence = NumberUtils.toLong(timestamp);
        if (sequenceService.isDuplicated(token, sequence)) {
            log.warn("duplicated request with token {} and timestamp {}", token, timestamp);
            responseFailed(response, "Duplicated timestamp");
            return;
        }
        chain.doFilter(request, response);
    }

    private void responseFailed(ServletResponse response, String failedMessage) throws IOException {
        response.setContentType("application/json");
        String json = JSON.toJSONString(new FailedResponse(failedMessage));
        response.getWriter().write(json);
    }

    @Override
    public void destroy() {

    }
}
