package com.aia.sqs.dao.support;

import com.aia.sqs.common.constant.contact.IsContacts;

import javax.persistence.AttributeConverter;

public class IsContactAttributeConverter implements AttributeConverter<IsContacts,String> {


    @Override
    public String convertToDatabaseColumn(IsContacts attribute) {
        if(attribute == null){
            return null;
        }
        return attribute.getCode();
    }

    @Override
    public IsContacts convertToEntityAttribute(String dbData) {

        if(dbData == null){
            return null;
        }

        return dbData.equals(IsContacts.PAYOR.getCode()) ? IsContacts.PAYOR:IsContacts.INSURED;
    }
}
