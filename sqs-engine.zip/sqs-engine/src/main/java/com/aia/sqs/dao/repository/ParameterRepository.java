package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.Parameter;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface ParameterRepository extends JpaRepository<Parameter, String>, CrudRepository<Parameter, String>, JpaSpecificationExecutor {
	List<Parameter> findAllByProductId(String productId);
	
}
