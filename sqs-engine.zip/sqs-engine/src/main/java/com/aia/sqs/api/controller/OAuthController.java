package com.aia.sqs.api.controller;


import com.aia.sqs.aop.support.StopWatch;
import com.aia.sqs.dao.entity.TWebserviceConfig;
import com.aia.sqs.service.PortalLoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(allowCredentials = "true")
@Slf4j
public class OAuthController {

    @Autowired
    private PortalLoginService portalLoginService;

    @RequestMapping(value = "/api/oauth/hello",method = {RequestMethod.GET})
    public String hello()
    {
        return "Hello First";
    }


    @RequestMapping(value = "/api/oauth/hello2",method = {RequestMethod.GET})
    public String hello2()
    {
        return "Hello Second";
    }


    @StopWatch
    @RequestMapping(value = "/api/oauth/account/save/{id}",method = {RequestMethod.GET})
    public ResponseEntity<String> saveAccount(@PathVariable(name="id") String id)
    {
        portalLoginService.saveAccount(id);
        return ResponseEntity.ok("save successfully");
    }

    @RequestMapping(value = "/api/oauth/account/update/{id}/{pwd}",method = {RequestMethod.GET})
    public ResponseEntity<String> updateAccount(@PathVariable(name="id") String id,@PathVariable(name="pwd") String pwd)
    {
        portalLoginService.saveAccount(id);
        return ResponseEntity.ok("save successfully");
    }

}
