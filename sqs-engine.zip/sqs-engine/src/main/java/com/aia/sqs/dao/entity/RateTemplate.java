package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_rates_template")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RateTemplate extends BaseEntity{

    @Column(name="name")
    private String name;

    @Column(name="table_name")
    private String tableName;

    @Column(name="r_condition")
    private String condition;

    @Column(name="description")
    private String description;
    
    @Column(name="plan_template_id")
    private String planTemplateId;
    

}
