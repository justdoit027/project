package com.aia.sqs.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.FormularTemplate;
import com.aia.sqs.dao.entity.ParameterTemplate;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.aia.sqs.dao.entity.RateTemplate;
import com.aia.sqs.service.FormularTemplateService;
import com.aia.sqs.service.ParameterTemplateService;
import com.aia.sqs.service.PlanTemplateService;
import com.aia.sqs.service.RateTemplateService;
import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin(
        origins = "*",
        allowedHeaders = "*",
        allowCredentials = "true",
        exposedHeaders= {"access-control-allow-headers", 
        		"access-control-allow-methods", 
        		"access-control-allow-origin", 
        		"access-control-max-age", "X-Frame-Options"},
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS, RequestMethod.HEAD}
)
@Slf4j
public class TemplateController {
	@Autowired
	private PlanTemplateService planTemplateService;
	@Autowired
	private FormularTemplateService formularTemplateService;
	@Autowired
	private ParameterTemplateService parameterTemplateService;
	@Autowired
	private RateTemplateService rateTemplateService;

	@RequestMapping(value = "/api/v1/template/plan/{planTemplateId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deletePlanTemlate(@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(planTemplateService.delete(planTemplateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/plan/{planTemplateId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> getOnePlanTemlate(@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(planTemplateService.getOne(planTemplateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/plan", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addPlanTemlate(@RequestBody(required = false) PlanTemplate planTemplate) {
		return new ResponseEntity<>(planTemplateService.add(planTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/plan/{planTemplateId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updatePlanTemlate(@PathVariable(name = "planTemplateId") String planTemplateId,
			@RequestBody(required = false) PlanTemplate planTemplate) {
		planTemplate.setId(planTemplateId);
		return new ResponseEntity<>(planTemplateService.update(planTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/clone/{planTemplateId}", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> clonePlanTemlate(@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(planTemplateService.clone(planTemplateId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/plan/list", produces = { "application/json" }, method = { RequestMethod.POST })
	public ResponseEntity<OutputVO> queryPlanTemlateList(@RequestBody(required = false) JSONObject json) {
		return new ResponseEntity<>(planTemplateService.findAll(json), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleteFormularTemlate(@PathVariable(name = "formularId") String formularId) {
		return new ResponseEntity<>(formularTemplateService.delete(formularId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updateFormularTemlate(@PathVariable(name = "formularId") String formularId,
			@RequestBody(required = false) FormularTemplate formularTemplate) {
		formularTemplate.setId(formularId);
		return new ResponseEntity<>(formularTemplateService.update(formularTemplate), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/formular/{formularId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryFormularTemlateById(@PathVariable(name = "formularId") String formularId) {
		return new ResponseEntity<>(formularTemplateService.queryById(formularId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/formular", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addFormularTemlate(@PathVariable(name = "planTemplateId") String planTemplateId,
			@RequestBody(required = false) FormularTemplate formularTemplate) {
		formularTemplate.setPlanTemplateId(planTemplateId);
		return new ResponseEntity<>(formularTemplateService.add(formularTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/formular", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryFormularTemlateList(
			@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(formularTemplateService.findAll(planTemplateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleterateTemlate(@PathVariable(name = "rateId") String rateId) {
		return new ResponseEntity<>(rateTemplateService.delete(rateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryRateTemlateById(@PathVariable(name = "rateId") String rateId) {
		return new ResponseEntity<>(rateTemplateService.queryById(rateId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/rates/{rateId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updaterateTemlate(@PathVariable(name = "rateId") String rateId,
			@RequestBody(required = false) RateTemplate rateTemplate) {
		rateTemplate.setId(rateId);
		return new ResponseEntity<>(rateTemplateService.update(rateTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/rates", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addrateTemlate(@PathVariable(name = "planTemplateId") String planTemplateId,
			@RequestBody(required = false) RateTemplate rateTemplate) {
		rateTemplate.setPlanTemplateId(planTemplateId);
		return new ResponseEntity<>(rateTemplateService.add(rateTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/rates", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryrateTemlateList(
			@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(rateTemplateService.findAll(planTemplateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.DELETE })
	public ResponseEntity<OutputVO> deleteparameterTemlate(@PathVariable(name = "parameterId") String parameterId) {
		return new ResponseEntity<>(parameterTemplateService.delete(parameterId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryParameterTemlate(@PathVariable(name = "parameterId") String parameterId) {
		return new ResponseEntity<>(parameterTemplateService.queryById(parameterId), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/parameter/{parameterId}", produces = { "application/json" }, method = {
			RequestMethod.PUT })
	public ResponseEntity<OutputVO> updateparameterTemlate(@PathVariable(name = "parameterId") String parameterId,
			@RequestBody(required = false) ParameterTemplate parameterTemplate) {
		parameterTemplate.setId(parameterId);
		return new ResponseEntity<>(parameterTemplateService.update(parameterTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/parameter", produces = { "application/json" }, method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> addparameterTemlate(@PathVariable(name = "planTemplateId") String planTemplateId,
			@RequestBody(required = false) ParameterTemplate parameterTemplate) {
		parameterTemplate.setPlanTemplateId(planTemplateId);
		return new ResponseEntity<>(parameterTemplateService.add(parameterTemplate), HttpStatus.OK);
	}

	@RequestMapping(value = "/api/v1/template/{planTemplateId}/parameter", produces = { "application/json" }, method = {
			RequestMethod.GET })
	public ResponseEntity<OutputVO> queryparameterTemlateList(
			@PathVariable(name = "planTemplateId") String planTemplateId) {
		return new ResponseEntity<>(parameterTemplateService.findAll(planTemplateId), HttpStatus.OK);
	}
	@RequestMapping(value = "/api/v1/template/rates/{tableName}/upload", method = {
			RequestMethod.POST })
	public ResponseEntity<OutputVO> uploadRateExcel(
			@RequestParam("file") MultipartFile file,@PathVariable(name = "tableName") String tableName) {
		return new ResponseEntity<>(rateTemplateService.excelToDb(file,tableName), HttpStatus.OK);
	}
}
