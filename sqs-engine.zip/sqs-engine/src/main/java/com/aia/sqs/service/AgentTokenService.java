package com.aia.sqs.service;

import com.aia.sqs.api.model.TokenDisableResponse;
import com.aia.sqs.api.model.TokenGetRequest;
import com.aia.sqs.api.model.TokenGetResponse;

public interface AgentTokenService {

    TokenGetResponse getToken(TokenGetRequest request, int localPort, String contextPath);

    TokenDisableResponse disableToken(String token);
}
