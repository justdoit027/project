package com.aia.sqs.service;

import com.aia.sqs.dao.entity.Contact;

import javax.transaction.Transactional;
import java.util.List;

public interface ContactService {


    List<Contact> finaAll();

    Contact findById(String contactId);

    @Transactional
    void delete(String contactId);

    @Transactional
    void save(Contact contact);

}
