package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_parameter")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Parameter extends BaseEntity{

    @Column(name="parameter_key")
    private String parameterKey;

    @Column(name="parameter_name")
    private String parameterName;


    @Column(name="description")
    private String description;
    
    @Column(name="plan_id")
    private String planId;
    
    @Column(name="product_id")
    private String productId;
    
  
   

}
