package com.aia.sqs.service.impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.Parameter;
import com.aia.sqs.dao.repository.ParameterRepository;
import com.aia.sqs.service.ParameterService;
@Service
public class ParameterServiceImpl implements ParameterService{
	@Autowired 
	private ParameterRepository parameterRepository;
	@Override
	public OutputVO delete(String parameterId) {
		OutputVO outputVO = new OutputVO();
		try {
			parameterRepository.deleteById(parameterId);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}
	@Override
	public OutputVO getOne(String parameterId) {
		OutputVO outputVO = new OutputVO();
		try {
			Parameter parameter = parameterRepository.findById(parameterId).get();
			outputVO.setData(parameter);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(Parameter parameter) {
		OutputVO outputVO = new OutputVO();
		try {
			Parameter source = parameterRepository.findById(parameter.getId()).get();
			UpdateTool.copyNullProperties(source, parameter);
			parameterRepository.saveAndFlush(parameter);
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO add(Parameter parameter) {
		OutputVO outputVO = new OutputVO();
		try {
			parameterRepository.saveAndFlush(parameter);
		
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	

	@Override
	public OutputVO findAll(String productId) {
		OutputVO outputVO = new OutputVO();
		try {
			 List<Parameter> planList = parameterRepository.findAllByProductId(productId);
			
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}

	
	

}
