package com.aia.sqs.service;


import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.Rate;

public interface RateService {
	OutputVO delete(String RateId);
	OutputVO getOne(String RateId);
	OutputVO update(Rate rate);
	OutputVO add(Rate rate);
	OutputVO findAll(String planId);
}
