package com.aia.sqs.service;

import java.util.List;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.dao.entity.Product;
import com.alibaba.fastjson.JSONObject;

public interface ProductService {
OutputVO ralease(String productId);
OutputVO getOne(String productId);
OutputVO findPlanList(String productId);
OutputVO add(List<String> productIds);
OutputVO clone(String ProductId);
OutputVO findAll(JSONObject json);
}
