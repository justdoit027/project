package com.aia.sqs.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenGet {
  private String grant_type;
  private String username;
  private String password;
}

