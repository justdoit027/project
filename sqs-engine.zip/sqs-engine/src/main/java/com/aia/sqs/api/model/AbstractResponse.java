package com.aia.sqs.api.model;

import com.aia.sqs.common.constant.ErrorCode;

public abstract class AbstractResponse {

    protected final short errorCode;

    protected String errorMessage;

    public AbstractResponse(ErrorCode errorCode) {
        this(errorCode, null);
    }

    public AbstractResponse(ErrorCode errorCode, String errorMessage) {
        this.errorCode = errorCode.getCode();
        this.errorMessage = errorMessage;
    }

    public short getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
