package com.aia.sqs.service;

import com.aia.sqs.dao.entity.SysUser;

public interface SysUserService {

    SysUser findByUserName(String username);

    SysUser authenticate(String username,String password);

}
