package com.aia.sqs.common.constant;

public enum ErrorCode {

    SUCCESSFUL((short) 0),
    FAILED((short) 1),

    BENEFICIARIES_EXISTED((short)101),
    GENERATE_EXCEPTION((short)102),
    AGENT_LICENSE_FAILED((short)103),
    AGENT_NOT_EXISTED((short)104),
    AGENT_LOCKED((short) 105),
    AGENT_PASSWORD_WRONG((short)106),
    PLATFORM_WRONG((short)107),
    NOT_AG_CHANNEL((short)108),
    AGENT_ID_NO_WRONG((short) 109);

    private short code;

    ErrorCode(short code) {
        this.code = code;
    }

    public short getCode() {
        return code;
    }
}
