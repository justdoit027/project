package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.AgentToken;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;

import javax.persistence.LockModeType;
import java.util.List;

public interface AgentTokenRepository extends SqsRepository<AgentToken, String>, JpaSpecificationExecutor {
    @Lock(LockModeType.OPTIMISTIC)
    AgentToken findByAccessToken(String accessToken);

    @Lock(LockModeType.OPTIMISTIC)
    List<AgentToken> findAllByAccessToken(String accessToken);

    @Lock(LockModeType.OPTIMISTIC)
    @Query("from AgentToken where disabledAt is null and agentCode=?1 and accessToken!=?2")
    List<AgentToken> findAllByDisabledAtIsNullAndAgentCodeEqualsAndAccessTokenNot(
            String agentCode, String excludedToken);

    @Lock(LockModeType.OPTIMISTIC)
    @Query("from AgentToken where disabledAt is null and agentCode=?1")
    List<AgentToken> findAllByDisabledAtIsNullAndAgentCodeEquals(String agentCode);
}
