package com.aia.sqs.common.util;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

@Slf4j
public class Encryption {

    public static byte[] unzip(byte[] zipData) {
        if (zipData == null)
            return null;

        ByteArrayInputStream in = new ByteArrayInputStream(zipData);
        ByteArrayOutputStream out = new ByteArrayOutputStream(zipData.length);
        ZipInputStream zis = new ZipInputStream(new BufferedInputStream(in));
        byte[] outData = null;
        try {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                log.info("Extracting: {}", entry);
                // write the files to the disk
                int count;
                int BUFFER = 1024;
                byte[] buffer = new byte[BUFFER];
                while ((count = zis.read(buffer, 0, BUFFER)) != -1) {
                    out.write(buffer, 0, count);
                }
                outData = out.toByteArray();
            }
        } catch (IOException ex) {
            log.error("Exception when unzip", ex);
        } finally {
            try {
                in.close();
            } catch (IOException ex) {
                log.error("Exception when unzip close in", ex);
            }
            try {
                zis.close();
            } catch (IOException ex) {
                log.error("Exception when unzip close zis", ex);
            }
            try {
                out.close();
            } catch (IOException ex) {
                log.error("Exception when unzip close out", ex);
            }
        }
        return outData;
    }

    public static byte[] zip(String filename, byte[] input)
    {
        if (input == null)
        {
            return null;
        }
        if (filename == null)
        {
            return null;
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        ZipEntry entry = new ZipEntry(filename);
        entry.setSize(input.length);

        try
        {
            zos.putNextEntry(entry);
            zos.write(input);
            zos.closeEntry();
            zos.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }

        return baos.toByteArray();
    }

    public static byte[] zipBytes(String filename, byte[] input){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        ZipEntry entry = new ZipEntry(filename);
        entry.setSize(input.length);
        try {
            zos.putNextEntry(entry);
            zos.write(input);
            zos.closeEntry();
            zos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return baos.toByteArray();
    }
//    public static byte[] zip(byte[] input) {
//        if (input == null) {
//            return null;
//        }
//
//        ByteArrayOutputStream baOut = new ByteArrayOutputStream();
//        ZipOutputStream zipOut = new ZipOutputStream(baOut);
//        ZipEntry entry = new ZipEntry(String.valueOf(System.currentTimeMillis()));
//        entry.setSize(input.length);
//
//        try {
//            zipOut.putNextEntry(entry);
//            zipOut.write(input);
//            byte[] result = baOut.toByteArray();
//            return result;
//        } catch (IOException ex) {
//            logger.error("Exception when unzip", ex);
//            return new byte[0];
//        } finally {
//            try {
//                baOut.close();
//            } catch (IOException e) {
//                logger.error("Exception when close baOut", e);
//            }
//            try {
//                zipOut.closeEntry();
//            } catch (IOException e) {
//                logger.error("Exception when close zipOutEntry", e);
//            }
//            try {
//                zipOut.close();
//            } catch (IOException e) {
//                logger.error("Exception when close zipOut", e);
//            }
//        }
//    }

}
