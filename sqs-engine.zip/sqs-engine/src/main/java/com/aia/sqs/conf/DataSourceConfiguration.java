//package com.aia.sqs.conf;
//
//import com.aia.sqs.common.constant.DataSourceConstant;
//import com.aia.sqs.common.mutildatasource.DynamicDataSource;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
//import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings;
//import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.boot.jdbc.DataSourceBuilder;
//import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.orm.jpa.JpaTransactionManager;
//import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
//import org.springframework.transaction.PlatformTransactionManager;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//import javax.persistence.EntityManager;
//import javax.sql.DataSource;
//import java.util.HashMap;
//import java.util.Map;
//
//@Configuration
//@EnableTransactionManagement(order = 2)
//@EnableJpaRepositories(basePackages= { "com.aia.sqs.dao.repository" })
//@Slf4j
//public class DataSourceConfiguration {
//
//    @Autowired
//    private HibernateProperties hibernateProperties;
//
//    @Autowired
//    private JpaProperties jpaProperties;
//
//    @Value("${muti-datasource-open}")
//    private Boolean mutiDatasourceFlag;
//
//    @Primary
//    @Bean(name = "dataSourceMaster")
//    @Qualifier("dataSourceMaster")
//    @ConfigurationProperties(prefix="spring.datasource.master" )
//    public DataSource dataSourceMaster()
//    {
//        return DataSourceBuilder.create().build();
//    }
//
//
//    @Bean(name="dataSourceCommon")
//    @Qualifier("dataSourceCommon")
//    @ConfigurationProperties(prefix="spring.datasource.common")
//    public DataSource dataSourceCommon()
//    {
//        return DataSourceBuilder.create().build();
//    }
//
//
//    /**
//     * 多数据源连接池配置
//     */
//    @Bean
//    public DynamicDataSource dynamicDataSource() {
//
//        DynamicDataSource dynamicDataSource = new DynamicDataSource();
//        Map<Object, Object> hashMap = new HashMap();
//
//        DataSource dataSourceMaster = dataSourceMaster();
//        hashMap.put(DataSourceConstant.DATASOURCE_DEFAULT, dataSourceMaster);
//
//        if (mutiDatasourceFlag)
//        {
//            DataSource dataSourceCommon = dataSourceCommon();
//            hashMap.put(DataSourceConstant.DATASOURCE_COMMON, dataSourceCommon);
//        }
//
//        dynamicDataSource.setTargetDataSources(hashMap);
//        dynamicDataSource.setDefaultTargetDataSource(dataSourceMaster);
//        return dynamicDataSource;
//    }
//
//    @Bean
//    public EntityManager entityManager(EntityManagerFactoryBuilder builder) {
//        return entityManagerFactory(builder).getObject().createEntityManager();
//    }
//
//    @Bean
//    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
//            EntityManagerFactoryBuilder builder) {
//        Map<String, Object> properties = hibernateProperties.determineHibernateProperties(
//                jpaProperties.getProperties(), new HibernateSettings());
//            return builder.dataSource(dynamicDataSource()).properties(properties)
//                    .packages("com.aia.sqs.dao.entity").build();
//    }
//
//    @Bean
//    public PlatformTransactionManager transactionManager(EntityManagerFactoryBuilder builder) {
//        return new JpaTransactionManager(entityManagerFactory(builder).getObject());
//    }
//
//}
