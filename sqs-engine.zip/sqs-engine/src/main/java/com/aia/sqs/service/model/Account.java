package com.aia.sqs.service.model;

import org.apache.commons.lang3.StringUtils;

public class Account {

    private final String agentCode;
    private final String startMillis;
    private final String idNo;

    private Account(String agentCode, String startMillis, String idNo) {
        this.agentCode = agentCode;
        this.startMillis = startMillis;
        this.idNo = idNo;
    }

    public String getUsername(){
        StringBuilder builder = new StringBuilder();
        builder.append(agentCode);
        if (StringUtils.isNotEmpty(startMillis)) {
            builder.append(" ").append(startMillis);
        }
        return builder.toString();
    }

    public String asString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getUsername());
        if (StringUtils.isNotEmpty(idNo)) {
            builder.append(",").append(idNo);
        }
        return builder.toString();
    }

    public String getAgentCode() {
        return agentCode;
    }

    public String getStartMillis() {
        return startMillis;
    }

    public String getIdNo() {
        return idNo;
    }

    public static Account generateAccount(String agentCode, String idNo) {
        String startMillis = String.valueOf(System.currentTimeMillis());
        return new Account(agentCode, startMillis, idNo);
    }

    public static Account fromString(String string){
        String[] accArray = string.split(",");
        String username = accArray[0];
        String idNo = null;
        if (accArray.length > 1) {
            idNo = accArray[1];
        }
        String[] usernameArray = username.split(" ");
        String agentCode = usernameArray[0];
        String startMillis = null;
        if (usernameArray.length > 1) {
            startMillis = usernameArray[1];
        }
        return new Account(agentCode, startMillis, idNo);
    }
}