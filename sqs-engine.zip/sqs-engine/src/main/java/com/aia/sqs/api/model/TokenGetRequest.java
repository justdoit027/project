package com.aia.sqs.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenGetRequest {
  private String userId = null;
  private String idNo = null;
  private String password = null;
  private String disableOtherToken;
}

