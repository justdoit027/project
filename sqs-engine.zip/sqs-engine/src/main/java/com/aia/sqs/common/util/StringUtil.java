package com.aia.sqs.common.util;

import java.util.UUID;

public class StringUtil {
	public static synchronized String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
}
