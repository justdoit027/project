package com.aia.sqs.dao.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="t_parameter_template")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParameterTemplate extends BaseEntity{

    @Column(name="parameter_key")
    private String parameterKey;

    @Column(name="parameter_name")
    private String parameterName;


    @Column(name="description")
    private String description;
    
    @Column(name="plan_template_id")
    private String planTemplateId;
    
  
    
  
   

}
