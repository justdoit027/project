package com.aia.sqs.service;

public interface SequenceService {
    boolean isDuplicated(String token, long sequence);
}
