package com.aia.sqs.api.controller;

import com.aia.sqs.api.model.TokenDisableRequest;
import com.aia.sqs.api.model.TokenDisableResponse;
import com.aia.sqs.api.model.TokenGetRequest;
import com.aia.sqs.api.model.TokenGetResponse;
import com.aia.sqs.service.AgentTokenService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@CrossOrigin(allowCredentials = "true")
@Slf4j
public class AgentApiController {

	@Autowired
	private AgentTokenService agentTokenService;

	@ApiOperation(value = "", nickname = "agentTokenGet", notes = "", response = TokenGetResponse.class, tags = {
			"agent", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation", response = TokenGetResponse.class) })
	@RequestMapping(value = "/api/agent/token/get", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<TokenGetResponse> agentTokenGet(
			@ApiParam(value = "", required = true) @Valid @RequestBody TokenGetRequest body,
			HttpServletRequest request) {
		int localPort = request.getLocalPort();
		String contextPath = request.getContextPath();
		TokenGetResponse response = agentTokenService.getToken(body, localPort, contextPath);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@ApiOperation(value = "", nickname = "agentTokenDisable", notes = "", response = TokenDisableResponse.class, tags = {
			"agent", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation", response = TokenDisableResponse.class) })
	@RequestMapping(value = "/api/agent/token/disable", produces = { "application/json" }, method = RequestMethod.POST)
	public ResponseEntity<TokenDisableResponse> agentTokenDisable(
			@ApiParam(value = "", required = true) @Valid @RequestBody TokenDisableRequest body,
			@RequestHeader(value = "token") String token) {
		return new ResponseEntity<>(agentTokenService.disableToken(token), HttpStatus.OK);
	}

}
