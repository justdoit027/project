package com.aia.sqs.dao.repository;

import com.aia.sqs.dao.entity.TWebserviceConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

public interface WebServiceConfigRepository extends JpaRepository<TWebserviceConfig, String>, CrudRepository<TWebserviceConfig, String>, JpaSpecificationExecutor {
}
