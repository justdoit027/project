package com.aia.sqs.api.model;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class TokenGetOutput {
  private String access_token;
  
  private int validity_seconds;
  
  private long servertime;
  public TokenGetOutput() {
	  this.servertime=System.currentTimeMillis();
  }
}

