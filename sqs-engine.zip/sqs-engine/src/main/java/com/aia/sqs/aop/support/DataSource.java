package com.aia.sqs.aop.support;

import java.lang.annotation.*;

/**
 * Support Multiple data sources
 * We can add to the method that needs to use the other data source.
 * @DataSource(value="datasourceName")
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface DataSource {

    String value() default "";
}
