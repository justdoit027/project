package com.aia.sqs.common.constant.contact;

/**
 * PHONE_TYPE_CODE
 */
public enum PhoneType {

    PRIMARY("1001"),SECONDARY("1002"),RESIDENCE("1003"),OFFICE("1004");

    private final String code;

    PhoneType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static PhoneType valueOfCode(String phoneTypeCode) {
        for (PhoneType value : values()) {
            if (value.code.equals(phoneTypeCode)) {
                return value;
            }
        }
        return null;
    }
}
