package com.aia.sqs.service.impl;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.aia.sqs.api.model.OutputVO;
import com.aia.sqs.common.util.UpdateTool;
import com.aia.sqs.dao.entity.FormularTemplate;
import com.aia.sqs.dao.entity.PlanTemplate;
import com.aia.sqs.dao.repository.FormularTemplateRepository;
import com.aia.sqs.dao.repository.PlanTemplateRepository;
import com.aia.sqs.service.FormularTemplateService;
import com.aia.sqs.service.PlanTemplateService;
import com.alibaba.fastjson.JSONObject;
@Service
public class FormularTemplateServiceImpl implements FormularTemplateService{
	@Autowired 
	private FormularTemplateRepository formularTemplateRepository;
	@Override
	public OutputVO delete(String formularTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			formularTemplateRepository.deleteById(formularTemplateId);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	@Override
	public OutputVO update(FormularTemplate formularTemplate) {
		OutputVO outputVO = new OutputVO();
		
		try {
			if (formularTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			FormularTemplate sourceTemplate = formularTemplateRepository.findById(formularTemplate.getId()).get();
			UpdateTool.copyNullProperties(sourceTemplate, formularTemplate);
			formularTemplateRepository.saveAndFlush(formularTemplate);
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
	}

	@Override
	public OutputVO add(FormularTemplate formularTemplate) {
		OutputVO outputVO = new OutputVO();
		try {
			if (formularTemplate==null) {
				outputVO.setCode("-1");
				outputVO.setMessage("Invalid parameter");
				return outputVO;
			}
			formularTemplateRepository.saveAndFlush(formularTemplate);
		
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
		
		
		
	}
	

	@Override
	public OutputVO findAll(String planTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			 List<FormularTemplate> planList = formularTemplateRepository.findAllByPlanTemplateId(planTemplateId);
			 
				outputVO.setData(planList);
			
		} catch (Exception e) {
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}

		return outputVO;
	}

	@Override
	public OutputVO queryById(String formularTemplateId) {
		OutputVO outputVO = new OutputVO();
		try {
			
			FormularTemplate formularTemplate=formularTemplateRepository.findById(formularTemplateId).get();
		
				outputVO.setData(formularTemplate);
			
		} catch (Exception e) {
			outputVO.setCode("-1");
			outputVO.setMessage("Invalid parameter");
			e.printStackTrace();
			return outputVO;
		}
		return outputVO;
	}

	

}
