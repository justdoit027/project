package com.ireport.demo.util;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import org.apache.tomcat.util.http.fileupload.FileUtils;

/**
 * PdfUtil
 * @author Hank(bsnpcbn)
 * @date Aug 30, 2019
 */
@Slf4j
public class PdfUtil {

	private PdfUtil() {}

	private static final String PDF_TEMPLATE_DIR = "jaspers/";

	public static void compileReportTemplete() throws JRException {
		File[] files = FileUtil.ls(PDF_TEMPLATE_DIR);

		if (files != null && files.length > 0) {
			for (File file : files) {
				if (!StrUtil.endWith(file.getName(), ".jrxml")) {
					continue;
				}
				String destFile = file.getAbsolutePath().replace(".jrxml", ".jasper");
				JasperCompileManager.compileReportToFile(file.getAbsolutePath(),destFile);
			}
		}
	}

	public static byte[] generatePdfBytesByJasper(String templeteName, Object data) throws JRException {

		Map<String, Object> datas = new HashMap<>();

		datas.put("resultMap", BeanUtil.beanToMap(data));
		//datas.put("imgFolder", "C:\\Users\\bsnpcbn\\eclipse-workspace\\mmr-ipos\\mmr-ipos-api\\src\\main\\resources\\pic\\");
		StringBuilder sb = new StringBuilder(PDF_TEMPLATE_DIR);
		sb.append(File.separatorChar);
		sb.append(templeteName);
		if (!StrUtil.endWith(templeteName, ".jasper")) {
			sb.append(".jasper");
		}

		JasperPrint jasperPrint = JasperFillManager.fillReport(ResourceUtil.getStream(sb.toString()), datas,
				new JREmptyDataSource());
		return JasperExportManager.exportReportToPdf(jasperPrint);
	}
	
	public static String generatePdfBytesByJasper(String templateDir,String templeteName, Map<String,Object> datas) throws JRException {
		
		StringBuilder sb = new StringBuilder(templateDir);
		if(!templateDir.endsWith(File.separator)) {
			sb.append(File.separator);
		}
		sb.append(templeteName);
		if (!StrUtil.endWith(templeteName, ".jasper")) {
			sb.append(".jasper");
		}

		JasperPrint jasperPrint = JasperFillManager.fillReport(ResourceUtil.getStream(sb.toString()), datas,
				new JREmptyDataSource());
		 byte[] pdfBytes=JasperExportManager.exportReportToPdf(jasperPrint);
		 FileUtil.writeBytes(pdfBytes, new File("C:\\soft\\pdf\\"+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddhhmmss")) +".pdf"));
		 return Base64.getEncoder().encodeToString(pdfBytes);
	}

	public static String generatePdfFileByJasperBase64(String templateName, Map<String, Object> datas) throws JRException, IOException {
		StringBuilder sb = new StringBuilder(templateName);
		if (!StrUtil.endWith(templateName, ".jasper")) {
			sb.append(".jasper");
		}
		JasperPrint jasperPrint = JasperFillManager.fillReport(ResourceUtil.getStream(sb.toString()), datas, new JREmptyDataSource());
		byte[] pdfBytes = JasperExportManager.exportReportToPdf(jasperPrint);
		FileUtil.writeBytes(pdfBytes, new File("C:\\soft\\pdf"+ LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddhhmmss")) +".pdf"));
		return Base64.getEncoder().encodeToString(pdfBytes);
	}



	
}
