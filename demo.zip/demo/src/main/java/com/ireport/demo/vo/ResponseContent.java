package com.ireport.demo.vo;


/**
 * ResponseContent
 * @author Hank(bsnpcbn)
 * @date Jul 29, 2019
 */
public enum ResponseContent {
	
	SUCCESSFUL("200","success"),
	
    FAILED("500","fail"),
	
	SAVE_FAILED("600","save failed");
	
	private String code;
	
	private String message;
	
	private ResponseContent(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

}
