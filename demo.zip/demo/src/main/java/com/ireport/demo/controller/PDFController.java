package com.ireport.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ireport.demo.service.PDFService;
import com.ireport.demo.vo.HttpResult;
import com.ireport.demo.vo.Student;
@RestController
public class PDFController {
	 @Autowired
	    private PDFService pdfService;
	 @PostMapping("/viewForm")
	    public HttpResult<String> viewQuotationForm(@RequestBody Student student) {
	        return HttpResult.returnSuccess(pdfService.generatePdfFile(student));
	    }
}
