package com.ireport.demo;


import com.ireport.demo.util.PdfUtil;

import net.sf.jasperreports.engine.JRException;

/**
 * @author created by Kevin Cheng (ASNPIEP)
 * @description
 * @date 9/9/2019
 **/
public class PdfUtilCompile {


    public static void main(String[] args) throws JRException {
        PdfUtil.compileReportTemplete();
    }
}
