package com.ireport.demo.service;

import java.util.Map;

import com.ireport.demo.vo.Student;

public interface PDFService {
	String generatePdfFile(Student student);
}
