package com.ireport.demo.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ireport.demo.util.PdfUtil;
import com.ireport.demo.vo.Student;

import net.sf.jasperreports.engine.JRException;
@Service
public class PDFServiceImpl implements PDFService{

	@Override
	public String generatePdfFile(Student student) {
		String result = "";
		Map<String, Object> datas = new HashMap<String, Object>();
		datas.put("test", student);
		try {      
			result = PdfUtil.generatePdfBytesByJasper("jaspers/","demo", datas);
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return result;
	}

}
