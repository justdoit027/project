package com.ireport.demo.vo;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;

import lombok.NoArgsConstructor;

/**
 * Global HttpResult
 * @author Hank(bsnpcbn)
 * @date Jul 29, 2019
 */
@NoArgsConstructor
public class HttpResult<T> implements Serializable {
	
    private static final long serialVersionUID = 3854679720587282344L;

    private String code;
    
    private String message;
    
    private T datas;

    private HttpResult(T datas) {
        this(ResponseContent.SUCCESSFUL, datas);
    }

    private HttpResult(ResponseContent responseContent, T datas) {
        this.datas = datas;
        this.code = responseContent.getCode();
        this.message = responseContent.getMessage();
    }
    
    private HttpResult(String code,String message,T datas) {
    	this.code = code;
    	this.message = message;
    	this.datas = datas;
    }

    public static <T> HttpResult<T> returnSuccess() {
        return new HttpResult<>(null);
    }

    public static <T> HttpResult<T> returnSuccess(T datas) {
        return new HttpResult<>(datas);
    }

    public static <T> HttpResult<T> returnSuccess(String message, T datas) {
        return new HttpResult<>(ResponseContent.SUCCESSFUL.getCode(),message,datas);
    }
    
    public static <T> HttpResult<T> returnFail() {
        return new HttpResult<>(ResponseContent.FAILED, null);
    }

    public static <T> HttpResult<T> returnFail(ResponseContent responseCode, T datas) {
        return new HttpResult<>(responseCode, datas);
    }
    
    public static <T> HttpResult<T> returnFail(String message, T datas) {
    	return new HttpResult<>(ResponseContent.FAILED.getCode(),message, datas);
    }
    
    public static <T> HttpResult<T> returnFail(String message) {
    	return returnFail(message, null);
    }
    
    public static <T> HttpResult<T> returnSaveFail() {
    	return new HttpResult<>(ResponseContent.SAVE_FAILED.getCode(),ResponseContent.SAVE_FAILED.getMessage(), null);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getDatas() {
        return datas;
    }

    public void setDatas(T datas) {
        this.datas = datas;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }
}
